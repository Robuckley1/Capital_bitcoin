/*! For license information please see chunk-WidgetIframe-27505c09674bbc49ecf7.js.LICENSE.txt */
(window.webpackJsonp = window.webpackJsonp || []).push([
    [2], {
        312: function(e, t, n) {
            "use strict";
            n.d(t, "f", (function() {
                return o
            })), n.d(t, "i", (function() {
                return a
            })), n.d(t, "x", (function() {
                return i
            })), n.d(t, "h", (function() {
                return s
            })), n.d(t, "q", (function() {
                return c
            })), n.d(t, "u", (function() {
                return u
            })), n.d(t, "s", (function() {
                return l
            })), n.d(t, "m", (function() {
                return d
            })), n.d(t, "d", (function() {
                return f
            })), n.d(t, "t", (function() {
                return p
            })), n.d(t, "w", (function() {
                return b
            })), n.d(t, "b", (function() {
                return h
            })), n.d(t, "g", (function() {
                return g
            })), n.d(t, "y", (function() {
                return v
            })), n.d(t, "A", (function() {
                return y
            })), n.d(t, "B", (function() {
                return w
            })), n.d(t, "C", (function() {
                return x
            })), n.d(t, "D", (function() {
                return O
            })), n.d(t, "l", (function() {
                return j
            })), n.d(t, "G", (function() {
                return k
            })), n.d(t, "E", (function() {
                return M
            })), n.d(t, "I", (function() {
                return A
            })), n.d(t, "H", (function() {
                return C
            })), n.d(t, "F", (function() {
                return S
            })), n.d(t, "v", (function() {
                return E
            })), n.d(t, "r", (function() {
                return R
            })), n.d(t, "n", (function() {
                return D
            })), n.d(t, "k", (function() {
                return N
            })), n.d(t, "p", (function() {
                return T
            })), n.d(t, "a", (function() {
                return P
            })), n.d(t, "e", (function() {
                return L
            })), n.d(t, "j", (function() {
                return _
            })), n.d(t, "o", (function() {
                return F
            })), n.d(t, "c", (function() {
                return z
            })), n.d(t, "z", (function() {
                return I
            }));
            n(2);
            var r = n(40),
                o = function() {
                    return Object(r.d)("svg", {
                        id: "ic_bubble",
                        fill: "#FFFFFF",
                        height: "24",
                        viewBox: "0 0 24 24",
                        width: "24",
                        xmlns: "http://www.w3.org/2000/svg",
                        "aria-hidden": !0
                    }, Object(r.d)("path", {
                        d: "M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"
                    }), Object(r.d)("path", {
                        d: "M0 0h24v24H0z",
                        fill: "none"
                    }))
                },
                a = function() {
                    return Object(r.d)("svg", {
                        id: "ic_create",
                        fill: "blue",
                        height: "24",
                        viewBox: "0 0 24 24",
                        width: "24",
                        xmlns: "http://www.w3.org/2000/svg",
                        "aria-hidden": !0
                    }, Object(r.d)("path", {
                        d: "M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"
                    }), Object(r.d)("path", {
                        d: "M0 0h24v24H0z",
                        fill: "none"
                    }))
                },
                i = function() {
                    return Object(r.d)("svg", {
                        id: "ic_send",
                        fill: "#FFFFFF",
                        height: "24",
                        viewBox: "0 0 24 24",
                        width: "24",
                        xmlns: "http://www.w3.org/2000/svg",
                        "aria-hidden": !0
                    }, Object(r.d)("path", {
                        d: "M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"
                    }), Object(r.d)("path", {
                        d: "M0 0h24v24H0z",
                        fill: "none"
                    }))
                },
                s = function() {
                    return Object(r.d)("svg", {
                        id: "ic_close",
                        fill: "#000000",
                        height: "24",
                        viewBox: "0 0 24 24",
                        width: "24",
                        xmlns: "http://www.w3.org/2000/svg",
                        "aria-hidden": !0
                    }, Object(r.d)("path", {
                        d: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"
                    }), Object(r.d)("path", {
                        d: "M0 0h24v24H0z",
                        fill: "none"
                    }))
                },
                c = function() {
                    return Object(r.d)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        height: "24",
                        viewBox: "0 0 24 24",
                        width: "24",
                        id: "ic-minimize"
                    }, Object(r.d)("path", {
                        d: "M0 0h24v24H0z",
                        fill: "none"
                    }), Object(r.d)("path", {
                        d: "M11.67 3.87L9.9 2.1 0 12l9.9 9.9 1.77-1.77L3.54 12z"
                    }))
                },
                u = function() {
                    return Object(r.d)("svg", {
                        id: "ic_options",
                        className: "options-icon",
                        fill: "#000000",
                        height: "24",
                        viewBox: "0 0 24 24",
                        width: "24",
                        xmlns: "http://www.w3.org/2000/svg",
                        "aria-hidden": !0
                    }, Object(r.d)("path", {
                        d: "M0 0h24v24H0z",
                        fill: "none"
                    }), Object(r.d)("path", {
                        d: "M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"
                    }))
                },
                l = function() {
                    return Object(r.d)("svg", {
                        id: "ic_notificationsOff",
                        fill: "#000000",
                        height: "24",
                        viewBox: "0 0 24 24",
                        width: "24",
                        xmlns: "http://www.w3.org/2000/svg",
                        "aria-hidden": !0
                    }, Object(r.d)("path", {
                        d: "M0 0h24v24H0z",
                        fill: "none"
                    }), Object(r.d)("path", {
                        d: "M20 18.69L7.84 6.14 5.27 3.49 4 4.76l2.8 2.8v.01c-.52.99-.8 2.16-.8 3.42v5l-2 2v1h13.73l2 2L21 19.72l-1-1.03zM12 22c1.11 0 2-.89 2-2h-4c0 1.11.89 2 2 2zm6-7.32V11c0-3.08-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68c-.15.03-.29.08-.42.12-.1.03-.2.07-.3.11h-.01c-.01 0-.01 0-.02.01-.23.09-.46.2-.68.31 0 0-.01 0-.01.01L18 14.68z"
                    }))
                },
                d = function() {
                    return Object(r.d)("svg", {
                        id: "ic_emojiSwitch",
                        fill: "#000000",
                        height: "24",
                        viewBox: "0 0 24 24",
                        width: "24",
                        xmlns: "http://www.w3.org/2000/svg",
                        "aria-hidden": !0
                    }, Object(r.d)("path", {
                        d: "M0 0h24v24H0z",
                        fill: "none"
                    }), Object(r.d)("path", {
                        d: "M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z"
                    }))
                },
                f = function() {
                    return Object(r.d)("svg", {
                        id: "ic_attachFile",
                        fill: "#000000",
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 24,
                        height: 24,
                        viewBox: "0 0 24 24",
                        "aria-hidden": !0
                    }, Object(r.d)("path", {
                        fill: "none",
                        d: "M0,0h24v24H0V0z"
                    }), Object(r.d)("path", {
                        d: "M13,21.8c-2.3,0-4.1-1.7-4.1-3.8V9.6c0-1.4,1.3-2.6,2.8-2.6c1.5,0,2.8,1.2,2.8,2.6v4.8c0,0.4-0.4,0.8-0.8,0.8s-0.8-0.4-0.8-0.8V9.6c0-0.6-0.5-1-1.2-1s-1.2,0.4-1.2,1V18c0,1.2,1.1,2.2,2.5,2.2c0.7,0,1.3-0.2,1.8-0.7c0.5-0.4,0.7-1,0.7-1.5V7.2c0-1.9-1.7-3.4-3.9-3.4c-2.1,0-3.9,1.5-3.9,3.4v7.2c0,0.4-0.4,0.8-0.8,0.8s-0.8-0.4-0.8-0.8V7.2c0-2.8,2.5-5,5.5-5s5.5,2.2,5.5,5V18c0,1-0.5,2-1.2,2.7C15.1,21.4,14.1,21.8,13,21.8z"
                    }))
                },
                p = function() {
                    return Object(r.d)("svg", {
                        id: "ic_notificationsOn",
                        fill: "#000000",
                        height: "24",
                        viewBox: "0 0 24 24",
                        width: "24",
                        xmlns: "http://www.w3.org/2000/svg",
                        "aria-hidden": !0
                    }, Object(r.d)("path", {
                        d: "M0 0h24v24H0z",
                        fill: "none"
                    }), Object(r.d)("path", {
                        d: "M7.58 4.08L6.15 2.65C3.75 4.48 2.17 7.3 2.03 10.5h2c.15-2.65 1.51-4.97 3.55-6.42zm12.39 6.42h2c-.15-3.2-1.73-6.02-4.12-7.85l-1.42 1.43c2.02 1.45 3.39 3.77 3.54 6.42zM18 11c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2v-5zm-6 11c.14 0 .27-.01.4-.04.65-.14 1.18-.58 1.44-1.18.1-.24.15-.5.15-.78h-4c.01 1.1.9 2 2.01 2z"
                    }))
                },
                b = function() {
                    return Object(r.d)("svg", {
                        id: "ic_rateStar",
                        fill: "#000000",
                        height: "24",
                        viewBox: "0 0 24 24",
                        width: "24",
                        xmlns: "http://www.w3.org/2000/svg",
                        "aria-hidden": !0
                    }, Object(r.d)("path", {
                        d: "M0 0h24v24H0z",
                        fill: "none"
                    }), Object(r.d)("path", {
                        d: "M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"
                    }), Object(r.d)("path", {
                        d: "M0 0h24v24H0z",
                        fill: "none"
                    }))
                },
                h = function() {
                    return Object(r.d)("svg", {
                        id: "ic_arrow",
                        fill: "#000000",
                        height: 24,
                        viewBox: "0 0 24 24",
                        width: 24,
                        xmlns: "http://www.w3.org/2000/svg"
                    }, Object(r.d)("path", {
                        d: "M0 0h24v24H0z",
                        fill: "none"
                    }), Object(r.d)("path", {
                        d: "M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z"
                    }))
                },
                m = {
                    transform: "scale(0.8) translate(3px, 4px)"
                },
                g = function() {
                    return Object(r.d)("svg", {
                        id: "caret",
                        fill: "#000000",
                        height: "48",
                        viewBox: "0 0 24 24",
                        width: "48",
                        xmlns: "http://www.w3.org/2000/svg"
                    }, Object(r.d)("path", {
                        style: m,
                        d: "M7.41 7.84L12 12.42l4.59-4.58L18 9.25l-6 6-6-6z",
                        fill: "#007dfc"
                    }), Object(r.d)("path", {
                        d: "M0-.75h24v24H0z",
                        fill: "none"
                    }))
                },
                v = function() {
                    return Object(r.d)("svg", {
                        id: "ic_successChek",
                        fill: "#000000",
                        height: "18",
                        viewBox: "0 0 24 24",
                        width: "18",
                        xmlns: "http://www.w3.org/2000/svg",
                        "aria-hidden": !0
                    }, Object(r.d)("path", {
                        d: "M0 0h24v24H0z",
                        fill: "none"
                    }), Object(r.d)("path", {
                        d: "M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"
                    }))
                },
                y = function() {
                    return Object(r.d)("svg", {
                        id: "ic_thumbDown",
                        fill: "#000000",
                        height: "24",
                        viewBox: "0 0 24 24",
                        width: "24",
                        xmlns: "http://www.w3.org/2000/svg",
                        "aria-hidden": !0
                    }, Object(r.d)("path", {
                        d: "M0 0h24v24H0z",
                        fill: "none"
                    }), Object(r.d)("path", {
                        d: "M15 3H6c-.83 0-1.54.5-1.84 1.22l-3.02 7.05c-.09.23-.14.47-.14.73v1.91l.01.01L1 14c0 1.1.9 2 2 2h6.31l-.95 4.57-.03.32c0 .41.17.79.44 1.06L9.83 23l6.59-6.59c.36-.36.58-.86.58-1.41V5c0-1.1-.9-2-2-2zm4 0v12h4V3h-4z"
                    }))
                },
                w = function() {
                    return Object(r.d)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        height: 24,
                        viewBox: "0 0 24 24",
                        width: 24,
                        fill: "#000000"
                    }, Object(r.d)("path", {
                        d: "M0 0h24v24H0V0zm0 0h24v24H0V0z",
                        fill: "none"
                    }), Object(r.d)("path", {
                        d: "M15 3H6c-.83 0-1.54.5-1.84 1.22l-3.02 7.05c-.09.23-.14.47-.14.73v2c0 1.1.9 2 2 2h6.31l-.95 4.57-.03.32c0 .41.17.79.44 1.06L9.83 23l6.59-6.59c.36-.36.58-.86.58-1.41V5c0-1.1-.9-2-2-2zm0 12l-4.34 4.34L12 14H3v-2l3-7h9v10zm4-12h4v12h-4z"
                    }))
                },
                x = function() {
                    return Object(r.d)("svg", {
                        id: "ic_thumbUp",
                        fill: "#000000",
                        height: "24",
                        viewBox: "0 0 24 24",
                        width: "24",
                        xmlns: "http://www.w3.org/2000/svg",
                        "aria-hidden": !0
                    }, Object(r.d)("path", {
                        d: "M0 0h24v24H0z",
                        fill: "none"
                    }), Object(r.d)("path", {
                        d: "M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-1.91l-.01-.01L23 10z"
                    }))
                },
                O = function() {
                    return Object(r.d)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        height: 24,
                        viewBox: "0 0 24 24",
                        width: 24,
                        fill: "#000000"
                    }, Object(r.d)("path", {
                        d: "M0 0h24v24H0V0zm0 0h24v24H0V0z",
                        fill: "none"
                    }), Object(r.d)("path", {
                        d: "M9 21h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.58 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2zM9 9l4.34-4.34L12 10h9v2l-3 7H9V9zM1 9h4v12H1z"
                    }))
                },
                j = function() {
                    return Object(r.d)("svg", {
                        id: "ic_download",
                        fill: "#000000",
                        height: 24,
                        viewBox: "0 0 24 24",
                        width: 24,
                        xmlns: "http://www.w3.org/2000/svg"
                    }, Object(r.d)("path", {
                        d: "M0 0h24v24H0z",
                        fill: "none"
                    }), Object(r.d)("path", {
                        d: "M19 19H5V5h7V3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z"
                    }))
                },
                k = function() {
                    return Object(r.d)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 24,
                        height: 24,
                        viewBox: "0 0 24 24",
                        className: "ic_upload"
                    }, Object(r.d)("path", {
                        d: "M0 0h24v24H0z",
                        fill: "none"
                    }), Object(r.d)("path", {
                        d: "M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM14 13v4h-4v-4H7l5-5 5 5h-3z"
                    }))
                },
                M = function() {
                    return Object(r.d)("svg", {
                        version: "1.1",
                        id: "ic_logo",
                        xmlns: "http://www.w3.org/2000/svg",
                        xmlnsXlink: "http://www.w3.org/1999/xlink",
                        x: "0px",
                        y: "0px",
                        viewBox: "0 0 52 16",
                        style: {
                            enableBackground: "new 0 0 52 16"
                        },
                        xmlSpace: "preserve",
                        "aria-hidden": !0
                    }, Object(r.d)("style", {
                        type: "text/css",
                        dangerouslySetInnerHTML: {
                            __html: "\n\t.st0{fill:#135EEB;}\n\t.st1{fill:#080F1A;}\n\t.st2{fill:#4FC3F7;}\n\t.st3{fill:#3F88F6;}\n"
                        }
                    }), Object(r.d)("polygon", {
                        className: "st0",
                        points: "4.8,4.7 5.1,4.3 8.9,4.7 11.2,6.3 11.7,9.1 11.8,11 11.5,11.4 11.3,11.7 8.4,11.7 5.8,10.4 4.3,8.8  4.3,6.5 4.4,5.4 "
                    }), Object(r.d)("g", null, Object(r.d)("g", null, Object(r.d)("polygon", {
                        className: "st1",
                        points: "23,12.4 23,5.3 20.5,5.3 20.5,4 27.1,4 27.1,5.3 24.5,5.3 24.5,12.4 \t\t"
                    }), Object(r.d)("path", {
                        className: "st1",
                        d: "M31.3,12.4V4h3c1.5,0,2.7,0.4,3.6,1.1S39,6.9,39,8.2s-0.4,2.3-1.2,3.1c-0.8,0.7-2,1.1-3.7,1.1H31.3z M32.8,11.2h1.5c1,0,1.8-0.3,2.3-0.7c0.5-0.5,0.8-1.2,0.8-2.2S37.2,6.6,36.7,6c-0.5-0.5-1.4-0.8-2.5-0.8h-1.4V11.2L32.8,11.2z"
                    }), Object(r.d)("path", {
                        className: "st1",
                        d: "M47.5,12.5c-1.3,0-2.4-0.4-3.2-1.2C43.4,10.5,43,9.4,43,8.2s0.4-2.3,1.3-3.1c0.9-0.8,1.9-1.2,3.2-1.2 s2.3,0.4,3.2,1.2C51.6,5.9,52,7,52,8.2s-0.4,2.3-1.3,3.1C49.8,12.1,48.8,12.5,47.5,12.5z M47.5,5.1c-0.8,0-1.5,0.3-2.1,0.9 s-0.8,1.3-0.8,2.2s0.3,1.6,0.8,2.2c0.6,0.6,1.3,0.9,2.1,0.9s1.5-0.3,2.1-0.9c0.6-0.6,0.8-1.3,0.8-2.2S50.2,6.6,49.6,6 C49,5.4,48.3,5.1,47.5,5.1z"
                    }), Object(r.d)("path", {
                        className: "st1",
                        d: "M28.1,5.8c0-0.9,0.6-1.6,1.5-1.7l0,0v6.7c0,0.9-0.6,1.6-1.5,1.7l0,0V5.8z"
                    }), Object(r.d)("path", {
                        className: "st1",
                        d: "M40.3,5.8c0-0.9,0.6-1.6,1.5-1.7l0,0v6.7c0,0.9-0.6,1.6-1.5,1.7l0,0V5.8z"
                    })), Object(r.d)("g", null, Object(r.d)("g", null, Object(r.d)("path", {
                        className: "st0",
                        d: "M5.8,4.6c-0.3,0-0.7,0-1,0.1C4.7,5,4.7,5.4,4.7,5.7c0,3.1,2.6,5.7,5.8,5.7h1c0.1-0.3,0.1-0.7,0.1-1.1 C11.6,7.2,9,4.6,5.8,4.6z"
                    }), Object(r.d)("path", {
                        className: "st2",
                        d: "M10.5,11.4c-3.2,0-5.8-2.6-5.8-5.7c0-0.3,0-0.7,0.1-1C2.1,5.2,0,7.5,0,10.3V16h5.8c2.8,0,5.2-2,5.7-4.6H10.5 z"
                    }), Object(r.d)("path", {
                        className: "st3",
                        d: "M10.5,0C7.6,0,5.3,2,4.8,4.7c0.3-0.1,0.7-0.1,1-0.1c3.2,0,5.8,2.6,5.8,5.7c0,0.4,0,0.7-0.1,1.1h4.8V5.7 C16.3,2.6,13.7,0,10.5,0z"
                    })))))
                },
                A = function() {
                    return Object(r.d)("svg", {
                        id: "xls-xlsx-csv-icon",
                        "data-name": "Warstwa 1",
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 24 24",
                        "aria-hidden": !0
                    }, Object(r.d)("defs", null, Object(r.d)("style", {
                        dangerouslySetInnerHTML: {
                            __html: "#xls-xlsx-csv-icon .cls-1{fill:#208549;}#xls-xlsx-csv-icon .cls-2{fill:#21a558;}#xls-xlsx-csv-icon .cls-3{fill:#2abc65;}#xls-xlsx-csv-icon .cls-4{fill:#fff;}"
                        }
                    })), Object(r.d)("path", {
                        className: "cls-1",
                        d: "M4.7,1A2.09,2.09,0,0,0,2.61,3.13V21.91A2.09,2.09,0,0,0,4.7,24H19.3a2.09,2.09,0,0,0,2.09-2.09V7.3L15.13,1Z"
                    }), Object(r.d)("path", {
                        className: "cls-2",
                        d: "M4.7,0A2.09,2.09,0,0,0,2.61,2.09V20.87A2.09,2.09,0,0,0,4.7,23H19.3a2.09,2.09,0,0,0,2.09-2.09V6.26L15.13,0Z"
                    }), Object(r.d)("polygon", {
                        className: "cls-1",
                        points: "21.39 11.3 21.39 10.44 21.39 6.26 18.29 3.16 15.77 5.68 21.39 11.3"
                    }), Object(r.d)("path", {
                        className: "cls-3",
                        d: "M21.39,6.26,15.13,0V4.17a2.09,2.09,0,0,0,2.09,2.09Z"
                    }), Object(r.d)("path", {
                        className: "cls-4",
                        d: "M10.54,11.79l-3-4.36h2.53L12,10.63l1.87-3.2h2.44l-2.95,4.32,3.3,4.82H14.13L11.9,12.89,9.73,16.57H7.34Z"
                    }))
                },
                C = function() {
                    return Object(r.d)("svg", {
                        id: "wma-mp3-icon",
                        "data-name": "Warstwa 1",
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 24 24",
                        "aria-hidden": !0
                    }, Object(r.d)("defs", null, Object(r.d)("style", {
                        dangerouslySetInnerHTML: {
                            __html: "#wma-mp3-icon .cls-1{fill:#542c74;}#wma-mp3-icon .cls-2{fill:#683695;}#wma-mp3-icon .cls-3{fill:#7649a2;}#wma-mp3-icon .cls-4{fill:#fff;}"
                        }
                    })), Object(r.d)("path", {
                        className: "cls-1",
                        d: "M4.7,1A2.09,2.09,0,0,0,2.61,3.13V21.91A2.09,2.09,0,0,0,4.7,24H19.3a2.09,2.09,0,0,0,2.09-2.09V7.3L15.13,1Z"
                    }), Object(r.d)("path", {
                        className: "cls-2",
                        d: "M4.7,0A2.09,2.09,0,0,0,2.61,2.09V20.87A2.09,2.09,0,0,0,4.7,23H19.3a2.09,2.09,0,0,0,2.09-2.09V6.26L15.13,0Z"
                    }), Object(r.d)("polygon", {
                        className: "cls-1",
                        points: "21.39 11.3 21.39 10.44 21.39 6.26 18.29 3.16 15.77 5.68 21.39 11.3"
                    }), Object(r.d)("path", {
                        className: "cls-3",
                        d: "M21.39,6.26,15.13,0V4.17a2.09,2.09,0,0,0,2.09,2.09Z"
                    }), Object(r.d)("path", {
                        className: "cls-4",
                        d: "M12,6.83v6.06a2.26,2.26,0,0,0-1.15-.32,2.3,2.3,0,1,0,2.3,2.3V9.13h2.3V6.83Z"
                    }))
                },
                S = function() {
                    return Object(r.d)("svg", {
                        id: "txt-rtf-icon",
                        "data-name": "Warstwa 1",
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 24 24",
                        "aria-hidden": !0
                    }, Object(r.d)("defs", null, Object(r.d)("style", {
                        dangerouslySetInnerHTML: {
                            __html: "#txt-rtf-icon .cls-1{fill:#dadada;}#txt-rtf-icon .cls-2{fill:#fff;}#txt-rtf-icon .cls-3{fill:#445b70;}"
                        }
                    })), Object(r.d)("path", {
                        className: "cls-1",
                        d: "M4.7,1A2.09,2.09,0,0,0,2.61,3.13V21.91A2.09,2.09,0,0,0,4.7,24H19.3a2.09,2.09,0,0,0,2.09-2.09V7.3L15.13,1Z"
                    }), Object(r.d)("path", {
                        className: "cls-2",
                        d: "M4.7,0A2.09,2.09,0,0,0,2.61,2.09V20.87A2.09,2.09,0,0,0,4.7,23H19.3a2.09,2.09,0,0,0,2.09-2.09V6.26L15.13,0Z"
                    }), Object(r.d)("polygon", {
                        className: "cls-1",
                        points: "21.39 11.3 21.39 10.44 21.39 6.26 18.29 3.16 15.77 5.68 21.39 11.3"
                    }), Object(r.d)("path", {
                        className: "cls-2",
                        d: "M21.39,6.26,15.13,0V4.17a2.09,2.09,0,0,0,2.09,2.09Z"
                    }), Object(r.d)("path", {
                        className: "cls-3",
                        d: "M13.54,14H10.31l-.51.8-.58.89a2.12,2.12,0,0,0-.22.51.88.88,0,0,0,0,.36.61.61,0,0,0,.26.34,1.42,1.42,0,0,0,.68.18l.05.28H6.86l0-.28a1.66,1.66,0,0,0,.69-.29,6.59,6.59,0,0,0,1-1.27l5.83-8.82h.35l1.16,8.53c.06.45.1.72.11.81a1.38,1.38,0,0,0,.35.76,1.22,1.22,0,0,0,.75.28l0,.28H12.6l0-.28a4,4,0,0,0,.75-.11.76.76,0,0,0,.31-.45,2.85,2.85,0,0,0,0-1.19Zm-.11-.63L13,9.94l-2.3,3.4Z"
                    }))
                },
                E = function() {
                    return Object(r.d)("svg", {
                        id: "pdf-icon",
                        "data-name": "Warstwa 1",
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 24 24",
                        "aria-hidden": !0
                    }, Object(r.d)("defs", null, Object(r.d)("style", {
                        dangerouslySetInnerHTML: {
                            __html: "#pdf-icon .cls-1{fill:#b6241e;}#pdf-icon .cls-2{fill:#ee2a24;}#pdf-icon .cls-3{fill:#ff4343;}#pdf-icon .cls-4{fill:#fff;}"
                        }
                    })), Object(r.d)("path", {
                        className: "cls-1",
                        d: "M4.7,1A2.09,2.09,0,0,0,2.61,3.13V21.91A2.09,2.09,0,0,0,4.7,24H19.3a2.09,2.09,0,0,0,2.09-2.09V7.3L15.13,1Z"
                    }), Object(r.d)("path", {
                        className: "cls-2",
                        d: "M4.7,0A2.09,2.09,0,0,0,2.61,2.09V20.87A2.09,2.09,0,0,0,4.7,23H19.3a2.09,2.09,0,0,0,2.09-2.09V6.26L15.13,0Z"
                    }), Object(r.d)("polygon", {
                        className: "cls-1",
                        points: "21.39 11.3 21.39 10.44 21.39 6.26 18.29 3.16 15.77 5.68 21.39 11.3"
                    }), Object(r.d)("path", {
                        className: "cls-3",
                        d: "M21.39,6.26,15.13,0V4.17a2.09,2.09,0,0,0,2.09,2.09Z"
                    }), Object(r.d)("path", {
                        className: "cls-4",
                        d: "M18.37,14.46c-.31-.56-1.39-.73-1.89-.81a7.84,7.84,0,0,0-1.19-.08c-.31,0-.61,0-.92,0l-.33,0c-.11-.12-.22-.24-.32-.37a11.45,11.45,0,0,1-1.66-2.63,10.5,10.5,0,0,0,.27-1.42,5.89,5.89,0,0,0-.2-2.77c-.12-.3-.43-.66-.78-.48a1.44,1.44,0,0,0-.56,1.2,3.71,3.71,0,0,0,.05,1,6.15,6.15,0,0,0,.25,1c.09.29.19.57.3.85-.07.23-.14.44-.22.66-.19.48-.39.94-.58,1.39l-.3.64c-.31.68-.64,1.34-1,2A11,11,0,0,0,7,15.73a4.89,4.89,0,0,0-.92.74,1.6,1.6,0,0,0-.51.94.6.6,0,0,0,.24.53,1,1,0,0,0,.81.11,4.46,4.46,0,0,0,2.13-1.58A16.23,16.23,0,0,0,10,14.79h0a19.15,19.15,0,0,1,2.63-.62c.42-.07.86-.13,1.31-.17a7.21,7.21,0,0,0,1,.79,4.87,4.87,0,0,0,.92.44,8,8,0,0,0,1,.25,3,3,0,0,0,.52,0c.4,0,1-.16,1-.65A.66.66,0,0,0,18.37,14.46Zm-9.53.89c-.19.29-.37.55-.53.78a3.88,3.88,0,0,1-1.58,1.48,1.17,1.17,0,0,1-.48.09c-.16,0-.32-.08-.32-.27a.93.93,0,0,1,.13-.33,1.72,1.72,0,0,1,.28-.37,5.06,5.06,0,0,1,.84-.68A10.18,10.18,0,0,1,9,15.17ZM11.18,8.1a3.4,3.4,0,0,1,0-.9,2.59,2.59,0,0,1,.09-.42c0-.12.12-.4.25-.43s.27.39.29.51a5.65,5.65,0,0,1-.14,2.24l-.09.33c-.05-.14-.09-.28-.14-.42A7.13,7.13,0,0,1,11.18,8.1Zm1.44,5.7a22.51,22.51,0,0,0-2.24.49,5.43,5.43,0,0,0,.56-.9,11.61,11.61,0,0,0,1-2.26,10.73,10.73,0,0,0,1.56,2.34,1.54,1.54,0,0,0,.17.19Zm5.3,1c0,.15-.36.24-.51.27A2.94,2.94,0,0,1,16,14.94a4,4,0,0,1-.86-.4A4.79,4.79,0,0,1,14.4,14c.29,0,.59,0,.89,0s.6,0,.9.06a3.2,3.2,0,0,1,1.63.62C17.91,14.69,17.93,14.75,17.92,14.81Z"
                    }))
                },
                R = function() {
                    return Object(r.d)("svg", {
                        id: "mpg-mp4-icon",
                        "data-name": "Warstwa 1",
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 24 24",
                        "aria-hidden": !0
                    }, Object(r.d)("defs", null, Object(r.d)("style", {
                        dangerouslySetInnerHTML: {
                            __html: "#mpg-mp4-icon .cls-1{fill:#132b40;}#mpg-mp4-icon .cls-2{fill:#1c3c57;}#mpg-mp4-icon .cls-3{fill:#335268;}#mpg-mp4-icon .cls-4{fill:#fff;}"
                        }
                    })), Object(r.d)("path", {
                        className: "cls-1",
                        d: "M4.7,1A2.09,2.09,0,0,0,2.61,3.13V21.91A2.09,2.09,0,0,0,4.7,24H19.3a2.09,2.09,0,0,0,2.09-2.09V7.3L15.13,1Z"
                    }), Object(r.d)("path", {
                        className: "cls-2",
                        d: "M4.7,0A2.09,2.09,0,0,0,2.61,2.09V20.87A2.09,2.09,0,0,0,4.7,23H19.3a2.09,2.09,0,0,0,2.09-2.09V6.26L15.13,0Z"
                    }), Object(r.d)("polygon", {
                        className: "cls-1",
                        points: "21.39 11.3 21.39 10.44 21.39 6.26 18.29 3.16 15.77 5.68 21.39 11.3"
                    }), Object(r.d)("path", {
                        className: "cls-3",
                        d: "M21.39,6.26,15.13,0V4.17a2.09,2.09,0,0,0,2.09,2.09Z"
                    }), Object(r.d)("path", {
                        className: "cls-4",
                        d: "M14.69,11.19V9.31a.54.54,0,0,0-.54-.54H7.69a.54.54,0,0,0-.53.54v5.38a.54.54,0,0,0,.53.54h6.46a.54.54,0,0,0,.54-.54V12.81L16.84,15V9Z"
                    }))
                },
                D = function() {
                    return Object(r.d)("svg", {
                        id: "flv-icon",
                        "data-name": "Warstwa 1",
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 24 24",
                        "aria-hidden": !0
                    }, Object(r.d)("defs", null, Object(r.d)("style", {
                        dangerouslySetInnerHTML: {
                            __html: "#flv-icon .cls-1{fill:#9b1c24;}#flv-icon .cls-2{fill:#cf1f26;}#flv-icon .cls-3{fill:#f23341;}#flv-icon .cls-4{fill:#fff;}"
                        }
                    })), Object(r.d)("path", {
                        className: "cls-1",
                        d: "M4.7,1A2.09,2.09,0,0,0,2.61,3.13V21.91A2.09,2.09,0,0,0,4.7,24H19.3a2.09,2.09,0,0,0,2.09-2.09V7.3L15.13,1Z"
                    }), Object(r.d)("path", {
                        className: "cls-2",
                        d: "M4.7,0A2.09,2.09,0,0,0,2.61,2.09V20.87A2.09,2.09,0,0,0,4.7,23H19.3a2.09,2.09,0,0,0,2.09-2.09V6.26L15.13,0Z"
                    }), Object(r.d)("polygon", {
                        className: "cls-1",
                        points: "21.39 11.3 21.39 10.44 21.39 6.26 18.29 3.16 15.77 5.68 21.39 11.3"
                    }), Object(r.d)("path", {
                        className: "cls-3",
                        d: "M21.39,6.26,15.13,0V4.17a2.09,2.09,0,0,0,2.09,2.09Z"
                    }), Object(r.d)("path", {
                        id: "path3820",
                        className: "cls-4",
                        d: "M7.48,16.4v-1h.17a2.47,2.47,0,0,0,1.78-.81,8.5,8.5,0,0,0,1.75-3.27,10.92,10.92,0,0,1,1.44-2.8A4.54,4.54,0,0,1,14.9,6.85a5.53,5.53,0,0,1,1.47-.27h.15V8.63h-.17A2.82,2.82,0,0,0,15.14,9a4.27,4.27,0,0,0-1.4,1.72c-.12.25-.18.23.76.23h.83V13H12.79l-.14.31a13.45,13.45,0,0,1-1.19,2.12,4.48,4.48,0,0,1-3.31,1.9l-.48,0H7.48v-1Z"
                    }))
                },
                N = function() {
                    return Object(r.d)("svg", {
                        id: "doc-docx-icon",
                        "data-name": "Warstwa 1",
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 24 24",
                        "aria-hidden": !0
                    }, Object(r.d)("defs", null, Object(r.d)("style", {
                        dangerouslySetInnerHTML: {
                            __html: "#doc-docx-icon .cls-1{fill:#163d75;}#doc-docx-icon .cls-2{fill:#2d4b8e;}#doc-docx-icon .cls-3{fill:#3666ad;}#doc-docx-icon .cls-4{fill:#fff;}#doc-docx-icon .cls-5{fill:#a0bde0;}"
                        }
                    })), Object(r.d)("path", {
                        className: "cls-1",
                        d: "M4.7,1A2.09,2.09,0,0,0,2.61,3.13V21.91A2.09,2.09,0,0,0,4.7,24H19.3a2.09,2.09,0,0,0,2.09-2.09V7.3L15.13,1Z"
                    }), Object(r.d)("path", {
                        className: "cls-2",
                        d: "M4.7,0A2.09,2.09,0,0,0,2.61,2.09V20.87A2.09,2.09,0,0,0,4.7,23H19.3a2.09,2.09,0,0,0,2.09-2.09V6.26L15.13,0Z"
                    }), Object(r.d)("polygon", {
                        className: "cls-1",
                        points: "21.39 11.3 21.39 10.44 21.39 6.26 18.29 3.16 15.77 5.68 21.39 11.3"
                    }), Object(r.d)("path", {
                        className: "cls-3",
                        d: "M21.39,6.26,15.13,0V4.17a2.09,2.09,0,0,0,2.09,2.09Z"
                    }), Object(r.d)("path", {
                        className: "cls-4",
                        d: "M5.51,7.43h2.2l1.46,5.86h0l1.91-5.86H13l1.9,6h0l1.53-6h2l-2.68,9.14H14l-2-6.33h0l-2,6.33H8.23Z"
                    }), Object(r.d)("polygon", {
                        className: "cls-5",
                        points: "18.27 8.17 18.48 7.43 17.52 7.43 18.27 8.17"
                    }))
                },
                T = function() {
                    return Object(r.d)("svg", {
                        className: "circular loader-icon",
                        viewBox: "25 25 50 50",
                        "aria-hidden": !0
                    }, Object(r.d)("circle", {
                        className: "path",
                        cx: 50,
                        cy: 50,
                        r: 20,
                        fill: "none",
                        stroke: "#fff",
                        strokeWidth: 2,
                        strokeMiterlimit: 10
                    }))
                },
                P = function() {
                    return Object(r.d)("svg", {
                        className: "alert-icon",
                        fill: "#000000",
                        height: 24,
                        viewBox: "0 0 24 24",
                        width: 24,
                        xmlns: "http://www.w3.org/2000/svg",
                        "aria-hidden": !0
                    }, Object(r.d)("path", {
                        d: "M0 0h24v24H0V0z",
                        fill: "none"
                    }), Object(r.d)("path", {
                        d: "M11 15h2v2h-2zm0-8h2v6h-2zm.99-5C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z"
                    }))
                },
                L = function() {
                    return Object(r.d)("svg", {
                        className: "bots-icon",
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 24,
                        height: 24,
                        viewBox: "0 0 24 24",
                        "aria-hidden": !0
                    }, Object(r.d)("path", {
                        fill: "none",
                        d: "M0,0h24v24H0V0z"
                    }), Object(r.d)("path", {
                        d: "M21.6,10.2l-0.1-1.4c0-2.1-1.6-3.7-3.7-3.8c0,0,0,0,0,0H6.3C4.3,5.1,2.6,6.7,2.6,8.8v1.4H2.4c-1.3,0-2.4,1.1-2.4,2.5v1.7c0,1.3,1.1,2.4,2.4,2.5h1.8v-8c0-1.1,0.9-2,2-2h11.5c1.1,0,2,0.9,2,2V19c0,1.1-0.9,2-2,2h-3.8c-0.3-0.8-1.1-1.2-1.9-1.2c-1.2,0-2.1,0.9-2.1,2.1C9.9,23,10.8,24,12,24c0.8,0,1.6-0.5,1.9-1.2h3.8c2.1,0,3.7-1.6,3.8-3.7c0,0,0,0,0,0v-2.4h0.1c1.3,0,2.4-1.1,2.4-2.4v-1.7C23.9,11.3,22.9,10.2,21.6,10.2z"
                    }), Object(r.d)("circle", {
                        cx: "18.2",
                        cy: "2",
                        r: "1.7"
                    }), Object(r.d)("circle", {
                        cx: "5.8",
                        cy: "2",
                        r: "1.7"
                    }), Object(r.d)("path", {
                        d: "M12.2,16.5l2,1.5l2-1.5l0.4-0.2c0.3-0.2,0.4-0.7,0.1-1c-0.2-0.3-0.7-0.4-1-0.1l0,0l-1.5,1.1l-2-1.5l-2,1.5l-1.5-1.1c-0.3-0.2-0.7-0.2-1,0.1c-0.2,0.3-0.2,0.7,0.1,1l2.3,1.7L12.2,16.5z"
                    }), Object(r.d)("circle", {
                        cx: "8.9",
                        cy: "11.4",
                        r: "1.7"
                    }), Object(r.d)("circle", {
                        cx: "15.1",
                        cy: "11.4",
                        r: "1.7"
                    }))
                },
                _ = function() {
                    return Object(r.d)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 24,
                        height: 24,
                        viewBox: "0 0 24 24"
                    }, Object(r.d)("path", {
                        d: "M0 0h24v24H0z",
                        fill: "none"
                    }), Object(r.d)("path", {
                        fill: "#3f88f6",
                        d: "M10 16.5l6-4.5-6-4.5v9zM12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"
                    }))
                },
                F = function() {
                    return Object(r.d)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 24,
                        height: 24,
                        viewBox: "0 0 24 24"
                    }, Object(r.d)("path", {
                        d: "M0 0h24v24H0z",
                        fill: "none"
                    }), Object(r.d)("path", {
                        d: "M13 3c-4.97 0-9 4.03-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42C8.27 19.99 10.51 21 13 21c4.97 0 9-4.03 9-9s-4.03-9-9-9zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z"
                    }))
                },
                z = function() {
                    return Object(r.d)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: 24,
                        height: 24,
                        viewBox: "0 0 24 24",
                        fill: "currentColor"
                    }, Object(r.d)("path", {
                        d: "M7 10L12 15L17 10L7 10Z"
                    }))
                },
                I = function() {
                    return Object(r.d)("svg", {
                        viewBox: "0 0 24 24",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg"
                    }, Object(r.d)("circle", {
                        cx: "12",
                        cy: "12",
                        r: "12",
                        fill: "#53CF74"
                    }), Object(r.d)("path", {
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        d: "m16.45 9.01-1.19-.96a.2.2 0 0 0-.13-.05.2.2 0 0 0-.14.06l-4.32 5.67-1.75-1.72c-.05-.04-.1-.13-.2-.13s-.14.07-.2.12l-.93 1.02a.95.95 0 0 1-.05.04.22.22 0 0 0-.04.13c0 .05.02.09.04.13l.06.05 3.07 3.01c.05.06.1.12.2.12.08 0 .16-.1.2-.14l5.39-7.08a.22.22 0 0 0 .04-.13c0-.05-.02-.1-.05-.14Z",
                        fill: "#fff"
                    }))
                }
        },
        313: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e, t) {
                if (t.length < e) throw new TypeError(e + " argument" + (e > 1 ? "s" : "") + " required, but only " + t.length + " present")
            }, e.exports = t.default
        },
        314: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                (0, o.default)(1, arguments);
                var t = Object.prototype.toString.call(e);
                return e instanceof Date || "object" === typeof e && "[object Date]" === t ? new Date(e.getTime()) : "number" === typeof e || "[object Number]" === t ? new Date(e) : ("string" !== typeof e && "[object String]" !== t || "undefined" === typeof console || (console.warn("Starting with v2.0.0-beta.1 date-fns doesn't accept strings as date arguments. Please use `parseISO` to parse strings. See: https://git.io/fjule"), console.warn((new Error).stack)), new Date(NaN))
            };
            var r, o = (r = n(313)) && r.__esModule ? r : {
                default: r
            };
            e.exports = t.default
        },
        315: function(e, t) {
            function n() {
                return e.exports = n = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }, n.apply(this, arguments)
            }
            e.exports = n
        },
        321: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                if (null === e || !0 === e || !1 === e) return NaN;
                var t = Number(e);
                if (isNaN(t)) return t;
                return t < 0 ? Math.ceil(t) : Math.floor(t)
            }, e.exports = t.default
        },
        323: function(e, t, n) {
            "use strict";

            function r(e) {
                return e && "object" === typeof e && "default" in e ? e.default : e
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = r(n(348)),
                a = r(n(349)),
                i = n(2),
                s = r(i),
                c = r(n(350)),
                u = r(n(351)),
                l = {
                    arr: Array.isArray,
                    obj: function(e) {
                        return "[object Object]" === Object.prototype.toString.call(e)
                    },
                    fun: function(e) {
                        return "function" === typeof e
                    },
                    str: function(e) {
                        return "string" === typeof e
                    },
                    num: function(e) {
                        return "number" === typeof e
                    },
                    und: function(e) {
                        return void 0 === e
                    },
                    nul: function(e) {
                        return null === e
                    },
                    set: function(e) {
                        return e instanceof Set
                    },
                    map: function(e) {
                        return e instanceof Map
                    },
                    equ: function(e, t) {
                        if (typeof e !== typeof t) return !1;
                        if (l.str(e) || l.num(e)) return e === t;
                        if (l.obj(e) && l.obj(t) && Object.keys(e).length + Object.keys(t).length === 0) return !0;
                        var n;
                        for (n in e)
                            if (!(n in t)) return !1;
                        for (n in t)
                            if (e[n] !== t[n]) return !1;
                        return !l.und(n) || e === t
                    }
                };

            function d() {
                var e = i.useState(!1)[1];
                return i.useCallback((function() {
                    return e((function(e) {
                        return !e
                    }))
                }), [])
            }

            function f(e, t) {
                return l.und(e) || l.nul(e) ? t : e
            }

            function p(e) {
                return l.und(e) ? [] : l.arr(e) ? e : [e]
            }

            function b(e) {
                for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                return l.fun(e) ? e.apply(void 0, n) : e
            }

            function h(e) {
                var t = function(e) {
                    return e.to, e.from, e.config, e.onStart, e.onRest, e.onFrame, e.children, e.reset, e.reverse, e.force, e.immediate, e.delay, e.attach, e.destroyed, e.interpolateTo, e.ref, e.lazy, a(e, ["to", "from", "config", "onStart", "onRest", "onFrame", "children", "reset", "reverse", "force", "immediate", "delay", "attach", "destroyed", "interpolateTo", "ref", "lazy"])
                }(e);
                if (l.und(t)) return o({
                    to: t
                }, e);
                var n = Object.keys(e).reduce((function(n, r) {
                    var a;
                    return l.und(t[r]) ? o({}, n, ((a = {})[r] = e[r], a)) : n
                }), {});
                return o({
                    to: t
                }, n)
            }
            var m, g, v = function() {
                    function e() {
                        this.payload = void 0, this.children = []
                    }
                    var t = e.prototype;
                    return t.getAnimatedValue = function() {
                        return this.getValue()
                    }, t.getPayload = function() {
                        return this.payload || this
                    }, t.attach = function() {}, t.detach = function() {}, t.getChildren = function() {
                        return this.children
                    }, t.addChild = function(e) {
                        0 === this.children.length && this.attach(), this.children.push(e)
                    }, t.removeChild = function(e) {
                        var t = this.children.indexOf(e);
                        this.children.splice(t, 1), 0 === this.children.length && this.detach()
                    }, e
                }(),
                y = function(e) {
                    function t() {
                        for (var t, n = arguments.length, r = new Array(n), o = 0; o < n; o++) r[o] = arguments[o];
                        return (t = e.call.apply(e, [this].concat(r)) || this).payload = [], t.attach = function() {
                            return t.payload.forEach((function(e) {
                                return e instanceof v && e.addChild(u(t))
                            }))
                        }, t.detach = function() {
                            return t.payload.forEach((function(e) {
                                return e instanceof v && e.removeChild(u(t))
                            }))
                        }, t
                    }
                    return c(t, e), t
                }(v),
                w = function(e) {
                    function t() {
                        for (var t, n = arguments.length, r = new Array(n), o = 0; o < n; o++) r[o] = arguments[o];
                        return (t = e.call.apply(e, [this].concat(r)) || this).payload = {}, t.attach = function() {
                            return Object.values(t.payload).forEach((function(e) {
                                return e instanceof v && e.addChild(u(t))
                            }))
                        }, t.detach = function() {
                            return Object.values(t.payload).forEach((function(e) {
                                return e instanceof v && e.removeChild(u(t))
                            }))
                        }, t
                    }
                    c(t, e);
                    var n = t.prototype;
                    return n.getValue = function(e) {
                        void 0 === e && (e = !1);
                        var t = {};
                        for (var n in this.payload) {
                            var r = this.payload[n];
                            (!e || r instanceof v) && (t[n] = r instanceof v ? r[e ? "getAnimatedValue" : "getValue"]() : r)
                        }
                        return t
                    }, n.getAnimatedValue = function() {
                        return this.getValue(!0)
                    }, t
                }(v);

            function x(e, t) {
                m = {
                    fn: e,
                    transform: t
                }
            }

            function O(e) {
                g = e
            }
            var j, k = function(e) {
                    return "undefined" !== typeof window ? window.requestAnimationFrame(e) : -1
                },
                M = function(e) {
                    "undefined" !== typeof window && window.cancelAnimationFrame(e)
                };

            function A(e) {
                j = e
            }
            var C, S = function() {
                return Date.now()
            };

            function E(e) {
                C = e
            }
            var R, D, N = function(e) {
                return e.current
            };

            function T(e) {
                R = e
            }
            var P = Object.freeze({
                    get applyAnimatedValues() {
                        return m
                    },
                    injectApplyAnimatedValues: x,
                    get colorNames() {
                        return g
                    },
                    injectColorNames: O,
                    get requestFrame() {
                        return k
                    },
                    get cancelFrame() {
                        return M
                    },
                    injectFrame: function(e, t) {
                        k = e, M = t
                    },
                    get interpolation() {
                        return j
                    },
                    injectStringInterpolator: A,
                    get now() {
                        return S
                    },
                    injectNow: function(e) {
                        S = e
                    },
                    get defaultElement() {
                        return C
                    },
                    injectDefaultElement: E,
                    get animatedApi() {
                        return N
                    },
                    injectAnimatedApi: function(e) {
                        N = e
                    },
                    get createAnimatedStyle() {
                        return R
                    },
                    injectCreateAnimatedStyle: T,
                    get manualFrameloop() {
                        return D
                    },
                    injectManualFrameloop: function(e) {
                        D = e
                    }
                }),
                L = function(e) {
                    function t(t, n) {
                        var r;
                        return (r = e.call(this) || this).update = void 0, r.payload = t.style ? o({}, t, {
                            style: R(t.style)
                        }) : t, r.update = n, r.attach(), r
                    }
                    return c(t, e), t
                }(w),
                _ = !1,
                F = new Set,
                z = function e() {
                    if (!_) return !1;
                    var t = S(),
                        n = F,
                        r = Array.isArray(n),
                        o = 0;
                    for (n = r ? n : n[Symbol.iterator]();;) {
                        var a;
                        if (r) {
                            if (o >= n.length) break;
                            a = n[o++]
                        } else {
                            if ((o = n.next()).done) break;
                            a = o.value
                        }
                        for (var i = a, s = !1, c = 0; c < i.configs.length; c++) {
                            for (var u = i.configs[c], l = void 0, d = void 0, f = 0; f < u.animatedValues.length; f++) {
                                var p = u.animatedValues[f];
                                if (!p.done) {
                                    var b = u.fromValues[f],
                                        h = u.toValues[f],
                                        m = p.lastPosition,
                                        g = h instanceof v,
                                        y = Array.isArray(u.initialVelocity) ? u.initialVelocity[f] : u.initialVelocity;
                                    if (g && (h = h.getValue()), u.immediate) p.setValue(h), p.done = !0;
                                    else if ("string" !== typeof b && "string" !== typeof h) {
                                        if (void 0 !== u.duration) m = b + u.easing((t - p.startTime) / u.duration) * (h - b), l = t >= p.startTime + u.duration;
                                        else if (u.decay) m = b + y / (1 - .998) * (1 - Math.exp(-(1 - .998) * (t - p.startTime))), (l = Math.abs(p.lastPosition - m) < .1) && (h = m);
                                        else {
                                            d = void 0 !== p.lastTime ? p.lastTime : t, y = void 0 !== p.lastVelocity ? p.lastVelocity : u.initialVelocity, t > d + 64 && (d = t);
                                            for (var w = Math.floor(t - d), x = 0; x < w; ++x) {
                                                m += 1 * (y += 1 * ((-u.tension * (m - h) + -u.friction * y) / u.mass) / 1e3) / 1e3
                                            }
                                            var O = !(!u.clamp || 0 === u.tension) && (b < h ? m > h : m < h),
                                                j = Math.abs(y) <= u.precision,
                                                M = 0 === u.tension || Math.abs(h - m) <= u.precision;
                                            l = O || j && M, p.lastVelocity = y, p.lastTime = t
                                        }
                                        g && !u.toValues[f].done && (l = !1), l ? (p.value !== h && (m = h), p.done = !0) : s = !0, p.setValue(m), p.lastPosition = m
                                    } else p.setValue(h), p.done = !0
                                }
                            }
                            i.props.onFrame && (i.values[u.name] = u.interpolation.getValue())
                        }
                        i.props.onFrame && i.props.onFrame(i.values), s || (F.delete(i), i.stop(!0))
                    }
                    return F.size ? D ? D() : k(e) : _ = !1, _
                };

            function I(e, t, n) {
                if ("function" === typeof e) return e;
                if (Array.isArray(e)) return I({
                    range: e,
                    output: t,
                    extrapolate: n
                });
                if (j && "string" === typeof e.output[0]) return j(e);
                var r = e,
                    o = r.output,
                    a = r.range || [0, 1],
                    i = r.extrapolateLeft || r.extrapolate || "extend",
                    s = r.extrapolateRight || r.extrapolate || "extend",
                    c = r.easing || function(e) {
                        return e
                    };
                return function(e) {
                    var t = function(e, t) {
                        for (var n = 1; n < t.length - 1 && !(t[n] >= e); ++n);
                        return n - 1
                    }(e, a);
                    return function(e, t, n, r, o, a, i, s, c) {
                        var u = c ? c(e) : e;
                        if (u < t) {
                            if ("identity" === i) return u;
                            "clamp" === i && (u = t)
                        }
                        if (u > n) {
                            if ("identity" === s) return u;
                            "clamp" === s && (u = n)
                        }
                        if (r === o) return r;
                        if (t === n) return e <= t ? r : o;
                        t === -1 / 0 ? u = -u : n === 1 / 0 ? u -= t : u = (u - t) / (n - t);
                        u = a(u), r === -1 / 0 ? u = -u : o === 1 / 0 ? u += r : u = u * (o - r) + r;
                        return u
                    }(e, a[t], a[t + 1], o[t], o[t + 1], c, i, s, r.map)
                }
            }
            var B = function(e) {
                function t(n, r, o, a) {
                    var i;
                    return (i = e.call(this) || this).calc = void 0, i.payload = n instanceof y && !(n instanceof t) ? n.getPayload() : Array.isArray(n) ? n : [n], i.calc = I(r, o, a), i
                }
                c(t, e);
                var n = t.prototype;
                return n.getValue = function() {
                    return this.calc.apply(this, this.payload.map((function(e) {
                        return e.getValue()
                    })))
                }, n.updateConfig = function(e, t, n) {
                    this.calc = I(e, t, n)
                }, n.interpolate = function(e, n, r) {
                    return new t(this, e, n, r)
                }, t
            }(y);
            var H = function(e) {
                    function t(t) {
                        var n;
                        return (n = e.call(this) || this).animatedStyles = new Set, n.value = void 0, n.startPosition = void 0, n.lastPosition = void 0, n.lastVelocity = void 0, n.startTime = void 0, n.lastTime = void 0, n.done = !1, n.setValue = function(e, t) {
                            void 0 === t && (t = !0), n.value = e, t && n.flush()
                        }, n.value = t, n.startPosition = t, n.lastPosition = t, n
                    }
                    c(t, e);
                    var n = t.prototype;
                    return n.flush = function() {
                        0 === this.animatedStyles.size && function e(t, n) {
                            "update" in t ? n.add(t) : t.getChildren().forEach((function(t) {
                                return e(t, n)
                            }))
                        }(this, this.animatedStyles), this.animatedStyles.forEach((function(e) {
                            return e.update()
                        }))
                    }, n.clearStyles = function() {
                        this.animatedStyles.clear()
                    }, n.getValue = function() {
                        return this.value
                    }, n.interpolate = function(e, t, n) {
                        return new B(this, e, t, n)
                    }, t
                }(v),
                W = function(e) {
                    function t(t) {
                        var n;
                        return (n = e.call(this) || this).payload = t.map((function(e) {
                            return new H(e)
                        })), n
                    }
                    c(t, e);
                    var n = t.prototype;
                    return n.setValue = function(e, t) {
                        var n = this;
                        void 0 === t && (t = !0), Array.isArray(e) ? e.length === this.payload.length && e.forEach((function(e, r) {
                            return n.payload[r].setValue(e, t)
                        })) : this.payload.forEach((function(n) {
                            return n.setValue(e, t)
                        }))
                    }, n.getValue = function() {
                        return this.payload.map((function(e) {
                            return e.getValue()
                        }))
                    }, n.interpolate = function(e, t) {
                        return new B(this, e, t)
                    }, t
                }(y),
                V = 0,
                U = function() {
                    function e() {
                        var e = this;
                        this.id = void 0, this.idle = !0, this.hasChanged = !1, this.guid = 0, this.local = 0, this.props = {}, this.merged = {}, this.animations = {}, this.interpolations = {}, this.values = {}, this.configs = [], this.listeners = [], this.queue = [], this.localQueue = void 0, this.getValues = function() {
                            return e.interpolations
                        }, this.id = V++
                    }
                    var t = e.prototype;
                    return t.update = function(e) {
                        if (!e) return this;
                        var t = h(e),
                            n = t.delay,
                            r = void 0 === n ? 0 : n,
                            i = t.to,
                            s = a(t, ["delay", "to"]);
                        if (l.arr(i) || l.fun(i)) this.queue.push(o({}, s, {
                            delay: r,
                            to: i
                        }));
                        else if (i) {
                            var c = {};
                            Object.entries(i).forEach((function(e) {
                                var t, n = e[0],
                                    a = e[1],
                                    i = o({
                                        to: (t = {}, t[n] = a, t),
                                        delay: b(r, n)
                                    }, s),
                                    u = c[i.delay] && c[i.delay].to;
                                c[i.delay] = o({}, c[i.delay], i, {
                                    to: o({}, u, i.to)
                                })
                            })), this.queue = Object.values(c)
                        }
                        return this.queue = this.queue.sort((function(e, t) {
                            return e.delay - t.delay
                        })), this.diff(s), this
                    }, t.start = function(e) {
                        var t, n = this;
                        if (this.queue.length) {
                            this.idle = !1, this.localQueue && this.localQueue.forEach((function(e) {
                                var t = e.from,
                                    r = void 0 === t ? {} : t,
                                    a = e.to,
                                    i = void 0 === a ? {} : a;
                                l.obj(r) && (n.merged = o({}, r, n.merged)), l.obj(i) && (n.merged = o({}, n.merged, i))
                            }));
                            var r = this.local = ++this.guid,
                                i = this.localQueue = this.queue;
                            this.queue = [], i.forEach((function(t, o) {
                                var s = t.delay,
                                    c = a(t, ["delay"]),
                                    u = function(t) {
                                        o === i.length - 1 && r === n.guid && t && (n.idle = !0, n.props.onRest && n.props.onRest(n.merged)), e && e()
                                    },
                                    d = l.arr(c.to) || l.fun(c.to);
                                s ? setTimeout((function() {
                                    r === n.guid && (d ? n.runAsync(c, u) : n.diff(c).start(u))
                                }), s) : d ? n.runAsync(c, u) : n.diff(c).start(u)
                            }))
                        } else l.fun(e) && this.listeners.push(e), this.props.onStart && this.props.onStart(), t = this, F.has(t) || F.add(t), _ || (_ = !0, k(D || z));
                        return this
                    }, t.stop = function(e) {
                        return this.listeners.forEach((function(t) {
                            return t(e)
                        })), this.listeners = [], this
                    }, t.pause = function(e) {
                        var t;
                        return this.stop(!0), e && (t = this, F.has(t) && F.delete(t)), this
                    }, t.runAsync = function(e, t) {
                        var n = this,
                            r = (e.delay, a(e, ["delay"])),
                            i = this.local,
                            s = Promise.resolve(void 0);
                        if (l.arr(r.to))
                            for (var c = function(e) {
                                    var t = e,
                                        a = o({}, r, h(r.to[t]));
                                    l.arr(a.config) && (a.config = a.config[t]), s = s.then((function() {
                                        if (i === n.guid) return new Promise((function(e) {
                                            return n.diff(a).start(e)
                                        }))
                                    }))
                                }, u = 0; u < r.to.length; u++) c(u);
                        else if (l.fun(r.to)) {
                            var d, f = 0;
                            s = s.then((function() {
                                return r.to((function(e) {
                                    var t = o({}, r, h(e));
                                    if (l.arr(t.config) && (t.config = t.config[f]), f++, i === n.guid) return d = new Promise((function(e) {
                                        return n.diff(t).start(e)
                                    }))
                                }), (function(e) {
                                    return void 0 === e && (e = !0), n.stop(e)
                                })).then((function() {
                                    return d
                                }))
                            }))
                        }
                        s.then(t)
                    }, t.diff = function(e) {
                        var t = this;
                        this.props = o({}, this.props, e);
                        var n = this.props,
                            r = n.from,
                            a = void 0 === r ? {} : r,
                            i = n.to,
                            s = void 0 === i ? {} : i,
                            c = n.config,
                            u = void 0 === c ? {} : c,
                            d = n.reverse,
                            h = n.attach,
                            m = n.reset,
                            v = n.immediate;
                        if (d) {
                            var y = [s, a];
                            a = y[0], s = y[1]
                        }
                        this.merged = o({}, a, this.merged, s), this.hasChanged = !1;
                        var w = h && h(this);
                        if (this.animations = Object.entries(this.merged).reduce((function(e, n) {
                                var r = n[0],
                                    i = n[1],
                                    s = e[r] || {},
                                    c = l.num(i),
                                    d = l.str(i) && !i.startsWith("#") && !/\d/.test(i) && !g[i],
                                    h = l.arr(i),
                                    y = !c && !h && !d,
                                    x = l.und(a[r]) ? i : a[r],
                                    O = c || h || d ? i : 1,
                                    k = b(u, r);
                                w && (O = w.animations[r].parent);
                                var M, A = s.parent,
                                    C = s.interpolation,
                                    E = p(w ? O.getPayload() : O),
                                    R = i;
                                y && (R = j({
                                    range: [0, 1],
                                    output: [i, i]
                                })(1));
                                var D, N = C && C.getValue(),
                                    T = !l.und(A) && s.animatedValues.some((function(e) {
                                        return !e.done
                                    })),
                                    P = !l.equ(R, N),
                                    L = !l.equ(R, s.previous),
                                    _ = !l.equ(k, s.config);
                                if (m || L && P || _) {
                                    var F;
                                    if (c || d) A = C = s.parent || new H(x);
                                    else if (h) A = C = s.parent || new W(x);
                                    else if (y) {
                                        var z = s.interpolation && s.interpolation.calc(s.parent.value);
                                        z = void 0 === z || m ? x : z, s.parent ? (A = s.parent).setValue(0, !1) : A = new H(0);
                                        var I = {
                                            output: [z, i]
                                        };
                                        s.interpolation ? (C = s.interpolation, s.interpolation.updateConfig(I)) : C = A.interpolate(I)
                                    }
                                    return E = p(w ? O.getPayload() : O), M = p(A.getPayload()), m && !y && A.setValue(x, !1), t.hasChanged = !0, M.forEach((function(e) {
                                        e.startPosition = e.value, e.lastPosition = e.value, e.lastVelocity = T ? e.lastVelocity : void 0, e.lastTime = T ? e.lastTime : void 0, e.startTime = S(), e.done = !1, e.animatedStyles.clear()
                                    })), b(v, r) && A.setValue(y ? O : i, !1), o({}, e, ((F = {})[r] = o({}, s, {
                                        name: r,
                                        parent: A,
                                        interpolation: C,
                                        animatedValues: M,
                                        toValues: E,
                                        previous: R,
                                        config: k,
                                        fromValues: p(A.getValue()),
                                        immediate: b(v, r),
                                        initialVelocity: f(k.velocity, 0),
                                        clamp: f(k.clamp, !1),
                                        precision: f(k.precision, .01),
                                        tension: f(k.tension, 170),
                                        friction: f(k.friction, 26),
                                        mass: f(k.mass, 1),
                                        duration: k.duration,
                                        easing: f(k.easing, (function(e) {
                                            return e
                                        })),
                                        decay: k.decay
                                    }), F))
                                }
                                return P ? e : (y && (A.setValue(1, !1), C.updateConfig({
                                    output: [R, R]
                                })), A.done = !0, t.hasChanged = !0, o({}, e, ((D = {})[r] = o({}, e[r], {
                                    previous: R
                                }), D)))
                            }), this.animations), this.hasChanged)
                            for (var x in this.configs = Object.values(this.animations), this.values = {}, this.interpolations = {}, this.animations) this.interpolations[x] = this.animations[x].interpolation, this.values[x] = this.animations[x].interpolation.getValue();
                        return this
                    }, t.destroy = function() {
                        this.stop(), this.props = {}, this.merged = {}, this.animations = {}, this.interpolations = {}, this.values = {}, this.configs = [], this.local = 0
                    }, e
                }(),
                q = function(e, t) {
                    var n = i.useRef(!1),
                        r = i.useRef(),
                        o = l.fun(t),
                        a = i.useMemo((function() {
                            var n;
                            return r.current && (r.current.map((function(e) {
                                return e.destroy()
                            })), r.current = void 0), [new Array(e).fill().map((function(e, r) {
                                var a = new U,
                                    i = o ? b(t, r, a) : t[r];
                                return 0 === r && (n = i.ref), a.update(i), n || a.start(), a
                            })), n]
                        }), [e]),
                        s = a[0],
                        c = a[1];
                    r.current = s;
                    i.useImperativeHandle(c, (function() {
                        return {
                            start: function() {
                                return Promise.all(r.current.map((function(e) {
                                    return new Promise((function(t) {
                                        return e.start(t)
                                    }))
                                })))
                            },
                            stop: function(e) {
                                return r.current.forEach((function(t) {
                                    return t.stop(e)
                                }))
                            },
                            get controllers() {
                                return r.current
                            }
                        }
                    }));
                    var u = i.useMemo((function() {
                        return function(e) {
                            return r.current.map((function(t, n) {
                                t.update(o ? b(e, n, t) : e[n]), c || t.start()
                            }))
                        }
                    }), [e]);
                    i.useEffect((function() {
                        n.current ? o || u(t) : c || r.current.forEach((function(e) {
                            return e.start()
                        }))
                    })), i.useEffect((function() {
                        return n.current = !0,
                            function() {
                                return r.current.forEach((function(e) {
                                    return e.destroy()
                                }))
                            }
                    }), []);
                    var d = r.current.map((function(e) {
                        return e.getValues()
                    }));
                    return o ? [d, u, function(e) {
                        return r.current.forEach((function(t) {
                            return t.pause(e)
                        }))
                    }] : d
                },
                G = 0,
                Y = function(e, t) {
                    return ("function" === typeof t ? e.map(t) : p(t)).map(String)
                },
                Q = function(e) {
                    var t = e.items,
                        n = e.keys,
                        r = void 0 === n ? function(e) {
                            return e
                        } : n,
                        i = a(e, ["items", "keys"]);
                    return t = p(void 0 !== t ? t : null), o({
                        items: t,
                        keys: Y(t, r)
                    }, i)
                };

            function K(e, t) {
                var n = function() {
                        if (o) {
                            if (a >= r.length) return "break";
                            i = r[a++]
                        } else {
                            if ((a = r.next()).done) return "break";
                            i = a.value
                        }
                        var n = i.key,
                            s = function(e) {
                                return e.key !== n
                            };
                        (l.und(t) || t === n) && (e.current.instances.delete(n), e.current.transitions = e.current.transitions.filter(s), e.current.deleted = e.current.deleted.filter(s))
                    },
                    r = e.current.deleted,
                    o = Array.isArray(r),
                    a = 0;
                for (r = o ? r : r[Symbol.iterator]();;) {
                    var i;
                    if ("break" === n()) break
                }
                e.current.forceUpdate()
            }
            var Z = function(e) {
                    function t(t) {
                        var n;
                        return void 0 === t && (t = {}), n = e.call(this) || this, !t.transform || t.transform instanceof v || (t = m.transform(t)), n.payload = t, n
                    }
                    return c(t, e), t
                }(w),
                X = {
                    transparent: 0,
                    aliceblue: 4042850303,
                    antiquewhite: 4209760255,
                    aqua: 16777215,
                    aquamarine: 2147472639,
                    azure: 4043309055,
                    beige: 4126530815,
                    bisque: 4293182719,
                    black: 255,
                    blanchedalmond: 4293643775,
                    blue: 65535,
                    blueviolet: 2318131967,
                    brown: 2771004159,
                    burlywood: 3736635391,
                    burntsienna: 3934150143,
                    cadetblue: 1604231423,
                    chartreuse: 2147418367,
                    chocolate: 3530104575,
                    coral: 4286533887,
                    cornflowerblue: 1687547391,
                    cornsilk: 4294499583,
                    crimson: 3692313855,
                    cyan: 16777215,
                    darkblue: 35839,
                    darkcyan: 9145343,
                    darkgoldenrod: 3095792639,
                    darkgray: 2846468607,
                    darkgreen: 6553855,
                    darkgrey: 2846468607,
                    darkkhaki: 3182914559,
                    darkmagenta: 2332068863,
                    darkolivegreen: 1433087999,
                    darkorange: 4287365375,
                    darkorchid: 2570243327,
                    darkred: 2332033279,
                    darksalmon: 3918953215,
                    darkseagreen: 2411499519,
                    darkslateblue: 1211993087,
                    darkslategray: 793726975,
                    darkslategrey: 793726975,
                    darkturquoise: 13554175,
                    darkviolet: 2483082239,
                    deeppink: 4279538687,
                    deepskyblue: 12582911,
                    dimgray: 1768516095,
                    dimgrey: 1768516095,
                    dodgerblue: 512819199,
                    firebrick: 2988581631,
                    floralwhite: 4294635775,
                    forestgreen: 579543807,
                    fuchsia: 4278255615,
                    gainsboro: 3705462015,
                    ghostwhite: 4177068031,
                    gold: 4292280575,
                    goldenrod: 3668254975,
                    gray: 2155905279,
                    green: 8388863,
                    greenyellow: 2919182335,
                    grey: 2155905279,
                    honeydew: 4043305215,
                    hotpink: 4285117695,
                    indianred: 3445382399,
                    indigo: 1258324735,
                    ivory: 4294963455,
                    khaki: 4041641215,
                    lavender: 3873897215,
                    lavenderblush: 4293981695,
                    lawngreen: 2096890111,
                    lemonchiffon: 4294626815,
                    lightblue: 2916673279,
                    lightcoral: 4034953471,
                    lightcyan: 3774873599,
                    lightgoldenrodyellow: 4210742015,
                    lightgray: 3553874943,
                    lightgreen: 2431553791,
                    lightgrey: 3553874943,
                    lightpink: 4290167295,
                    lightsalmon: 4288707327,
                    lightseagreen: 548580095,
                    lightskyblue: 2278488831,
                    lightslategray: 2005441023,
                    lightslategrey: 2005441023,
                    lightsteelblue: 2965692159,
                    lightyellow: 4294959359,
                    lime: 16711935,
                    limegreen: 852308735,
                    linen: 4210091775,
                    magenta: 4278255615,
                    maroon: 2147483903,
                    mediumaquamarine: 1724754687,
                    mediumblue: 52735,
                    mediumorchid: 3126187007,
                    mediumpurple: 2473647103,
                    mediumseagreen: 1018393087,
                    mediumslateblue: 2070474495,
                    mediumspringgreen: 16423679,
                    mediumturquoise: 1221709055,
                    mediumvioletred: 3340076543,
                    midnightblue: 421097727,
                    mintcream: 4127193855,
                    mistyrose: 4293190143,
                    moccasin: 4293178879,
                    navajowhite: 4292783615,
                    navy: 33023,
                    oldlace: 4260751103,
                    olive: 2155872511,
                    olivedrab: 1804477439,
                    orange: 4289003775,
                    orangered: 4282712319,
                    orchid: 3664828159,
                    palegoldenrod: 4008225535,
                    palegreen: 2566625535,
                    paleturquoise: 2951671551,
                    palevioletred: 3681588223,
                    papayawhip: 4293907967,
                    peachpuff: 4292524543,
                    peru: 3448061951,
                    pink: 4290825215,
                    plum: 3718307327,
                    powderblue: 2967529215,
                    purple: 2147516671,
                    rebeccapurple: 1714657791,
                    red: 4278190335,
                    rosybrown: 3163525119,
                    royalblue: 1097458175,
                    saddlebrown: 2336560127,
                    salmon: 4202722047,
                    sandybrown: 4104413439,
                    seagreen: 780883967,
                    seashell: 4294307583,
                    sienna: 2689740287,
                    silver: 3233857791,
                    skyblue: 2278484991,
                    slateblue: 1784335871,
                    slategray: 1887473919,
                    slategrey: 1887473919,
                    snow: 4294638335,
                    springgreen: 16744447,
                    steelblue: 1182971135,
                    tan: 3535047935,
                    teal: 8421631,
                    thistle: 3636451583,
                    tomato: 4284696575,
                    turquoise: 1088475391,
                    violet: 4001558271,
                    wheat: 4125012991,
                    white: 4294967295,
                    whitesmoke: 4126537215,
                    yellow: 4294902015,
                    yellowgreen: 2597139199
                },
                $ = "[-+]?\\d*\\.?\\d+";

            function J() {
                for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                return "\\(\\s*(" + t.join(")\\s*,\\s*(") + ")\\s*\\)"
            }
            var ee = new RegExp("rgb" + J($, $, $)),
                te = new RegExp("rgba" + J($, $, $, $)),
                ne = new RegExp("hsl" + J($, "[-+]?\\d*\\.?\\d+%", "[-+]?\\d*\\.?\\d+%")),
                re = new RegExp("hsla" + J($, "[-+]?\\d*\\.?\\d+%", "[-+]?\\d*\\.?\\d+%", $)),
                oe = /^#([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
                ae = /^#([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
                ie = /^#([0-9a-fA-F]{6})$/,
                se = /^#([0-9a-fA-F]{8})$/;

            function ce(e, t, n) {
                return n < 0 && (n += 1), n > 1 && (n -= 1), n < 1 / 6 ? e + 6 * (t - e) * n : n < .5 ? t : n < 2 / 3 ? e + (t - e) * (2 / 3 - n) * 6 : e
            }

            function ue(e, t, n) {
                var r = n < .5 ? n * (1 + t) : n + t - n * t,
                    o = 2 * n - r,
                    a = ce(o, r, e + 1 / 3),
                    i = ce(o, r, e),
                    s = ce(o, r, e - 1 / 3);
                return Math.round(255 * a) << 24 | Math.round(255 * i) << 16 | Math.round(255 * s) << 8
            }

            function le(e) {
                var t = parseInt(e, 10);
                return t < 0 ? 0 : t > 255 ? 255 : t
            }

            function de(e) {
                return (parseFloat(e) % 360 + 360) % 360 / 360
            }

            function fe(e) {
                var t = parseFloat(e);
                return t < 0 ? 0 : t > 1 ? 255 : Math.round(255 * t)
            }

            function pe(e) {
                var t = parseFloat(e);
                return t < 0 ? 0 : t > 100 ? 1 : t / 100
            }

            function be(e) {
                var t = function(e) {
                    var t;
                    return "number" === typeof e ? e >>> 0 === e && e >= 0 && e <= 4294967295 ? e : null : (t = ie.exec(e)) ? parseInt(t[1] + "ff", 16) >>> 0 : X.hasOwnProperty(e) ? X[e] : (t = ee.exec(e)) ? (le(t[1]) << 24 | le(t[2]) << 16 | le(t[3]) << 8 | 255) >>> 0 : (t = te.exec(e)) ? (le(t[1]) << 24 | le(t[2]) << 16 | le(t[3]) << 8 | fe(t[4])) >>> 0 : (t = oe.exec(e)) ? parseInt(t[1] + t[1] + t[2] + t[2] + t[3] + t[3] + "ff", 16) >>> 0 : (t = se.exec(e)) ? parseInt(t[1], 16) >>> 0 : (t = ae.exec(e)) ? parseInt(t[1] + t[1] + t[2] + t[2] + t[3] + t[3] + t[4] + t[4], 16) >>> 0 : (t = ne.exec(e)) ? (255 | ue(de(t[1]), pe(t[2]), pe(t[3]))) >>> 0 : (t = re.exec(e)) ? (ue(de(t[1]), pe(t[2]), pe(t[3])) | fe(t[4])) >>> 0 : null
                }(e);
                return null === t ? e : "rgba(" + ((4278190080 & (t = t || 0)) >>> 24) + ", " + ((16711680 & t) >>> 16) + ", " + ((65280 & t) >>> 8) + ", " + (255 & t) / 255 + ")"
            }
            var he = /[+\-]?(?:0|[1-9]\d*)(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,
                me = /(#(?:[0-9a-f]{2}){2,4}|(#[0-9a-f]{3})|(rgb|hsl)a?\((-?\d+%?[,\s]+){2,3}\s*[\d\.]+%?\))/gi,
                ge = new RegExp("(" + Object.keys(X).join("|") + ")", "g"),
                ve = {
                    animationIterationCount: !0,
                    borderImageOutset: !0,
                    borderImageSlice: !0,
                    borderImageWidth: !0,
                    boxFlex: !0,
                    boxFlexGroup: !0,
                    boxOrdinalGroup: !0,
                    columnCount: !0,
                    columns: !0,
                    flex: !0,
                    flexGrow: !0,
                    flexPositive: !0,
                    flexShrink: !0,
                    flexNegative: !0,
                    flexOrder: !0,
                    gridRow: !0,
                    gridRowEnd: !0,
                    gridRowSpan: !0,
                    gridRowStart: !0,
                    gridColumn: !0,
                    gridColumnEnd: !0,
                    gridColumnSpan: !0,
                    gridColumnStart: !0,
                    fontWeight: !0,
                    lineClamp: !0,
                    lineHeight: !0,
                    opacity: !0,
                    order: !0,
                    orphans: !0,
                    tabSize: !0,
                    widows: !0,
                    zIndex: !0,
                    zoom: !0,
                    fillOpacity: !0,
                    floodOpacity: !0,
                    stopOpacity: !0,
                    strokeDasharray: !0,
                    strokeDashoffset: !0,
                    strokeMiterlimit: !0,
                    strokeOpacity: !0,
                    strokeWidth: !0
                },
                ye = ["Webkit", "Ms", "Moz", "O"];

            function we(e, t, n) {
                return null == t || "boolean" === typeof t || "" === t ? "" : n || "number" !== typeof t || 0 === t || ve.hasOwnProperty(e) && ve[e] ? ("" + t).trim() : t + "px"
            }
            ve = Object.keys(ve).reduce((function(e, t) {
                return ye.forEach((function(n) {
                    return e[function(e, t) {
                        return e + t.charAt(0).toUpperCase() + t.substring(1)
                    }(n, t)] = e[t]
                })), e
            }), ve);
            var xe = {};
            T((function(e) {
                return new Z(e)
            })), E("div"), A((function(e) {
                var t = e.output.map((function(e) {
                        return e.replace(me, be)
                    })).map((function(e) {
                        return e.replace(ge, be)
                    })),
                    n = t[0].match(he).map((function() {
                        return []
                    }));
                t.forEach((function(e) {
                    e.match(he).forEach((function(e, t) {
                        return n[t].push(+e)
                    }))
                }));
                var r = t[0].match(he).map((function(t, r) {
                    return I(o({}, e, {
                        output: n[r]
                    }))
                }));
                return function(e) {
                    var n = 0;
                    return t[0].replace(he, (function() {
                        return r[n++](e)
                    })).replace(/rgba\(([0-9\.-]+), ([0-9\.-]+), ([0-9\.-]+), ([0-9\.-]+)\)/gi, (function(e, t, n, r, o) {
                        return "rgba(" + Math.round(t) + ", " + Math.round(n) + ", " + Math.round(r) + ", " + o + ")"
                    }))
                }
            })), O(X), x((function(e, t) {
                if (!e.nodeType || void 0 === e.setAttribute) return !1;
                var n = t.style,
                    r = t.children,
                    o = t.scrollTop,
                    i = t.scrollLeft,
                    s = a(t, ["style", "children", "scrollTop", "scrollLeft"]),
                    c = "filter" === e.nodeName || e.parentNode && "filter" === e.parentNode.nodeName;
                for (var u in void 0 !== o && (e.scrollTop = o), void 0 !== i && (e.scrollLeft = i), void 0 !== r && (e.textContent = r), n)
                    if (n.hasOwnProperty(u)) {
                        var l = 0 === u.indexOf("--"),
                            d = we(u, n[u], l);
                        "float" === u && (u = "cssFloat"), l ? e.style.setProperty(u, d) : e.style[u] = d
                    }
                for (var f in s) {
                    var p = c ? f : xe[f] || (xe[f] = f.replace(/([A-Z])/g, (function(e) {
                        return "-" + e.toLowerCase()
                    })));
                    "undefined" !== typeof e.getAttribute(p) && e.setAttribute(p, s[f])
                }
            }), (function(e) {
                return e
            }));
            var Oe, je, ke = (Oe = function(e) {
                    return i.forwardRef((function(t, n) {
                        var r = d(),
                            c = i.useRef(!0),
                            u = i.useRef(null),
                            f = i.useRef(null),
                            p = i.useCallback((function(e) {
                                var t = u.current;
                                u.current = new L(e, (function() {
                                    var e = !1;
                                    f.current && (e = m.fn(f.current, u.current.getAnimatedValue())), f.current && !1 !== e || r()
                                })), t && t.detach()
                            }), []);
                        i.useEffect((function() {
                            return function() {
                                c.current = !1, u.current && u.current.detach()
                            }
                        }), []), i.useImperativeHandle(n, (function() {
                            return N(f, c, r)
                        })), p(t);
                        var b, h = u.current.getValue(),
                            g = (h.scrollTop, h.scrollLeft, a(h, ["scrollTop", "scrollLeft"])),
                            v = (b = e, !l.fun(b) || b.prototype instanceof s.Component ? function(e) {
                                return f.current = function(e, t) {
                                    return t && (l.fun(t) ? t(e) : l.obj(t) && (t.current = e)), e
                                }(e, n)
                            } : void 0);
                        return s.createElement(e, o({}, g, {
                            ref: v
                        }))
                    }))
                }, void 0 === (je = !1) && (je = !0), function(e) {
                    return (l.arr(e) ? e : Object.keys(e)).reduce((function(e, t) {
                        var n = je ? t[0].toLowerCase() + t.substring(1) : t;
                        return e[n] = Oe(n), e
                    }), Oe)
                }),
                Me = ke(["a", "abbr", "address", "area", "article", "aside", "audio", "b", "base", "bdi", "bdo", "big", "blockquote", "body", "br", "button", "canvas", "caption", "cite", "code", "col", "colgroup", "data", "datalist", "dd", "del", "details", "dfn", "dialog", "div", "dl", "dt", "em", "embed", "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "iframe", "img", "input", "ins", "kbd", "keygen", "label", "legend", "li", "link", "main", "map", "mark", "menu", "menuitem", "meta", "meter", "nav", "noscript", "object", "ol", "optgroup", "option", "output", "p", "param", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "script", "section", "select", "small", "source", "span", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "textarea", "tfoot", "th", "thead", "time", "title", "tr", "track", "u", "ul", "var", "video", "wbr", "circle", "clipPath", "defs", "ellipse", "foreignObject", "g", "image", "line", "linearGradient", "mask", "path", "pattern", "polygon", "polyline", "radialGradient", "rect", "stop", "svg", "text", "tspan"]);
            t.apply = ke, t.config = {
                default: {
                    tension: 170,
                    friction: 26
                },
                gentle: {
                    tension: 120,
                    friction: 14
                },
                wobbly: {
                    tension: 180,
                    friction: 12
                },
                stiff: {
                    tension: 210,
                    friction: 20
                },
                slow: {
                    tension: 280,
                    friction: 60
                },
                molasses: {
                    tension: 280,
                    friction: 120
                }
            }, t.update = z, t.animated = Me, t.a = Me, t.interpolate = function(e, t, n) {
                return e && new B(e, t, n)
            }, t.Globals = P, t.useSpring = function(e) {
                var t = l.fun(e),
                    n = q(1, t ? e : [e]),
                    r = n[0],
                    o = n[1],
                    a = n[2];
                return t ? [r[0], o, a] : r
            }, t.useTrail = function(e, t) {
                var n = i.useRef(!1),
                    r = l.fun(t),
                    a = b(t),
                    s = i.useRef(),
                    c = q(e, (function(e, t) {
                        return 0 === e && (s.current = []), s.current.push(t), o({}, a, {
                            config: b(a.config, e),
                            attach: e > 0 && function() {
                                return s.current[e - 1]
                            }
                        })
                    })),
                    u = c[0],
                    d = c[1],
                    f = c[2],
                    p = i.useMemo((function() {
                        return function(e) {
                            return d((function(t, n) {
                                e.reverse;
                                var r = e.reverse ? t + 1 : t - 1,
                                    i = s.current[r];
                                return o({}, e, {
                                    config: b(e.config || a.config, t),
                                    attach: i && function() {
                                        return i
                                    }
                                })
                            }))
                        }
                    }), [e, a.reverse]);
                return i.useEffect((function() {
                    n.current && !r && p(t)
                })), i.useEffect((function() {
                    n.current = !0
                }), []), r ? [u, p, f] : u
            }, t.useTransition = function(e, t, n) {
                var r = o({
                        items: e,
                        keys: t || function(e) {
                            return e
                        }
                    }, n),
                    s = Q(r),
                    c = s.lazy,
                    u = void 0 !== c && c,
                    l = (s.unique, s.reset),
                    f = void 0 !== l && l,
                    p = (s.enter, s.leave, s.update, s.onDestroyed),
                    h = (s.keys, s.items, s.onFrame),
                    m = s.onRest,
                    g = s.onStart,
                    v = s.ref,
                    y = a(s, ["lazy", "unique", "reset", "enter", "leave", "update", "onDestroyed", "keys", "items", "onFrame", "onRest", "onStart", "ref"]),
                    w = d(),
                    x = i.useRef(!1),
                    O = i.useRef({
                        mounted: !1,
                        first: !0,
                        deleted: [],
                        current: {},
                        transitions: [],
                        prevProps: {},
                        paused: !!r.ref,
                        instances: !x.current && new Map,
                        forceUpdate: w
                    });
                return i.useImperativeHandle(r.ref, (function() {
                    return {
                        start: function() {
                            return Promise.all(Array.from(O.current.instances).map((function(e) {
                                var t = e[1];
                                return new Promise((function(e) {
                                    return t.start(e)
                                }))
                            })))
                        },
                        stop: function(e) {
                            return Array.from(O.current.instances).forEach((function(t) {
                                return t[1].stop(e)
                            }))
                        },
                        get controllers() {
                            return Array.from(O.current.instances).map((function(e) {
                                return e[1]
                            }))
                        }
                    }
                })), O.current = function(e, t) {
                    var n = e.first,
                        r = e.prevProps,
                        i = a(e, ["first", "prevProps"]),
                        s = Q(t),
                        c = s.items,
                        u = s.keys,
                        l = s.initial,
                        d = s.from,
                        f = s.enter,
                        p = s.leave,
                        h = s.update,
                        m = s.trail,
                        g = void 0 === m ? 0 : m,
                        v = s.unique,
                        y = s.config,
                        w = s.order,
                        x = void 0 === w ? ["enter", "leave", "update"] : w,
                        O = Q(r),
                        j = O.keys,
                        k = O.items,
                        M = o({}, i.current),
                        A = [].concat(i.deleted),
                        C = Object.keys(M),
                        S = new Set(C),
                        E = new Set(u),
                        R = u.filter((function(e) {
                            return !S.has(e)
                        })),
                        D = i.transitions.filter((function(e) {
                            return !e.destroyed && !E.has(e.originalKey)
                        })).map((function(e) {
                            return e.originalKey
                        })),
                        N = u.filter((function(e) {
                            return S.has(e)
                        })),
                        T = -g;
                    for (; x.length;) {
                        switch (x.shift()) {
                            case "enter":
                                R.forEach((function(e, t) {
                                    v && A.find((function(t) {
                                        return t.originalKey === e
                                    })) && (A = A.filter((function(t) {
                                        return t.originalKey !== e
                                    })));
                                    var r = u.indexOf(e),
                                        o = c[r],
                                        a = n && void 0 !== l ? "initial" : "enter";
                                    M[e] = {
                                        slot: a,
                                        originalKey: e,
                                        key: v ? String(e) : G++,
                                        item: o,
                                        trail: T += g,
                                        config: b(y, o, a),
                                        from: b(n && void 0 !== l ? l || {} : d, o),
                                        to: b(f, o)
                                    }
                                }));
                                break;
                            case "leave":
                                D.forEach((function(e) {
                                    var t = j.indexOf(e),
                                        n = k[t];
                                    A.unshift(o({}, M[e], {
                                        slot: "leave",
                                        destroyed: !0,
                                        left: j[Math.max(0, t - 1)],
                                        right: j[Math.min(j.length, t + 1)],
                                        trail: T += g,
                                        config: b(y, n, "leave"),
                                        to: b(p, n)
                                    })), delete M[e]
                                }));
                                break;
                            case "update":
                                N.forEach((function(e) {
                                    var t = u.indexOf(e),
                                        n = c[t];
                                    M[e] = o({}, M[e], {
                                        item: n,
                                        slot: "update",
                                        trail: T += g,
                                        config: b(y, n, "update"),
                                        to: b(h, n)
                                    })
                                }))
                        }
                    }
                    var P = u.map((function(e) {
                        return M[e]
                    }));
                    return A.forEach((function(e) {
                        var t, n = e.left,
                            r = (e.right, a(e, ["left", "right"])); - 1 !== (t = P.findIndex((function(e) {
                            return e.originalKey === n
                        }))) && (t += 1), t = Math.max(0, t), P = [].concat(P.slice(0, t), [r], P.slice(t))
                    })), o({}, i, {
                        changed: R.length || D.length || N.length,
                        first: n && 0 === R.length,
                        transitions: P,
                        current: M,
                        deleted: A,
                        prevProps: t
                    })
                }(O.current, r), O.current.changed && O.current.transitions.forEach((function(e) {
                    var t = e.slot,
                        n = e.from,
                        r = e.to,
                        a = e.config,
                        i = e.trail,
                        s = e.key,
                        c = e.item;
                    O.current.instances.has(s) || O.current.instances.set(s, new U);
                    var l = O.current.instances.get(s),
                        d = o({}, y, {
                            to: r,
                            from: n,
                            config: a,
                            ref: v,
                            onRest: function(n) {
                                O.current.mounted && (e.destroyed && (v || u || K(O, s), p && p(c)), !Array.from(O.current.instances).some((function(e) {
                                    return !e[1].idle
                                })) && (v || u) && O.current.deleted.length > 0 && K(O), m && m(c, t, n))
                            },
                            onStart: g && function() {
                                return g(c, t)
                            },
                            onFrame: h && function(e) {
                                return h(c, t, e)
                            },
                            delay: i,
                            reset: f && "enter" === t
                        });
                    l.update(d), O.current.paused || l.start()
                })), i.useEffect((function() {
                    return O.current.mounted = x.current = !0,
                        function() {
                            O.current.mounted = x.current = !1, Array.from(O.current.instances).map((function(e) {
                                return e[1].destroy()
                            })), O.current.instances.clear()
                        }
                }), []), O.current.transitions.map((function(e) {
                    var t = e.item,
                        n = e.slot,
                        r = e.key;
                    return {
                        item: t,
                        key: r,
                        state: n,
                        props: O.current.instances.get(r).getValues()
                    }
                }))
            }, t.useChain = function(e, t, n) {
                void 0 === n && (n = 1e3);
                var r = i.useRef();
                i.useEffect((function() {
                    l.equ(e, r.current) ? e.forEach((function(e) {
                        var t = e.current;
                        return t && t.start()
                    })) : t ? e.forEach((function(e, r) {
                        var a = e.current;
                        if (a) {
                            var i = a.controllers;
                            if (i.length) {
                                var s = n * t[r];
                                i.forEach((function(e) {
                                    e.queue = e.queue.map((function(e) {
                                        return o({}, e, {
                                            delay: e.delay + s
                                        })
                                    })), e.start()
                                }))
                            }
                        }
                    })) : e.reduce((function(e, t, n) {
                        var r = t.current;
                        return e.then((function() {
                            return r.start()
                        }))
                    }), Promise.resolve()), r.current = e
                }))
            }, t.useSprings = q
        },
        325: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.FrameContextConsumer = t.FrameContext = void 0;
            var r = n(328);
            Object.defineProperty(t, "FrameContext", {
                enumerable: !0,
                get: function() {
                    return r.FrameContext
                }
            }), Object.defineProperty(t, "FrameContextConsumer", {
                enumerable: !0,
                get: function() {
                    return r.FrameContextConsumer
                }
            });
            var o, a = n(342),
                i = (o = a) && o.__esModule ? o : {
                    default: o
                };
            t.default = i.default
        },
        326: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                (0, o.default)(1, arguments);
                var t = 1,
                    n = (0, r.default)(e),
                    a = n.getUTCDay(),
                    i = (a < t ? 7 : 0) + a - t;
                return n.setUTCDate(n.getUTCDate() - i), n.setUTCHours(0, 0, 0, 0), n
            };
            var r = a(n(314)),
                o = a(n(313));

            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            e.exports = t.default
        },
        327: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e, t) {
                (0, a.default)(1, arguments);
                var n = t || {},
                    i = n.locale,
                    s = i && i.options && i.options.weekStartsOn,
                    c = null == s ? 0 : (0, r.default)(s),
                    u = null == n.weekStartsOn ? c : (0, r.default)(n.weekStartsOn);
                if (!(u >= 0 && u <= 6)) throw new RangeError("weekStartsOn must be between 0 and 6 inclusively");
                var l = (0, o.default)(e),
                    d = l.getUTCDay(),
                    f = (d < u ? 7 : 0) + d - u;
                return l.setUTCDate(l.getUTCDate() - f), l.setUTCHours(0, 0, 0, 0), l
            };
            var r = i(n(321)),
                o = i(n(314)),
                a = i(n(313));

            function i(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            e.exports = t.default
        },
        328: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.FrameContextConsumer = t.FrameContextProvider = t.FrameContext = void 0;
            var r, o = n(2),
                a = (r = o) && r.__esModule ? r : {
                    default: r
                };
            var i = void 0,
                s = void 0;
            "undefined" !== typeof document && (i = document), "undefined" !== typeof window && (s = window);
            var c = t.FrameContext = a.default.createContext({
                    document: i,
                    window: s
                }),
                u = c.Provider,
                l = c.Consumer;
            t.FrameContextProvider = u, t.FrameContextConsumer = l
        },
        329: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.STYLIS_PROPERTY_CONTEXT = void 0;
            var r, o = n(344),
                a = (r = o) && r.__esModule ? r : {
                    default: r
                };
            var i = t.STYLIS_PROPERTY_CONTEXT = -1;

            function s(e, t) {
                if (e === i) return a.default.transform(t)
            }
            t.default = s
        },
        330: function(e, t, n) {
            var r = n(9),
                o = n(352);
            r({
                target: "Array",
                stat: !0,
                forced: !n(211)((function(e) {
                    Array.from(e)
                }))
            }, {
                from: o
            })
        },
        331: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e, t) {
                (0, o.default)(2, arguments);
                var n = (0, r.default)(e),
                    a = (0, r.default)(t);
                return n.getTime() === a.getTime()
            };
            var r = a(n(355)),
                o = a(n(313));

            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            e.exports = t.default
        },
        332: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e, t) {
                var n = e < 0 ? "-" : "",
                    r = Math.abs(e).toString();
                for (; r.length < t;) r = "0" + r;
                return n + r
            }, e.exports = t.default
        },
        333: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                (0, a.default)(1, arguments);
                var t = (0, r.default)(e),
                    n = t.getUTCFullYear(),
                    i = new Date(0);
                i.setUTCFullYear(n + 1, 0, 4), i.setUTCHours(0, 0, 0, 0);
                var s = (0, o.default)(i),
                    c = new Date(0);
                c.setUTCFullYear(n, 0, 4), c.setUTCHours(0, 0, 0, 0);
                var u = (0, o.default)(c);
                return t.getTime() >= s.getTime() ? n + 1 : t.getTime() >= u.getTime() ? n : n - 1
            };
            var r = i(n(314)),
                o = i(n(326)),
                a = i(n(313));

            function i(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            e.exports = t.default
        },
        334: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e, t) {
                (0, i.default)(1, arguments);
                var n = (0, o.default)(e, t),
                    s = n.getUTCFullYear(),
                    c = t || {},
                    u = c.locale,
                    l = u && u.options && u.options.firstWeekContainsDate,
                    d = null == l ? 1 : (0, r.default)(l),
                    f = null == c.firstWeekContainsDate ? d : (0, r.default)(c.firstWeekContainsDate);
                if (!(f >= 1 && f <= 7)) throw new RangeError("firstWeekContainsDate must be between 1 and 7 inclusively");
                var p = new Date(0);
                p.setUTCFullYear(s + 1, 0, f), p.setUTCHours(0, 0, 0, 0);
                var b = (0, a.default)(p, t),
                    h = new Date(0);
                h.setUTCFullYear(s, 0, f), h.setUTCHours(0, 0, 0, 0);
                var m = (0, a.default)(h, t);
                return n.getTime() >= b.getTime() ? s + 1 : n.getTime() >= m.getTime() ? s : s - 1
            };
            var r = s(n(321)),
                o = s(n(314)),
                a = s(n(327)),
                i = s(n(313));

            function s(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            e.exports = t.default
        },
        335: function(e, t, n) {
            var r = function(e) {
                "use strict";
                var t = Object.prototype,
                    n = t.hasOwnProperty,
                    r = "function" === typeof Symbol ? Symbol : {},
                    o = r.iterator || "@@iterator",
                    a = r.asyncIterator || "@@asyncIterator",
                    i = r.toStringTag || "@@toStringTag";

                function s(e, t, n, r) {
                    var o = t && t.prototype instanceof l ? t : l,
                        a = Object.create(o.prototype),
                        i = new O(r || []);
                    return a._invoke = function(e, t, n) {
                        var r = "suspendedStart";
                        return function(o, a) {
                            if ("executing" === r) throw new Error("Generator is already running");
                            if ("completed" === r) {
                                if ("throw" === o) throw a;
                                return k()
                            }
                            for (n.method = o, n.arg = a;;) {
                                var i = n.delegate;
                                if (i) {
                                    var s = y(i, n);
                                    if (s) {
                                        if (s === u) continue;
                                        return s
                                    }
                                }
                                if ("next" === n.method) n.sent = n._sent = n.arg;
                                else if ("throw" === n.method) {
                                    if ("suspendedStart" === r) throw r = "completed", n.arg;
                                    n.dispatchException(n.arg)
                                } else "return" === n.method && n.abrupt("return", n.arg);
                                r = "executing";
                                var l = c(e, t, n);
                                if ("normal" === l.type) {
                                    if (r = n.done ? "completed" : "suspendedYield", l.arg === u) continue;
                                    return {
                                        value: l.arg,
                                        done: n.done
                                    }
                                }
                                "throw" === l.type && (r = "completed", n.method = "throw", n.arg = l.arg)
                            }
                        }
                    }(e, n, i), a
                }

                function c(e, t, n) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, n)
                        }
                    } catch (r) {
                        return {
                            type: "throw",
                            arg: r
                        }
                    }
                }
                e.wrap = s;
                var u = {};

                function l() {}

                function d() {}

                function f() {}
                var p = {};
                p[o] = function() {
                    return this
                };
                var b = Object.getPrototypeOf,
                    h = b && b(b(j([])));
                h && h !== t && n.call(h, o) && (p = h);
                var m = f.prototype = l.prototype = Object.create(p);

                function g(e) {
                    ["next", "throw", "return"].forEach((function(t) {
                        e[t] = function(e) {
                            return this._invoke(t, e)
                        }
                    }))
                }

                function v(e, t) {
                    var r;
                    this._invoke = function(o, a) {
                        function i() {
                            return new t((function(r, i) {
                                ! function r(o, a, i, s) {
                                    var u = c(e[o], e, a);
                                    if ("throw" !== u.type) {
                                        var l = u.arg,
                                            d = l.value;
                                        return d && "object" === typeof d && n.call(d, "__await") ? t.resolve(d.__await).then((function(e) {
                                            r("next", e, i, s)
                                        }), (function(e) {
                                            r("throw", e, i, s)
                                        })) : t.resolve(d).then((function(e) {
                                            l.value = e, i(l)
                                        }), (function(e) {
                                            return r("throw", e, i, s)
                                        }))
                                    }
                                    s(u.arg)
                                }(o, a, r, i)
                            }))
                        }
                        return r = r ? r.then(i, i) : i()
                    }
                }

                function y(e, t) {
                    var n = e.iterator[t.method];
                    if (void 0 === n) {
                        if (t.delegate = null, "throw" === t.method) {
                            if (e.iterator.return && (t.method = "return", t.arg = void 0, y(e, t), "throw" === t.method)) return u;
                            t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return u
                    }
                    var r = c(n, e.iterator, t.arg);
                    if ("throw" === r.type) return t.method = "throw", t.arg = r.arg, t.delegate = null, u;
                    var o = r.arg;
                    return o ? o.done ? (t[e.resultName] = o.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = void 0), t.delegate = null, u) : o : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, u)
                }

                function w(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function x(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function O(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(w, this), this.reset(!0)
                }

                function j(e) {
                    if (e) {
                        var t = e[o];
                        if (t) return t.call(e);
                        if ("function" === typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var r = -1,
                                a = function t() {
                                    for (; ++r < e.length;)
                                        if (n.call(e, r)) return t.value = e[r], t.done = !1, t;
                                    return t.value = void 0, t.done = !0, t
                                };
                            return a.next = a
                        }
                    }
                    return {
                        next: k
                    }
                }

                function k() {
                    return {
                        value: void 0,
                        done: !0
                    }
                }
                return d.prototype = m.constructor = f, f.constructor = d, f[i] = d.displayName = "GeneratorFunction", e.isGeneratorFunction = function(e) {
                    var t = "function" === typeof e && e.constructor;
                    return !!t && (t === d || "GeneratorFunction" === (t.displayName || t.name))
                }, e.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, f) : (e.__proto__ = f, i in e || (e[i] = "GeneratorFunction")), e.prototype = Object.create(m), e
                }, e.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, g(v.prototype), v.prototype[a] = function() {
                    return this
                }, e.AsyncIterator = v, e.async = function(t, n, r, o, a) {
                    void 0 === a && (a = Promise);
                    var i = new v(s(t, n, r, o), a);
                    return e.isGeneratorFunction(n) ? i : i.next().then((function(e) {
                        return e.done ? e.value : i.next()
                    }))
                }, g(m), m[i] = "Generator", m[o] = function() {
                    return this
                }, m.toString = function() {
                    return "[object Generator]"
                }, e.keys = function(e) {
                    var t = [];
                    for (var n in e) t.push(n);
                    return t.reverse(),
                        function n() {
                            for (; t.length;) {
                                var r = t.pop();
                                if (r in e) return n.value = r, n.done = !1, n
                            }
                            return n.done = !0, n
                        }
                }, e.values = j, O.prototype = {
                    constructor: O,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(x), !e)
                            for (var t in this) "t" === t.charAt(0) && n.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(e) {
                        if (this.done) throw e;
                        var t = this;

                        function r(n, r) {
                            return i.type = "throw", i.arg = e, t.next = n, r && (t.method = "next", t.arg = void 0), !!r
                        }
                        for (var o = this.tryEntries.length - 1; o >= 0; --o) {
                            var a = this.tryEntries[o],
                                i = a.completion;
                            if ("root" === a.tryLoc) return r("end");
                            if (a.tryLoc <= this.prev) {
                                var s = n.call(a, "catchLoc"),
                                    c = n.call(a, "finallyLoc");
                                if (s && c) {
                                    if (this.prev < a.catchLoc) return r(a.catchLoc, !0);
                                    if (this.prev < a.finallyLoc) return r(a.finallyLoc)
                                } else if (s) {
                                    if (this.prev < a.catchLoc) return r(a.catchLoc, !0)
                                } else {
                                    if (!c) throw new Error("try statement without catch or finally");
                                    if (this.prev < a.finallyLoc) return r(a.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var o = this.tryEntries[r];
                            if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) {
                                var a = o;
                                break
                            }
                        }
                        a && ("break" === e || "continue" === e) && a.tryLoc <= t && t <= a.finallyLoc && (a = null);
                        var i = a ? a.completion : {};
                        return i.type = e, i.arg = t, a ? (this.method = "next", this.next = a.finallyLoc, u) : this.complete(i)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), u
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), x(n), u
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.tryLoc === e) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var o = r.arg;
                                    x(n)
                                }
                                return o
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(e, t, n) {
                        return this.delegate = {
                            iterator: j(e),
                            resultName: t,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = void 0), u
                    }
                }, e
            }(e.exports);
            try {
                regeneratorRuntime = r
            } catch (o) {
                Function("r", "regeneratorRuntime = r")(r)
            }
        },
        336: function(e, t, n) {
            "use strict";
            e.exports = function(e) {
                var t = [];
                return t.toString = function() {
                    return this.map((function(t) {
                        var n = function(e, t) {
                            var n = e[1] || "",
                                r = e[3];
                            if (!r) return n;
                            if (t && "function" === typeof btoa) {
                                var o = function(e) {
                                        var t = btoa(unescape(encodeURIComponent(JSON.stringify(e)))),
                                            n = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(t);
                                        return "/*# ".concat(n, " */")
                                    }(r),
                                    a = r.sources.map((function(e) {
                                        return "/*# sourceURL=".concat(r.sourceRoot || "").concat(e, " */")
                                    }));
                                return [n].concat(a).concat([o]).join("\n")
                            }
                            return [n].join("\n")
                        }(t, e);
                        return t[2] ? "@media ".concat(t[2], " {").concat(n, "}") : n
                    })).join("")
                }, t.i = function(e, n, r) {
                    "string" === typeof e && (e = [
                        [null, e, ""]
                    ]);
                    var o = {};
                    if (r)
                        for (var a = 0; a < this.length; a++) {
                            var i = this[a][0];
                            null != i && (o[i] = !0)
                        }
                    for (var s = 0; s < e.length; s++) {
                        var c = [].concat(e[s]);
                        r && o[c[0]] || (n && (c[2] ? c[2] = "".concat(n, " and ").concat(c[2]) : c[2] = n), t.push(c))
                    }
                }, t
            }
        },
        337: function(e, t, n) {
            "use strict";
            var r = n(315),
                o = n.n(r),
                a = (n(2), n(325)),
                i = n(40);
            t.a = function(e) {
                return function(t) {
                    return Object(i.d)(a.FrameContextConsumer, null, (function(n) {
                        var r = n.document,
                            a = n.window;
                        return Object(i.d)(e, o()({}, t, {
                            iframeDocument: r,
                            iframeWindow: a
                        }))
                    }))
                }
            }
        },
        342: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                },
                o = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var r = t[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                        }
                    }
                    return function(t, n, r) {
                        return n && e(t.prototype, n), r && e(t, r), t
                    }
                }(),
                a = n(2),
                i = d(a),
                s = d(n(100)),
                c = d(n(204)),
                u = n(328),
                l = d(n(343));

            function d(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            var f = function(e) {
                function t(e, n) {
                    ! function(e, t) {
                        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                    }(this, t);
                    var r = function(e, t) {
                        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                        return !t || "object" !== typeof t && "function" !== typeof t ? e : t
                    }(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, e, n));
                    return r.handleLoad = function() {
                        r.forceUpdate()
                    }, r._isMounted = !1, r
                }
                return function(e, t) {
                    if ("function" !== typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
                    e.prototype = Object.create(t && t.prototype, {
                        constructor: {
                            value: e,
                            enumerable: !1,
                            writable: !0,
                            configurable: !0
                        }
                    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
                }(t, e), o(t, [{
                    key: "componentDidMount",
                    value: function() {
                        this._isMounted = !0;
                        var e = this.getDoc();
                        e && "complete" === e.readyState ? this.forceUpdate() : this.node.addEventListener("load", this.handleLoad)
                    }
                }, {
                    key: "componentWillUnmount",
                    value: function() {
                        this._isMounted = !1, this.node.removeEventListener("load", this.handleLoad)
                    }
                }, {
                    key: "getDoc",
                    value: function() {
                        return this.node ? this.node.contentDocument : null
                    }
                }, {
                    key: "getMountTarget",
                    value: function() {
                        var e = this.getDoc();
                        return this.props.mountTarget ? e.querySelector(this.props.mountTarget) : e.body.children[0]
                    }
                }, {
                    key: "renderFrameContents",
                    value: function() {
                        if (!this._isMounted) return null;
                        var e = this.getDoc();
                        if (!e || !e.body) return null;
                        var t = this.props.contentDidMount,
                            n = this.props.contentDidUpdate,
                            r = e.defaultView || e.parentView,
                            o = i.default.createElement(l.default, {
                                contentDidMount: t,
                                contentDidUpdate: n
                            }, i.default.createElement(u.FrameContextProvider, {
                                value: {
                                    document: e,
                                    window: r
                                }
                            }, i.default.createElement("div", {
                                className: "frame-content"
                            }, this.props.children)));
                        e && e.body && e.body.children && e.body.children.length < 1 && (e.getElementsByTagName("html")[0].innerHTML = this.props.initialContent);
                        var a = this.getMountTarget();
                        return [s.default.createPortal(this.props.head, this.getDoc().head), s.default.createPortal(o, a)]
                    }
                }, {
                    key: "render",
                    value: function() {
                        var e = this,
                            t = r({}, this.props, {
                                children: void 0
                            });
                        return delete t.head, delete t.initialContent, delete t.mountTarget, delete t.contentDidMount, delete t.contentDidUpdate, i.default.createElement("iframe", r({}, t, {
                            ref: function(t) {
                                e.node = t
                            }
                        }), this.renderFrameContents())
                    }
                }]), t
            }(a.Component);
            f.propTypes = {
                style: c.default.object,
                head: c.default.node,
                initialContent: c.default.string,
                mountTarget: c.default.string,
                contentDidMount: c.default.func,
                contentDidUpdate: c.default.func,
                children: c.default.oneOfType([c.default.element, c.default.arrayOf(c.default.element)])
            }, f.defaultProps = {
                style: {},
                head: null,
                children: void 0,
                mountTarget: void 0,
                contentDidMount: function() {},
                contentDidUpdate: function() {},
                initialContent: '<html><head></head><body><div class="frame-root"></div></body>'
            }, t.default = f
        },
        343: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = function() {
                    function e(e, t) {
                        for (var n = 0; n < t.length; n++) {
                            var r = t[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                        }
                    }
                    return function(t, n, r) {
                        return n && e(t.prototype, n), r && e(t, r), t
                    }
                }(),
                o = n(2),
                a = (i(o), i(n(204)));

            function i(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }

            function s(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }

            function c(e, t) {
                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return !t || "object" !== typeof t && "function" !== typeof t ? e : t
            }
            var u = function(e) {
                function t() {
                    return s(this, t), c(this, (t.__proto__ || Object.getPrototypeOf(t)).apply(this, arguments))
                }
                return function(e, t) {
                    if ("function" !== typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
                    e.prototype = Object.create(t && t.prototype, {
                        constructor: {
                            value: e,
                            enumerable: !1,
                            writable: !0,
                            configurable: !0
                        }
                    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
                }(t, e), r(t, [{
                    key: "componentDidMount",
                    value: function() {
                        this.props.contentDidMount()
                    }
                }, {
                    key: "componentDidUpdate",
                    value: function() {
                        this.props.contentDidUpdate()
                    }
                }, {
                    key: "render",
                    value: function() {
                        return o.Children.only(this.props.children)
                    }
                }]), t
            }(o.Component);
            u.propTypes = {
                children: a.default.element.isRequired,
                contentDidMount: a.default.func.isRequired,
                contentDidUpdate: a.default.func.isRequired
            }, t.default = u
        },
        344: function(e, t, n) {
            var r;

            function o(e, t) {
                var n = [],
                    r = 0;

                function o(e) {
                    return n.push(e), t
                }

                function a() {
                    return n[r++]
                }
                return {
                    tokenize: function(t) {
                        return t.replace(e, o)
                    },
                    detokenize: function(e) {
                        return e.replace(new RegExp("(" + t + ")", "g"), a)
                    }
                }
            }
            r = new function() {
                var e = "(?:(?:(?:\\\\[0-9a-f]{1,6})(?:\\r\\n|\\s)?)|\\\\[^\\r\\n\\f0-9a-f])",
                    t = "(?:[_a-z0-9-]|[^\\u0020-\\u007e]|" + e + ")",
                    n = "(?:[0-9]*\\.[0-9]+|[0-9]+)(?:\\s*(?:em|ex|px|cm|mm|in|pt|pc|deg|rad|grad|ms|s|hz|khz|%)|-?(?:[_a-z]|[^\\u0020-\\u007e]|(?:(?:(?:\\\\[0-9a-f]{1,6})(?:\\r\\n|\\s)?)|\\\\[^\\r\\n\\f0-9a-f]))(?:[_a-z0-9-]|[^\\u0020-\\u007e]|(?:(?:(?:\\\\[0-9a-f]{1,6})(?:\\r\\n|\\s)?)|\\\\[^\\r\\n\\f0-9a-f]))*)?",
                    r = "((?:-?" + n + ")|(?:inherit|auto))",
                    a = "(#?" + t + "+|(?:rgba?|hsla?)\\([ \\d.,%-]+\\))",
                    i = "(?:[!#$%&*-~]|[^\\u0020-\\u007e]|" + e + ")*?",
                    s = "(?!(" + t + "|\\r?\\n|\\s|#|\\:|\\.|\\,|\\+|>|\\(|\\)|\\[|\\]|=|\\*=|~=|\\^=|'[^']*'])*?{)",
                    c = "(?!" + i + "['\"]?\\s*\\))",
                    u = "(?=" + i + "['\"]?\\s*\\))",
                    l = "(\\s*(?:!important\\s*)?[;}])",
                    d = new RegExp("`TMP`", "g"),
                    f = new RegExp("\\/\\*[^*]*\\*+([^\\/*][^*]*\\*+)*\\/", "gi"),
                    p = new RegExp("(\\/\\*\\!?\\s*@noflip\\s*\\*\\/" + s + "[^;}]+;?)", "gi"),
                    b = new RegExp("(\\/\\*\\!?\\s*@noflip\\s*\\*\\/[^\\}]*?})", "gi"),
                    h = new RegExp("(direction\\s*:\\s*)ltr", "gi"),
                    m = new RegExp("(direction\\s*:\\s*)rtl", "gi"),
                    g = new RegExp("(^|[^a-zA-Z])(left)(?![a-zA-Z])" + c + s, "gi"),
                    v = new RegExp("(^|[^a-zA-Z])(right)(?![a-zA-Z])" + c + s, "gi"),
                    y = new RegExp("(^|[^a-zA-Z])(left)" + u, "gi"),
                    w = new RegExp("(^|[^a-zA-Z])(right)" + u, "gi"),
                    x = new RegExp("(^|[^a-zA-Z])(ltr)" + u, "gi"),
                    O = new RegExp("(^|[^a-zA-Z])(rtl)" + u, "gi"),
                    j = new RegExp("(^|[^a-zA-Z])([ns]?)e-resize", "gi"),
                    k = new RegExp("(^|[^a-zA-Z])([ns]?)w-resize", "gi"),
                    M = new RegExp("((?:margin|padding|border-width)\\s*:\\s*)" + r + "(\\s+)" + r + "(\\s+)" + r + "(\\s+)" + r + l, "gi"),
                    A = new RegExp("((?:-color|border-style)\\s*:\\s*)" + a + "(\\s+)" + a + "(\\s+)" + a + "(\\s+)" + a + l, "gi"),
                    C = new RegExp("(background(?:-position)?\\s*:\\s*(?:[^:;}\\s]+\\s+)*?)(" + n + ")", "gi"),
                    S = new RegExp("(background-position-x\\s*:\\s*)(-?(?:[0-9]*\\.[0-9]+|[0-9]+)%)", "gi"),
                    E = new RegExp("(border-radius\\s*:\\s*)" + r + "(?:(?:\\s+" + r + ")(?:\\s+" + r + ")?(?:\\s+" + r + ")?)?(?:(?:(?:\\s*\\/\\s*)" + r + ")(?:\\s+" + r + ")?(?:\\s+" + r + ")?(?:\\s+" + r + ")?)?" + l, "gi"),
                    R = new RegExp("(box-shadow\\s*:\\s*(?:inset\\s*)?)" + r, "gi"),
                    D = new RegExp("(text-shadow\\s*:\\s*)" + r + "(\\s*)" + a, "gi"),
                    N = new RegExp("(text-shadow\\s*:\\s*)" + a + "(\\s*)" + r, "gi"),
                    T = new RegExp("(text-shadow\\s*:\\s*)" + r, "gi"),
                    P = new RegExp("(transform\\s*:[^;}]*)(translateX\\s*\\(\\s*)" + r + "(\\s*\\))", "gi"),
                    L = new RegExp("(transform\\s*:[^;}]*)(translate\\s*\\(\\s*)" + r + "((?:\\s*,\\s*" + r + "){0,2}\\s*\\))", "gi");

                function _(e, t, n) {
                    var r, o;
                    return "%" === n.slice(-1) && (-1 !== (r = n.indexOf(".")) ? (o = n.length - r - 2, n = (n = 100 - parseFloat(n)).toFixed(o) + "%") : n = 100 - parseFloat(n) + "%"), t + n
                }

                function F(e) {
                    switch (e.length) {
                        case 4:
                            e = [e[1], e[0], e[3], e[2]];
                            break;
                        case 3:
                            e = [e[1], e[0], e[1], e[2]];
                            break;
                        case 2:
                            e = [e[1], e[0]];
                            break;
                        case 1:
                            e = [e[0]]
                    }
                    return e.join(" ")
                }

                function z(e, t) {
                    var n = [].slice.call(arguments),
                        r = n.slice(2, 6).filter((function(e) {
                            return e
                        })),
                        o = n.slice(6, 10).filter((function(e) {
                            return e
                        })),
                        a = n[10] || "";
                    return t + (o.length ? F(r) + " / " + F(o) : F(r)) + a
                }

                function I(e) {
                    return 0 === parseFloat(e) ? e : "-" === e[0] ? e.slice(1) : "-" + e
                }

                function B(e, t, n) {
                    return t + I(n)
                }

                function H(e, t, n, r, o) {
                    return t + n + I(r) + o
                }

                function W(e, t, n, r, o) {
                    return t + n + r + I(o)
                }
                return {
                    transform: function(e, t) {
                        var n = new o(p, "`NOFLIP_SINGLE`"),
                            r = new o(b, "`NOFLIP_CLASS`"),
                            a = new o(f, "`COMMENT`");
                        return e = a.tokenize(r.tokenize(n.tokenize(e.replace("`", "%60")))), t.transformDirInUrl && (e = e.replace(x, "$1`TMP`").replace(O, "$1ltr").replace(d, "rtl")), t.transformEdgeInUrl && (e = e.replace(y, "$1`TMP`").replace(w, "$1left").replace(d, "right")), e = e.replace(h, "$1`TMP`").replace(m, "$1ltr").replace(d, "rtl").replace(g, "$1`TMP`").replace(v, "$1left").replace(d, "right").replace(j, "$1$2`TMP`").replace(k, "$1$2e-resize").replace(d, "w-resize").replace(E, z).replace(R, B).replace(D, W).replace(N, W).replace(T, B).replace(P, H).replace(L, H).replace(M, "$1$2$3$8$5$6$7$4$9").replace(A, "$1$2$3$8$5$6$7$4$9").replace(C, _).replace(S, _), e = n.detokenize(r.detokenize(a.detokenize(e)))
                    }
                }
            }, e.exports ? t.transform = function(e, t, n) {
                var o;
                return "object" === typeof t ? o = t : (o = {}, "boolean" === typeof t && (o.transformDirInUrl = t), "boolean" === typeof n && (o.transformEdgeInUrl = n)), r.transform(e, o)
            } : "undefined" !== typeof window && (window.cssjanus = r)
        },
        345: function(e, t, n) {
            ! function() {
                function t(e) {
                    this.document = e || window.document
                }

                function n(e, t) {
                    this.a = t, this.b = this.a.createElement("div"), this.b.setAttribute("aria-hidden", "true"), this.a.append(this.b, this.a.document.createTextNode(e)), this.c = this.a.createElement("span"), this.f = this.a.createElement("span"), this.i = this.a.createElement("span"), this.g = this.a.createElement("span"), this.h = -1, this.a.style(this.c, "max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;"), this.a.style(this.f, "max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;"), this.a.style(this.g, "max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;"), this.a.style(this.i, "display:inline-block;width:200%;height:200%;font-size:16px;max-width:none;"), this.a.append(this.c, this.i), this.a.append(this.f, this.g), this.a.append(this.b, this.c), this.a.append(this.b, this.f)
                }

                function r(e, t) {
                    e.a.style(e.b, "max-width:none;min-width:20px;min-height:20px;display:inline-block;overflow:hidden;position:absolute;width:auto;margin:0;padding:0;top:-999px;white-space:nowrap;font-synthesis:none;font:" + t + ";")
                }

                function o(e) {
                    var t = e.b.offsetWidth,
                        n = t + 100;
                    return e.g.style.width = n + "px", e.f.scrollLeft = n, e.c.scrollLeft = e.c.scrollWidth + 100, e.h !== t && (e.h = t, !0)
                }

                function a(e, t) {
                    function n() {
                        var e = r;
                        o(e) && null !== e.b.parentNode && t(e.h)
                    }
                    var r = e;
                    e.a.addListener(e.c, "scroll", n), e.a.addListener(e.f, "scroll", n), o(e)
                }

                function i(e, n) {
                    var r = n || {};
                    this.document = r.document || window.document, this.a = new t(this.document), this.family = e, this.style = r.style || "normal", this.weight = r.weight || "normal", this.stretch = r.stretch || "normal"
                }
                t.prototype.createElement = function(e) {
                    return this.document.createElement(e)
                }, t.prototype.style = function(e, t) {
                    e.style.cssText = t
                }, t.prototype.append = function(e, t) {
                    e.appendChild(t)
                }, t.prototype.addListener = function(e, t, n) {
                    this.document.addEventListener ? e.addEventListener(t, n, !1) : e.attachEvent(t, n)
                };
                var s = null,
                    c = null,
                    u = null,
                    l = null;

                function d() {
                    return null === l && (l = !!document.fonts), l
                }

                function f(e) {
                    if (null === u) {
                        e = e.a.createElement("div");
                        try {
                            e.style.font = "condensed 100px sans-serif"
                        } catch (t) {}
                        u = "" !== e.style.font
                    }
                    return u
                }

                function p(e, t) {
                    return [e.style, e.weight, f(e) ? e.stretch : "", "100px", t].join(" ")
                }
                i.prototype.load = function(e, t) {
                    var o = this,
                        i = e || "BESbswy",
                        u = 0,
                        l = t || 3e3,
                        f = (new Date).getTime();
                    return new Promise((function(e, t) {
                        if (d() && ! function() {
                                if (null === c)
                                    if (d() && /Apple/.test(window.navigator.vendor)) {
                                        var e = /AppleWebKit\/([0-9]+)(?:\.([0-9]+))(?:\.([0-9]+))/.exec(window.navigator.userAgent);
                                        c = !!e && 603 > parseInt(e[1], 10)
                                    } else c = !1;
                                return c
                            }()) {
                            var b = new Promise((function(e, t) {
                                    ! function n() {
                                        (new Date).getTime() - f >= l ? t() : o.document.fonts.load(p(o, '"' + o.family + '"'), i).then((function(t) {
                                            1 <= t.length ? e() : setTimeout(n, 25)
                                        }), (function() {
                                            t()
                                        }))
                                    }()
                                })),
                                h = new Promise((function(e, t) {
                                    u = setTimeout(t, l)
                                }));
                            Promise.race([h, b]).then((function() {
                                clearTimeout(u), e(o)
                            }), (function() {
                                t(o)
                            }))
                        } else ! function(e, t) {
                            e.document.body ? t() : e.document.addEventListener ? e.document.addEventListener("DOMContentLoaded", (function e() {
                                this.document.removeEventListener("DOMContentLoaded", e), t()
                            })) : e.document.attachEvent("onreadystatechange", (function e() {
                                "interactive" != this.document.readyState && "complete" != this.document.readyState || (this.document.detachEvent("onreadystatechange", e), t())
                            }))
                        }(o.a, (function() {
                            function c() {
                                var t;
                                (t = -1 != m && -1 != g || -1 != m && -1 != v || -1 != g && -1 != v) && ((t = m != g && m != v && g != v) || (null === s && (t = /AppleWebKit\/([0-9]+)(?:\.([0-9]+))/.exec(window.navigator.userAgent), s = !!t && (536 > parseInt(t[1], 10) || 536 === parseInt(t[1], 10) && 11 >= parseInt(t[2], 10))), t = s && (m == y && g == y && v == y || m == w && g == w && v == w || m == x && g == x && v == x)), t = !t), t && (O.parentNode && O.parentNode.removeChild(O), clearTimeout(u), e(o))
                            }
                            var d = new n(i, o.a),
                                b = new n(i, o.a),
                                h = new n(i, o.a),
                                m = -1,
                                g = -1,
                                v = -1,
                                y = -1,
                                w = -1,
                                x = -1,
                                O = o.a.createElement("div");
                            O.dir = "ltr", r(d, p(o, "sans-serif")), r(b, p(o, "serif")), r(h, p(o, "monospace")), o.a.append(O, d.b), o.a.append(O, b.b), o.a.append(O, h.b), o.a.append(o.document.body, O), y = d.b.offsetWidth, w = b.b.offsetWidth, x = h.b.offsetWidth,
                                function e() {
                                    if ((new Date).getTime() - f >= l) O.parentNode && O.parentNode.removeChild(O), t(o);
                                    else {
                                        var n = o.document.hidden;
                                        !0 !== n && void 0 !== n || (m = d.b.offsetWidth, g = b.b.offsetWidth, v = h.b.offsetWidth, c()), u = setTimeout(e, 50)
                                    }
                                }(), a(d, (function(e) {
                                    m = e, c()
                                })), r(d, p(o, '"' + o.family + '",sans-serif')), a(b, (function(e) {
                                    g = e, c()
                                })), r(b, p(o, '"' + o.family + '",serif')), a(h, (function(e) {
                                    v = e, c()
                                })), r(h, p(o, '"' + o.family + '",monospace'))
                        }))
                    }))
                }, e.exports = i
            }()
        },
        346: function(e, t, n) {
            "use strict";
            t.__esModule = !0, t.default = function(e, t) {
                if (e && t) {
                    var n = Array.isArray(t) ? t : t.split(","),
                        r = e.name || "",
                        o = (e.type || "").toLowerCase(),
                        a = o.replace(/\/.*$/, "");
                    return n.some((function(e) {
                        var t = e.trim().toLowerCase();
                        return "." === t.charAt(0) ? r.toLowerCase().endsWith(t) : t.endsWith("/*") ? a === t.replace(/\/.*$/, "") : o === t
                    }))
                }
                return !0
            }
        },
        347: function(e, t, n) {
            e.exports = function() {
                "use strict";
                var e = Object.hasOwnProperty,
                    t = Object.setPrototypeOf,
                    n = Object.isFrozen,
                    r = Object.keys,
                    o = Object.freeze,
                    a = Object.seal,
                    i = "undefined" !== typeof Reflect && Reflect,
                    s = i.apply,
                    c = i.construct;
                s || (s = function(e, t, n) {
                    return e.apply(t, n)
                }), o || (o = function(e) {
                    return e
                }), a || (a = function(e) {
                    return e
                }), c || (c = function(e, t) {
                    return new(Function.prototype.bind.apply(e, [null].concat(function(e) {
                        if (Array.isArray(e)) {
                            for (var t = 0, n = Array(e.length); t < e.length; t++) n[t] = e[t];
                            return n
                        }
                        return Array.from(e)
                    }(t))))
                });
                var u = j(Array.prototype.forEach),
                    l = j(Array.prototype.indexOf),
                    d = j(Array.prototype.join),
                    f = j(Array.prototype.pop),
                    p = j(Array.prototype.push),
                    b = j(Array.prototype.slice),
                    h = j(String.prototype.toLowerCase),
                    m = j(String.prototype.match),
                    g = j(String.prototype.replace),
                    v = j(String.prototype.indexOf),
                    y = j(String.prototype.trim),
                    w = j(RegExp.prototype.test),
                    x = k(RegExp),
                    O = k(TypeError);

                function j(e) {
                    return function(t) {
                        for (var n = arguments.length, r = Array(n > 1 ? n - 1 : 0), o = 1; o < n; o++) r[o - 1] = arguments[o];
                        return s(e, t, r)
                    }
                }

                function k(e) {
                    return function() {
                        for (var t = arguments.length, n = Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                        return c(e, n)
                    }
                }

                function M(e, r) {
                    t && t(e, null);
                    for (var o = r.length; o--;) {
                        var a = r[o];
                        if ("string" === typeof a) {
                            var i = h(a);
                            i !== a && (n(r) || (r[o] = i), a = i)
                        }
                        e[a] = !0
                    }
                    return e
                }

                function A(t) {
                    var n = {},
                        r = void 0;
                    for (r in t) s(e, t, [r]) && (n[r] = t[r]);
                    return n
                }
                var C = o(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]),
                    S = o(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "audio", "canvas", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "video", "view", "vkern"]),
                    E = o(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]),
                    R = o(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover"]),
                    D = o(["#text"]),
                    N = o(["accept", "action", "align", "alt", "autocomplete", "background", "bgcolor", "border", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "coords", "crossorigin", "datetime", "default", "dir", "disabled", "download", "enctype", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "integrity", "ismap", "label", "lang", "list", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "name", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "type", "usemap", "valign", "value", "width", "xmlns"]),
                    T = o(["accent-height", "accumulate", "additive", "alignment-baseline", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "specularconstant", "specularexponent", "spreadmethod", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "tabindex", "targetx", "targety", "transform", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]),
                    P = o(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]),
                    L = o(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]),
                    _ = a(/\{\{[\s\S]*|[\s\S]*\}\}/gm),
                    F = a(/<%[\s\S]*|[\s\S]*%>/gm),
                    z = a(/^data-[\-\w.\u00B7-\uFFFF]/),
                    I = a(/^aria-[\-\w]+$/),
                    B = a(/^(?:(?:(?:f|ht)tps?|mailto|tel|callto|cid|xmpp):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i),
                    H = a(/^(?:\w+script|data):/i),
                    W = a(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205f\u3000]/g),
                    V = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" === typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    };

                function U(e) {
                    if (Array.isArray(e)) {
                        for (var t = 0, n = Array(e.length); t < e.length; t++) n[t] = e[t];
                        return n
                    }
                    return Array.from(e)
                }
                var q = function() {
                        return "undefined" === typeof window ? null : window
                    },
                    G = function(e, t) {
                        if ("object" !== ("undefined" === typeof e ? "undefined" : V(e)) || "function" !== typeof e.createPolicy) return null;
                        var n = null;
                        t.currentScript && t.currentScript.hasAttribute("data-tt-policy-suffix") && (n = t.currentScript.getAttribute("data-tt-policy-suffix"));
                        var r = "dompurify" + (n ? "#" + n : "");
                        try {
                            return e.createPolicy(r, {
                                createHTML: function(e) {
                                    return e
                                }
                            })
                        } catch (o) {
                            return console.warn("TrustedTypes policy " + r + " could not be created."), null
                        }
                    };
                return function e() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : q(),
                        n = function(t) {
                            return e(t)
                        };
                    if (n.version = "2.0.8", n.removed = [], !t || !t.document || 9 !== t.document.nodeType) return n.isSupported = !1, n;
                    var a = t.document,
                        i = !1,
                        s = !1,
                        c = t.document,
                        j = t.DocumentFragment,
                        k = t.HTMLTemplateElement,
                        Y = t.Node,
                        Q = t.NodeFilter,
                        K = t.NamedNodeMap,
                        Z = void 0 === K ? t.NamedNodeMap || t.MozNamedAttrMap : K,
                        X = t.Text,
                        $ = t.Comment,
                        J = t.DOMParser,
                        ee = t.trustedTypes;
                    if ("function" === typeof k) {
                        var te = c.createElement("template");
                        te.content && te.content.ownerDocument && (c = te.content.ownerDocument)
                    }
                    var ne = G(ee, a),
                        re = ne ? ne.createHTML("") : "",
                        oe = c,
                        ae = oe.implementation,
                        ie = oe.createNodeIterator,
                        se = oe.getElementsByTagName,
                        ce = oe.createDocumentFragment,
                        ue = a.importNode,
                        le = {};
                    n.isSupported = ae && "undefined" !== typeof ae.createHTMLDocument && 9 !== c.documentMode;
                    var de = _,
                        fe = F,
                        pe = z,
                        be = I,
                        he = H,
                        me = W,
                        ge = B,
                        ve = null,
                        ye = M({}, [].concat(U(C), U(S), U(E), U(R), U(D))),
                        we = null,
                        xe = M({}, [].concat(U(N), U(T), U(P), U(L))),
                        Oe = null,
                        je = null,
                        ke = !0,
                        Me = !0,
                        Ae = !1,
                        Ce = !1,
                        Se = !1,
                        Ee = !1,
                        Re = !1,
                        De = !1,
                        Ne = !1,
                        Te = !1,
                        Pe = !1,
                        Le = !1,
                        _e = !0,
                        Fe = !0,
                        ze = !1,
                        Ie = {},
                        Be = M({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]),
                        He = M({}, ["audio", "video", "img", "source", "image"]),
                        We = null,
                        Ve = M({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "summary", "title", "value", "style", "xmlns"]),
                        Ue = null,
                        qe = c.createElement("form"),
                        Ge = function(e) {
                            Ue && Ue === e || (e && "object" === ("undefined" === typeof e ? "undefined" : V(e)) || (e = {}), ve = "ALLOWED_TAGS" in e ? M({}, e.ALLOWED_TAGS) : ye, we = "ALLOWED_ATTR" in e ? M({}, e.ALLOWED_ATTR) : xe, We = "ADD_URI_SAFE_ATTR" in e ? M(A(Ve), e.ADD_URI_SAFE_ATTR) : Ve, Oe = "FORBID_TAGS" in e ? M({}, e.FORBID_TAGS) : {}, je = "FORBID_ATTR" in e ? M({}, e.FORBID_ATTR) : {}, Ie = "USE_PROFILES" in e && e.USE_PROFILES, ke = !1 !== e.ALLOW_ARIA_ATTR, Me = !1 !== e.ALLOW_DATA_ATTR, Ae = e.ALLOW_UNKNOWN_PROTOCOLS || !1, Ce = e.SAFE_FOR_JQUERY || !1, Se = e.SAFE_FOR_TEMPLATES || !1, Ee = e.WHOLE_DOCUMENT || !1, Ne = e.RETURN_DOM || !1, Te = e.RETURN_DOM_FRAGMENT || !1, Pe = e.RETURN_DOM_IMPORT || !1, Le = e.RETURN_TRUSTED_TYPE || !1, De = e.FORCE_BODY || !1, _e = !1 !== e.SANITIZE_DOM, Fe = !1 !== e.KEEP_CONTENT, ze = e.IN_PLACE || !1, ge = e.ALLOWED_URI_REGEXP || ge, Se && (Me = !1), Te && (Ne = !0), Ie && (ve = M({}, [].concat(U(D))), we = [], !0 === Ie.html && (M(ve, C), M(we, N)), !0 === Ie.svg && (M(ve, S), M(we, T), M(we, L)), !0 === Ie.svgFilters && (M(ve, E), M(we, T), M(we, L)), !0 === Ie.mathMl && (M(ve, R), M(we, P), M(we, L))), e.ADD_TAGS && (ve === ye && (ve = A(ve)), M(ve, e.ADD_TAGS)), e.ADD_ATTR && (we === xe && (we = A(we)), M(we, e.ADD_ATTR)), e.ADD_URI_SAFE_ATTR && M(We, e.ADD_URI_SAFE_ATTR), Fe && (ve["#text"] = !0), Ee && M(ve, ["html", "head", "body"]), ve.table && (M(ve, ["tbody"]), delete Oe.tbody), o && o(e), Ue = e)
                        },
                        Ye = function(e) {
                            p(n.removed, {
                                element: e
                            });
                            try {
                                e.parentNode.removeChild(e)
                            } catch (t) {
                                e.outerHTML = re
                            }
                        },
                        Qe = function(e, t) {
                            try {
                                p(n.removed, {
                                    attribute: t.getAttributeNode(e),
                                    from: t
                                })
                            } catch (r) {
                                p(n.removed, {
                                    attribute: null,
                                    from: t
                                })
                            }
                            t.removeAttribute(e)
                        },
                        Ke = function(e) {
                            var t = void 0,
                                n = void 0;
                            if (De) e = "<remove></remove>" + e;
                            else {
                                var r = m(e, /^[\s]+/);
                                n = r && r[0]
                            }
                            var o = ne ? ne.createHTML(e) : e;
                            if (i) try {
                                t = (new J).parseFromString(o, "text/html")
                            } catch (u) {}
                            if (s && M(Oe, ["title"]), !t || !t.documentElement) {
                                var a = (t = ae.createHTMLDocument("")).body;
                                a.parentNode.removeChild(a.parentNode.firstElementChild), a.outerHTML = o
                            }
                            return e && n && t.body.insertBefore(c.createTextNode(n), t.body.childNodes[0] || null), se.call(t, Ee ? "html" : "body")[0]
                        };
                    n.isSupported && (function() {
                        try {
                            Ke('<svg><p><textarea><img src="</textarea><img src=x abc=1//">').querySelector("svg img") && (i = !0)
                        } catch (e) {}
                    }(), function() {
                        try {
                            var e = Ke("<x/><title>&lt;/title&gt;&lt;img&gt;");
                            w(/<\/title/, e.querySelector("title").innerHTML) && (s = !0)
                        } catch (t) {}
                    }());
                    var Ze = function(e) {
                            return ie.call(e.ownerDocument || e, e, Q.SHOW_ELEMENT | Q.SHOW_COMMENT | Q.SHOW_TEXT, (function() {
                                return Q.FILTER_ACCEPT
                            }), !1)
                        },
                        Xe = function(e) {
                            return !(e instanceof X || e instanceof $) && !("string" === typeof e.nodeName && "string" === typeof e.textContent && "function" === typeof e.removeChild && e.attributes instanceof Z && "function" === typeof e.removeAttribute && "function" === typeof e.setAttribute && "string" === typeof e.namespaceURI)
                        },
                        $e = function(e) {
                            return "object" === ("undefined" === typeof Y ? "undefined" : V(Y)) ? e instanceof Y : e && "object" === ("undefined" === typeof e ? "undefined" : V(e)) && "number" === typeof e.nodeType && "string" === typeof e.nodeName
                        },
                        Je = function(e, t, r) {
                            le[e] && u(le[e], (function(e) {
                                e.call(n, t, r, Ue)
                            }))
                        },
                        et = function(e) {
                            var t = void 0;
                            if (Je("beforeSanitizeElements", e, null), Xe(e)) return Ye(e), !0;
                            var r = h(e.nodeName);
                            if (Je("uponSanitizeElement", e, {
                                    tagName: r,
                                    allowedTags: ve
                                }), ("svg" === r || "math" === r) && 0 !== e.querySelectorAll("p, br").length) return Ye(e), !0;
                            if (!ve[r] || Oe[r]) {
                                if (Fe && !Be[r] && "function" === typeof e.insertAdjacentHTML) try {
                                    var o = e.innerHTML;
                                    e.insertAdjacentHTML("AfterEnd", ne ? ne.createHTML(o) : o)
                                } catch (a) {}
                                return Ye(e), !0
                            }
                            return "noscript" === r && w(/<\/noscript/i, e.innerHTML) || "noembed" === r && w(/<\/noembed/i, e.innerHTML) ? (Ye(e), !0) : (!Ce || e.firstElementChild || e.content && e.content.firstElementChild || !w(/</g, e.textContent) || (p(n.removed, {
                                element: e.cloneNode()
                            }), e.innerHTML ? e.innerHTML = g(e.innerHTML, /</g, "&lt;") : e.innerHTML = g(e.textContent, /</g, "&lt;")), Se && 3 === e.nodeType && (t = e.textContent, t = g(t, de, " "), t = g(t, fe, " "), e.textContent !== t && (p(n.removed, {
                                element: e.cloneNode()
                            }), e.textContent = t)), Je("afterSanitizeElements", e, null), !1)
                        },
                        tt = function(e, t, n) {
                            if (_e && ("id" === t || "name" === t) && (n in c || n in qe)) return !1;
                            if (Me && w(pe, t));
                            else if (ke && w(be, t));
                            else {
                                if (!we[t] || je[t]) return !1;
                                if (We[t]);
                                else if (w(ge, g(n, me, "")));
                                else if ("src" !== t && "xlink:href" !== t && "href" !== t || "script" === e || 0 !== v(n, "data:") || !He[e])
                                    if (Ae && !w(he, g(n, me, "")));
                                    else if (n) return !1
                            }
                            return !0
                        },
                        nt = function(e) {
                            var t = void 0,
                                o = void 0,
                                a = void 0,
                                i = void 0,
                                s = void 0;
                            Je("beforeSanitizeAttributes", e, null);
                            var c = e.attributes;
                            if (c) {
                                var u = {
                                    attrName: "",
                                    attrValue: "",
                                    keepAttr: !0,
                                    allowedAttributes: we
                                };
                                for (s = c.length; s--;) {
                                    var p = t = c[s],
                                        m = p.name,
                                        v = p.namespaceURI;
                                    if (o = y(t.value), a = h(m), u.attrName = a, u.attrValue = o, u.keepAttr = !0, u.forceKeepAttr = void 0, Je("uponSanitizeAttribute", e, u), o = u.attrValue, !u.forceKeepAttr) {
                                        if ("name" === a && "IMG" === e.nodeName && c.id) i = c.id, c = b(c, []), Qe("id", e), Qe(m, e), l(c, i) > s && e.setAttribute("id", i.value);
                                        else {
                                            if ("INPUT" === e.nodeName && "type" === a && "file" === o && u.keepAttr && (we[a] || !je[a])) continue;
                                            "id" === m && e.setAttribute(m, ""), Qe(m, e)
                                        }
                                        if (u.keepAttr)
                                            if (Ce && w(/\/>/i, o)) Qe(m, e);
                                            else if (w(/svg|math/i, e.namespaceURI) && w(x("</(" + d(r(Be), "|") + ")", "i"), o)) Qe(m, e);
                                        else {
                                            Se && (o = g(o, de, " "), o = g(o, fe, " "));
                                            var O = e.nodeName.toLowerCase();
                                            if (tt(O, a, o)) try {
                                                v ? e.setAttributeNS(v, m, o) : e.setAttribute(m, o), f(n.removed)
                                            } catch (j) {}
                                        }
                                    }
                                }
                                Je("afterSanitizeAttributes", e, null)
                            }
                        },
                        rt = function e(t) {
                            var n = void 0,
                                r = Ze(t);
                            for (Je("beforeSanitizeShadowDOM", t, null); n = r.nextNode();) Je("uponSanitizeShadowNode", n, null), et(n) || (n.content instanceof j && e(n.content), nt(n));
                            Je("afterSanitizeShadowDOM", t, null)
                        };
                    return n.sanitize = function(e, r) {
                        var o = void 0,
                            i = void 0,
                            s = void 0,
                            c = void 0,
                            u = void 0;
                        if (e || (e = "\x3c!--\x3e"), "string" !== typeof e && !$e(e)) {
                            if ("function" !== typeof e.toString) throw O("toString is not a function");
                            if ("string" !== typeof(e = e.toString())) throw O("dirty is not a string, aborting")
                        }
                        if (!n.isSupported) {
                            if ("object" === V(t.toStaticHTML) || "function" === typeof t.toStaticHTML) {
                                if ("string" === typeof e) return t.toStaticHTML(e);
                                if ($e(e)) return t.toStaticHTML(e.outerHTML)
                            }
                            return e
                        }
                        if (Re || Ge(r), n.removed = [], "string" === typeof e && (ze = !1), ze);
                        else if (e instanceof Y) 1 === (i = (o = Ke("\x3c!--\x3e")).ownerDocument.importNode(e, !0)).nodeType && "BODY" === i.nodeName || "HTML" === i.nodeName ? o = i : o.appendChild(i);
                        else {
                            if (!Ne && !Se && !Ee && Le && -1 === e.indexOf("<")) return ne ? ne.createHTML(e) : e;
                            if (!(o = Ke(e))) return Ne ? null : re
                        }
                        o && De && Ye(o.firstChild);
                        for (var l = Ze(ze ? e : o); s = l.nextNode();) 3 === s.nodeType && s === c || et(s) || (s.content instanceof j && rt(s.content), nt(s), c = s);
                        if (c = null, ze) return e;
                        if (Ne) {
                            if (Te)
                                for (u = ce.call(o.ownerDocument); o.firstChild;) u.appendChild(o.firstChild);
                            else u = o;
                            return Pe && (u = ue.call(a, u, !0)), u
                        }
                        var d = Ee ? o.outerHTML : o.innerHTML;
                        return Se && (d = g(d, de, " "), d = g(d, fe, " ")), ne && Le ? ne.createHTML(d) : d
                    }, n.setConfig = function(e) {
                        Ge(e), Re = !0
                    }, n.clearConfig = function() {
                        Ue = null, Re = !1
                    }, n.isValidAttribute = function(e, t, n) {
                        Ue || Ge({});
                        var r = h(e),
                            o = h(t);
                        return tt(r, o, n)
                    }, n.addHook = function(e, t) {
                        "function" === typeof t && (le[e] = le[e] || [], p(le[e], t))
                    }, n.removeHook = function(e) {
                        le[e] && f(le[e])
                    }, n.removeHooks = function(e) {
                        le[e] && (le[e] = [])
                    }, n.removeAllHooks = function() {
                        le = {}
                    }, n
                }()
            }()
        },
        348: function(e, t) {
            function n() {
                return e.exports = n = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }, n.apply(this, arguments)
            }
            e.exports = n
        },
        349: function(e, t) {
            e.exports = function(e, t) {
                if (null == e) return {};
                var n, r, o = {},
                    a = Object.keys(e);
                for (r = 0; r < a.length; r++) n = a[r], t.indexOf(n) >= 0 || (o[n] = e[n]);
                return o
            }
        },
        350: function(e, t) {
            e.exports = function(e, t) {
                e.prototype = Object.create(t.prototype), e.prototype.constructor = e, e.__proto__ = t
            }
        },
        351: function(e, t) {
            e.exports = function(e) {
                if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e
            }
        },
        352: function(e, t, n) {
            "use strict";
            var r = n(122),
                o = n(34),
                a = n(353),
                i = n(208),
                s = n(20),
                c = n(84),
                u = n(209);
            e.exports = function(e) {
                var t, n, l, d, f, p, b = o(e),
                    h = "function" == typeof this ? this : Array,
                    m = arguments.length,
                    g = m > 1 ? arguments[1] : void 0,
                    v = void 0 !== g,
                    y = u(b),
                    w = 0;
                if (v && (g = r(g, m > 2 ? arguments[2] : void 0, 2)), void 0 == y || h == Array && i(y))
                    for (n = new h(t = s(b.length)); t > w; w++) p = v ? g(b[w], w) : b[w], c(n, w, p);
                else
                    for (f = (d = y.call(b)).next, n = new h; !(l = f.call(d)).done; w++) p = v ? a(d, g, [l.value, w], !0) : l.value, c(n, w, p);
                return n.length = w, n
            }
        },
        353: function(e, t, n) {
            var r = n(16),
                o = n(210);
            e.exports = function(e, t, n, a) {
                try {
                    return a ? t(r(n)[0], n[1]) : t(n)
                } catch (i) {
                    throw o(e), i
                }
            }
        },
        354: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                return (0, o.default)(1, arguments), (0, r.default)(e, Date.now())
            };
            var r = a(n(331)),
                o = a(n(313));

            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            e.exports = t.default
        },
        355: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                (0, o.default)(1, arguments);
                var t = (0, r.default)(e);
                return t.setHours(0, 0, 0, 0), t
            };
            var r = a(n(314)),
                o = a(n(313));

            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            e.exports = t.default
        },
        356: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                return (0, a.default)(1, arguments), (0, r.default)(e, (0, o.default)(Date.now(), 1))
            };
            var r = i(n(331)),
                o = i(n(357)),
                a = i(n(313));

            function i(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            e.exports = t.default
        },
        357: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e, t) {
                (0, a.default)(2, arguments);
                var n = (0, r.default)(t);
                return (0, o.default)(e, -n)
            };
            var r = i(n(321)),
                o = i(n(358)),
                a = i(n(313));

            function i(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            e.exports = t.default
        },
        358: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e, t) {
                (0, a.default)(2, arguments);
                var n = (0, o.default)(e),
                    i = (0, r.default)(t);
                if (isNaN(i)) return new Date(NaN);
                if (!i) return n;
                return n.setDate(n.getDate() + i), n
            };
            var r = i(n(321)),
                o = i(n(314)),
                a = i(n(313));

            function i(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            e.exports = t.default
        },
        359: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e, t, n) {
                (0, f.default)(2, arguments);
                var p = String(t),
                    m = n || {},
                    g = m.locale || o.default,
                    w = g.options && g.options.firstWeekContainsDate,
                    x = null == w ? 1 : (0, d.default)(w),
                    O = null == m.firstWeekContainsDate ? x : (0, d.default)(m.firstWeekContainsDate);
                if (!(O >= 1 && O <= 7)) throw new RangeError("firstWeekContainsDate must be between 1 and 7 inclusively");
                var j = g.options && g.options.weekStartsOn,
                    k = null == j ? 0 : (0, d.default)(j),
                    M = null == m.weekStartsOn ? k : (0, d.default)(m.weekStartsOn);
                if (!(M >= 0 && M <= 6)) throw new RangeError("weekStartsOn must be between 0 and 6 inclusively");
                if (!g.localize) throw new RangeError("locale must contain localize property");
                if (!g.formatLong) throw new RangeError("locale must contain formatLong property");
                var A = (0, i.default)(e);
                if (!(0, r.default)(A)) throw new RangeError("Invalid time value");
                var C = (0, u.default)(A),
                    S = (0, a.default)(A, C),
                    E = {
                        firstWeekContainsDate: O,
                        weekStartsOn: M,
                        locale: g,
                        _originalDate: A
                    },
                    R = p.match(h).map((function(e) {
                        var t = e[0];
                        return "p" === t || "P" === t ? (0, c.default[t])(e, g.formatLong, E) : e
                    })).join("").match(b).map((function(n) {
                        if ("''" === n) return "'";
                        var r = n[0];
                        if ("'" === r) return y(n);
                        var o = s.default[r];
                        if (o) return !m.useAdditionalWeekYearTokens && (0, l.isProtectedWeekYearToken)(n) && (0, l.throwProtectedError)(n, t, e), !m.useAdditionalDayOfYearTokens && (0, l.isProtectedDayOfYearToken)(n) && (0, l.throwProtectedError)(n, t, e), o(S, n, g.localize, E);
                        if (r.match(v)) throw new RangeError("Format string contains an unescaped latin alphabet character `" + r + "`");
                        return n
                    })).join("");
                return R
            };
            var r = p(n(360)),
                o = p(n(361)),
                a = p(n(371)),
                i = p(n(314)),
                s = p(n(373)),
                c = p(n(380)),
                u = p(n(381)),
                l = n(382),
                d = p(n(321)),
                f = p(n(313));

            function p(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            var b = /[yYQqMLwIdDecihHKkms]o|(\w)\1*|''|'(''|[^'])+('|$)|./g,
                h = /P+p+|P+|p+|''|'(''|[^'])+('|$)|./g,
                m = /^'([^]*?)'?$/,
                g = /''/g,
                v = /[a-zA-Z]/;

            function y(e) {
                return e.match(m)[1].replace(g, "'")
            }
            e.exports = t.default
        },
        360: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                (0, o.default)(1, arguments);
                var t = (0, r.default)(e);
                return !isNaN(t)
            };
            var r = a(n(314)),
                o = a(n(313));

            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            e.exports = t.default
        },
        361: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = c(n(362)),
                o = c(n(363)),
                a = c(n(365)),
                i = c(n(366)),
                s = c(n(368));

            function c(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            var u = {
                code: "en-US",
                formatDistance: r.default,
                formatLong: o.default,
                formatRelative: a.default,
                localize: i.default,
                match: s.default,
                options: {
                    weekStartsOn: 0,
                    firstWeekContainsDate: 1
                }
            };
            t.default = u, e.exports = t.default
        },
        362: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e, t, n) {
                var o;
                n = n || {}, o = "string" === typeof r[e] ? r[e] : 1 === t ? r[e].one : r[e].other.replace("{{count}}", t);
                if (n.addSuffix) return n.comparison > 0 ? "in " + o : o + " ago";
                return o
            };
            var r = {
                lessThanXSeconds: {
                    one: "less than a second",
                    other: "less than {{count}} seconds"
                },
                xSeconds: {
                    one: "1 second",
                    other: "{{count}} seconds"
                },
                halfAMinute: "half a minute",
                lessThanXMinutes: {
                    one: "less than a minute",
                    other: "less than {{count}} minutes"
                },
                xMinutes: {
                    one: "1 minute",
                    other: "{{count}} minutes"
                },
                aboutXHours: {
                    one: "about 1 hour",
                    other: "about {{count}} hours"
                },
                xHours: {
                    one: "1 hour",
                    other: "{{count}} hours"
                },
                xDays: {
                    one: "1 day",
                    other: "{{count}} days"
                },
                aboutXWeeks: {
                    one: "about 1 week",
                    other: "about {{count}} weeks"
                },
                xWeeks: {
                    one: "1 week",
                    other: "{{count}} weeks"
                },
                aboutXMonths: {
                    one: "about 1 month",
                    other: "about {{count}} months"
                },
                xMonths: {
                    one: "1 month",
                    other: "{{count}} months"
                },
                aboutXYears: {
                    one: "about 1 year",
                    other: "about {{count}} years"
                },
                xYears: {
                    one: "1 year",
                    other: "{{count}} years"
                },
                overXYears: {
                    one: "over 1 year",
                    other: "over {{count}} years"
                },
                almostXYears: {
                    one: "almost 1 year",
                    other: "almost {{count}} years"
                }
            };
            e.exports = t.default
        },
        363: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r, o = (r = n(364)) && r.__esModule ? r : {
                default: r
            };
            var a = {
                date: (0, o.default)({
                    formats: {
                        full: "EEEE, MMMM do, y",
                        long: "MMMM do, y",
                        medium: "MMM d, y",
                        short: "MM/dd/yyyy"
                    },
                    defaultWidth: "full"
                }),
                time: (0, o.default)({
                    formats: {
                        full: "h:mm:ss a zzzz",
                        long: "h:mm:ss a z",
                        medium: "h:mm:ss a",
                        short: "h:mm a"
                    },
                    defaultWidth: "full"
                }),
                dateTime: (0, o.default)({
                    formats: {
                        full: "{{date}} 'at' {{time}}",
                        long: "{{date}} 'at' {{time}}",
                        medium: "{{date}}, {{time}}",
                        short: "{{date}}, {{time}}"
                    },
                    defaultWidth: "full"
                })
            };
            t.default = a, e.exports = t.default
        },
        364: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                return function(t) {
                    var n = t || {},
                        r = n.width ? String(n.width) : e.defaultWidth;
                    return e.formats[r] || e.formats[e.defaultWidth]
                }
            }, e.exports = t.default
        },
        365: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e, t, n, o) {
                return r[e]
            };
            var r = {
                lastWeek: "'last' eeee 'at' p",
                yesterday: "'yesterday at' p",
                today: "'today at' p",
                tomorrow: "'tomorrow at' p",
                nextWeek: "eeee 'at' p",
                other: "P"
            };
            e.exports = t.default
        },
        366: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r, o = (r = n(367)) && r.__esModule ? r : {
                default: r
            };
            var a = {
                ordinalNumber: function(e, t) {
                    var n = Number(e),
                        r = n % 100;
                    if (r > 20 || r < 10) switch (r % 10) {
                        case 1:
                            return n + "st";
                        case 2:
                            return n + "nd";
                        case 3:
                            return n + "rd"
                    }
                    return n + "th"
                },
                era: (0, o.default)({
                    values: {
                        narrow: ["B", "A"],
                        abbreviated: ["BC", "AD"],
                        wide: ["Before Christ", "Anno Domini"]
                    },
                    defaultWidth: "wide"
                }),
                quarter: (0, o.default)({
                    values: {
                        narrow: ["1", "2", "3", "4"],
                        abbreviated: ["Q1", "Q2", "Q3", "Q4"],
                        wide: ["1st quarter", "2nd quarter", "3rd quarter", "4th quarter"]
                    },
                    defaultWidth: "wide",
                    argumentCallback: function(e) {
                        return Number(e) - 1
                    }
                }),
                month: (0, o.default)({
                    values: {
                        narrow: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
                        abbreviated: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                        wide: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
                    },
                    defaultWidth: "wide"
                }),
                day: (0, o.default)({
                    values: {
                        narrow: ["S", "M", "T", "W", "T", "F", "S"],
                        short: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
                        abbreviated: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                        wide: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
                    },
                    defaultWidth: "wide"
                }),
                dayPeriod: (0, o.default)({
                    values: {
                        narrow: {
                            am: "a",
                            pm: "p",
                            midnight: "mi",
                            noon: "n",
                            morning: "morning",
                            afternoon: "afternoon",
                            evening: "evening",
                            night: "night"
                        },
                        abbreviated: {
                            am: "AM",
                            pm: "PM",
                            midnight: "midnight",
                            noon: "noon",
                            morning: "morning",
                            afternoon: "afternoon",
                            evening: "evening",
                            night: "night"
                        },
                        wide: {
                            am: "a.m.",
                            pm: "p.m.",
                            midnight: "midnight",
                            noon: "noon",
                            morning: "morning",
                            afternoon: "afternoon",
                            evening: "evening",
                            night: "night"
                        }
                    },
                    defaultWidth: "wide",
                    formattingValues: {
                        narrow: {
                            am: "a",
                            pm: "p",
                            midnight: "mi",
                            noon: "n",
                            morning: "in the morning",
                            afternoon: "in the afternoon",
                            evening: "in the evening",
                            night: "at night"
                        },
                        abbreviated: {
                            am: "AM",
                            pm: "PM",
                            midnight: "midnight",
                            noon: "noon",
                            morning: "in the morning",
                            afternoon: "in the afternoon",
                            evening: "in the evening",
                            night: "at night"
                        },
                        wide: {
                            am: "a.m.",
                            pm: "p.m.",
                            midnight: "midnight",
                            noon: "noon",
                            morning: "in the morning",
                            afternoon: "in the afternoon",
                            evening: "in the evening",
                            night: "at night"
                        }
                    },
                    defaultFormattingWidth: "wide"
                })
            };
            t.default = a, e.exports = t.default
        },
        367: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                return function(t, n) {
                    var r, o = n || {};
                    if ("formatting" === (o.context ? String(o.context) : "standalone") && e.formattingValues) {
                        var a = e.defaultFormattingWidth || e.defaultWidth,
                            i = o.width ? String(o.width) : a;
                        r = e.formattingValues[i] || e.formattingValues[a]
                    } else {
                        var s = e.defaultWidth,
                            c = o.width ? String(o.width) : e.defaultWidth;
                        r = e.values[c] || e.values[s]
                    }
                    return r[e.argumentCallback ? e.argumentCallback(t) : t]
                }
            }, e.exports = t.default
        },
        368: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = a(n(369)),
                o = a(n(370));

            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            var i = {
                ordinalNumber: (0, r.default)({
                    matchPattern: /^(\d+)(th|st|nd|rd)?/i,
                    parsePattern: /\d+/i,
                    valueCallback: function(e) {
                        return parseInt(e, 10)
                    }
                }),
                era: (0, o.default)({
                    matchPatterns: {
                        narrow: /^(b|a)/i,
                        abbreviated: /^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i,
                        wide: /^(before christ|before common era|anno domini|common era)/i
                    },
                    defaultMatchWidth: "wide",
                    parsePatterns: {
                        any: [/^b/i, /^(a|c)/i]
                    },
                    defaultParseWidth: "any"
                }),
                quarter: (0, o.default)({
                    matchPatterns: {
                        narrow: /^[1234]/i,
                        abbreviated: /^q[1234]/i,
                        wide: /^[1234](th|st|nd|rd)? quarter/i
                    },
                    defaultMatchWidth: "wide",
                    parsePatterns: {
                        any: [/1/i, /2/i, /3/i, /4/i]
                    },
                    defaultParseWidth: "any",
                    valueCallback: function(e) {
                        return e + 1
                    }
                }),
                month: (0, o.default)({
                    matchPatterns: {
                        narrow: /^[jfmasond]/i,
                        abbreviated: /^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,
                        wide: /^(january|february|march|april|may|june|july|august|september|october|november|december)/i
                    },
                    defaultMatchWidth: "wide",
                    parsePatterns: {
                        narrow: [/^j/i, /^f/i, /^m/i, /^a/i, /^m/i, /^j/i, /^j/i, /^a/i, /^s/i, /^o/i, /^n/i, /^d/i],
                        any: [/^ja/i, /^f/i, /^mar/i, /^ap/i, /^may/i, /^jun/i, /^jul/i, /^au/i, /^s/i, /^o/i, /^n/i, /^d/i]
                    },
                    defaultParseWidth: "any"
                }),
                day: (0, o.default)({
                    matchPatterns: {
                        narrow: /^[smtwf]/i,
                        short: /^(su|mo|tu|we|th|fr|sa)/i,
                        abbreviated: /^(sun|mon|tue|wed|thu|fri|sat)/i,
                        wide: /^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i
                    },
                    defaultMatchWidth: "wide",
                    parsePatterns: {
                        narrow: [/^s/i, /^m/i, /^t/i, /^w/i, /^t/i, /^f/i, /^s/i],
                        any: [/^su/i, /^m/i, /^tu/i, /^w/i, /^th/i, /^f/i, /^sa/i]
                    },
                    defaultParseWidth: "any"
                }),
                dayPeriod: (0, o.default)({
                    matchPatterns: {
                        narrow: /^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,
                        any: /^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i
                    },
                    defaultMatchWidth: "any",
                    parsePatterns: {
                        any: {
                            am: /^a/i,
                            pm: /^p/i,
                            midnight: /^mi/i,
                            noon: /^no/i,
                            morning: /morning/i,
                            afternoon: /afternoon/i,
                            evening: /evening/i,
                            night: /night/i
                        }
                    },
                    defaultParseWidth: "any"
                })
            };
            t.default = i, e.exports = t.default
        },
        369: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                return function(t, n) {
                    var r = String(t),
                        o = n || {},
                        a = r.match(e.matchPattern);
                    if (!a) return null;
                    var i = a[0],
                        s = r.match(e.parsePattern);
                    if (!s) return null;
                    var c = e.valueCallback ? e.valueCallback(s[0]) : s[0];
                    return {
                        value: c = o.valueCallback ? o.valueCallback(c) : c,
                        rest: r.slice(i.length)
                    }
                }
            }, e.exports = t.default
        },
        370: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                return function(t, n) {
                    var r = String(t),
                        o = n || {},
                        a = o.width,
                        i = a && e.matchPatterns[a] || e.matchPatterns[e.defaultMatchWidth],
                        s = r.match(i);
                    if (!s) return null;
                    var c, u = s[0],
                        l = a && e.parsePatterns[a] || e.parsePatterns[e.defaultParseWidth];
                    return c = "[object Array]" === Object.prototype.toString.call(l) ? function(e, t) {
                        for (var n = 0; n < e.length; n++)
                            if (t(e[n])) return n
                    }(l, (function(e) {
                        return e.test(u)
                    })) : function(e, t) {
                        for (var n in e)
                            if (e.hasOwnProperty(n) && t(e[n])) return n
                    }(l, (function(e) {
                        return e.test(u)
                    })), c = e.valueCallback ? e.valueCallback(c) : c, {
                        value: c = o.valueCallback ? o.valueCallback(c) : c,
                        rest: r.slice(u.length)
                    }
                }
            }, e.exports = t.default
        },
        371: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e, t) {
                (0, a.default)(2, arguments);
                var n = (0, r.default)(t);
                return (0, o.default)(e, -n)
            };
            var r = i(n(321)),
                o = i(n(372)),
                a = i(n(313));

            function i(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            e.exports = t.default
        },
        372: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e, t) {
                (0, a.default)(2, arguments);
                var n = (0, o.default)(e).getTime(),
                    i = (0, r.default)(t);
                return new Date(n + i)
            };
            var r = i(n(321)),
                o = i(n(314)),
                a = i(n(313));

            function i(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            e.exports = t.default
        },
        373: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = l(n(374)),
                o = l(n(375)),
                a = l(n(376)),
                i = l(n(333)),
                s = l(n(378)),
                c = l(n(334)),
                u = l(n(332));

            function l(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            var d = "midnight",
                f = "noon",
                p = "morning",
                b = "afternoon",
                h = "evening",
                m = "night";

            function g(e, t) {
                var n = e > 0 ? "-" : "+",
                    r = Math.abs(e),
                    o = Math.floor(r / 60),
                    a = r % 60;
                if (0 === a) return n + String(o);
                var i = t || "";
                return n + String(o) + i + (0, u.default)(a, 2)
            }

            function v(e, t) {
                return e % 60 === 0 ? (e > 0 ? "-" : "+") + (0, u.default)(Math.abs(e) / 60, 2) : y(e, t)
            }

            function y(e, t) {
                var n = t || "",
                    r = e > 0 ? "-" : "+",
                    o = Math.abs(e);
                return r + (0, u.default)(Math.floor(o / 60), 2) + n + (0, u.default)(o % 60, 2)
            }
            var w = {
                G: function(e, t, n) {
                    var r = e.getUTCFullYear() > 0 ? 1 : 0;
                    switch (t) {
                        case "G":
                        case "GG":
                        case "GGG":
                            return n.era(r, {
                                width: "abbreviated"
                            });
                        case "GGGGG":
                            return n.era(r, {
                                width: "narrow"
                            });
                        case "GGGG":
                        default:
                            return n.era(r, {
                                width: "wide"
                            })
                    }
                },
                y: function(e, t, n) {
                    if ("yo" === t) {
                        var o = e.getUTCFullYear(),
                            a = o > 0 ? o : 1 - o;
                        return n.ordinalNumber(a, {
                            unit: "year"
                        })
                    }
                    return r.default.y(e, t)
                },
                Y: function(e, t, n, r) {
                    var o = (0, c.default)(e, r),
                        a = o > 0 ? o : 1 - o;
                    if ("YY" === t) {
                        var i = a % 100;
                        return (0, u.default)(i, 2)
                    }
                    return "Yo" === t ? n.ordinalNumber(a, {
                        unit: "year"
                    }) : (0, u.default)(a, t.length)
                },
                R: function(e, t) {
                    var n = (0, i.default)(e);
                    return (0, u.default)(n, t.length)
                },
                u: function(e, t) {
                    var n = e.getUTCFullYear();
                    return (0, u.default)(n, t.length)
                },
                Q: function(e, t, n) {
                    var r = Math.ceil((e.getUTCMonth() + 1) / 3);
                    switch (t) {
                        case "Q":
                            return String(r);
                        case "QQ":
                            return (0, u.default)(r, 2);
                        case "Qo":
                            return n.ordinalNumber(r, {
                                unit: "quarter"
                            });
                        case "QQQ":
                            return n.quarter(r, {
                                width: "abbreviated",
                                context: "formatting"
                            });
                        case "QQQQQ":
                            return n.quarter(r, {
                                width: "narrow",
                                context: "formatting"
                            });
                        case "QQQQ":
                        default:
                            return n.quarter(r, {
                                width: "wide",
                                context: "formatting"
                            })
                    }
                },
                q: function(e, t, n) {
                    var r = Math.ceil((e.getUTCMonth() + 1) / 3);
                    switch (t) {
                        case "q":
                            return String(r);
                        case "qq":
                            return (0, u.default)(r, 2);
                        case "qo":
                            return n.ordinalNumber(r, {
                                unit: "quarter"
                            });
                        case "qqq":
                            return n.quarter(r, {
                                width: "abbreviated",
                                context: "standalone"
                            });
                        case "qqqqq":
                            return n.quarter(r, {
                                width: "narrow",
                                context: "standalone"
                            });
                        case "qqqq":
                        default:
                            return n.quarter(r, {
                                width: "wide",
                                context: "standalone"
                            })
                    }
                },
                M: function(e, t, n) {
                    var o = e.getUTCMonth();
                    switch (t) {
                        case "M":
                        case "MM":
                            return r.default.M(e, t);
                        case "Mo":
                            return n.ordinalNumber(o + 1, {
                                unit: "month"
                            });
                        case "MMM":
                            return n.month(o, {
                                width: "abbreviated",
                                context: "formatting"
                            });
                        case "MMMMM":
                            return n.month(o, {
                                width: "narrow",
                                context: "formatting"
                            });
                        case "MMMM":
                        default:
                            return n.month(o, {
                                width: "wide",
                                context: "formatting"
                            })
                    }
                },
                L: function(e, t, n) {
                    var r = e.getUTCMonth();
                    switch (t) {
                        case "L":
                            return String(r + 1);
                        case "LL":
                            return (0, u.default)(r + 1, 2);
                        case "Lo":
                            return n.ordinalNumber(r + 1, {
                                unit: "month"
                            });
                        case "LLL":
                            return n.month(r, {
                                width: "abbreviated",
                                context: "standalone"
                            });
                        case "LLLLL":
                            return n.month(r, {
                                width: "narrow",
                                context: "standalone"
                            });
                        case "LLLL":
                        default:
                            return n.month(r, {
                                width: "wide",
                                context: "standalone"
                            })
                    }
                },
                w: function(e, t, n, r) {
                    var o = (0, s.default)(e, r);
                    return "wo" === t ? n.ordinalNumber(o, {
                        unit: "week"
                    }) : (0, u.default)(o, t.length)
                },
                I: function(e, t, n) {
                    var r = (0, a.default)(e);
                    return "Io" === t ? n.ordinalNumber(r, {
                        unit: "week"
                    }) : (0, u.default)(r, t.length)
                },
                d: function(e, t, n) {
                    return "do" === t ? n.ordinalNumber(e.getUTCDate(), {
                        unit: "date"
                    }) : r.default.d(e, t)
                },
                D: function(e, t, n) {
                    var r = (0, o.default)(e);
                    return "Do" === t ? n.ordinalNumber(r, {
                        unit: "dayOfYear"
                    }) : (0, u.default)(r, t.length)
                },
                E: function(e, t, n) {
                    var r = e.getUTCDay();
                    switch (t) {
                        case "E":
                        case "EE":
                        case "EEE":
                            return n.day(r, {
                                width: "abbreviated",
                                context: "formatting"
                            });
                        case "EEEEE":
                            return n.day(r, {
                                width: "narrow",
                                context: "formatting"
                            });
                        case "EEEEEE":
                            return n.day(r, {
                                width: "short",
                                context: "formatting"
                            });
                        case "EEEE":
                        default:
                            return n.day(r, {
                                width: "wide",
                                context: "formatting"
                            })
                    }
                },
                e: function(e, t, n, r) {
                    var o = e.getUTCDay(),
                        a = (o - r.weekStartsOn + 8) % 7 || 7;
                    switch (t) {
                        case "e":
                            return String(a);
                        case "ee":
                            return (0, u.default)(a, 2);
                        case "eo":
                            return n.ordinalNumber(a, {
                                unit: "day"
                            });
                        case "eee":
                            return n.day(o, {
                                width: "abbreviated",
                                context: "formatting"
                            });
                        case "eeeee":
                            return n.day(o, {
                                width: "narrow",
                                context: "formatting"
                            });
                        case "eeeeee":
                            return n.day(o, {
                                width: "short",
                                context: "formatting"
                            });
                        case "eeee":
                        default:
                            return n.day(o, {
                                width: "wide",
                                context: "formatting"
                            })
                    }
                },
                c: function(e, t, n, r) {
                    var o = e.getUTCDay(),
                        a = (o - r.weekStartsOn + 8) % 7 || 7;
                    switch (t) {
                        case "c":
                            return String(a);
                        case "cc":
                            return (0, u.default)(a, t.length);
                        case "co":
                            return n.ordinalNumber(a, {
                                unit: "day"
                            });
                        case "ccc":
                            return n.day(o, {
                                width: "abbreviated",
                                context: "standalone"
                            });
                        case "ccccc":
                            return n.day(o, {
                                width: "narrow",
                                context: "standalone"
                            });
                        case "cccccc":
                            return n.day(o, {
                                width: "short",
                                context: "standalone"
                            });
                        case "cccc":
                        default:
                            return n.day(o, {
                                width: "wide",
                                context: "standalone"
                            })
                    }
                },
                i: function(e, t, n) {
                    var r = e.getUTCDay(),
                        o = 0 === r ? 7 : r;
                    switch (t) {
                        case "i":
                            return String(o);
                        case "ii":
                            return (0, u.default)(o, t.length);
                        case "io":
                            return n.ordinalNumber(o, {
                                unit: "day"
                            });
                        case "iii":
                            return n.day(r, {
                                width: "abbreviated",
                                context: "formatting"
                            });
                        case "iiiii":
                            return n.day(r, {
                                width: "narrow",
                                context: "formatting"
                            });
                        case "iiiiii":
                            return n.day(r, {
                                width: "short",
                                context: "formatting"
                            });
                        case "iiii":
                        default:
                            return n.day(r, {
                                width: "wide",
                                context: "formatting"
                            })
                    }
                },
                a: function(e, t, n) {
                    var r = e.getUTCHours() / 12 >= 1 ? "pm" : "am";
                    switch (t) {
                        case "a":
                        case "aa":
                            return n.dayPeriod(r, {
                                width: "abbreviated",
                                context: "formatting"
                            });
                        case "aaa":
                            return n.dayPeriod(r, {
                                width: "abbreviated",
                                context: "formatting"
                            }).toLowerCase();
                        case "aaaaa":
                            return n.dayPeriod(r, {
                                width: "narrow",
                                context: "formatting"
                            });
                        case "aaaa":
                        default:
                            return n.dayPeriod(r, {
                                width: "wide",
                                context: "formatting"
                            })
                    }
                },
                b: function(e, t, n) {
                    var r, o = e.getUTCHours();
                    switch (r = 12 === o ? f : 0 === o ? d : o / 12 >= 1 ? "pm" : "am", t) {
                        case "b":
                        case "bb":
                            return n.dayPeriod(r, {
                                width: "abbreviated",
                                context: "formatting"
                            });
                        case "bbb":
                            return n.dayPeriod(r, {
                                width: "abbreviated",
                                context: "formatting"
                            }).toLowerCase();
                        case "bbbbb":
                            return n.dayPeriod(r, {
                                width: "narrow",
                                context: "formatting"
                            });
                        case "bbbb":
                        default:
                            return n.dayPeriod(r, {
                                width: "wide",
                                context: "formatting"
                            })
                    }
                },
                B: function(e, t, n) {
                    var r, o = e.getUTCHours();
                    switch (r = o >= 17 ? h : o >= 12 ? b : o >= 4 ? p : m, t) {
                        case "B":
                        case "BB":
                        case "BBB":
                            return n.dayPeriod(r, {
                                width: "abbreviated",
                                context: "formatting"
                            });
                        case "BBBBB":
                            return n.dayPeriod(r, {
                                width: "narrow",
                                context: "formatting"
                            });
                        case "BBBB":
                        default:
                            return n.dayPeriod(r, {
                                width: "wide",
                                context: "formatting"
                            })
                    }
                },
                h: function(e, t, n) {
                    if ("ho" === t) {
                        var o = e.getUTCHours() % 12;
                        return 0 === o && (o = 12), n.ordinalNumber(o, {
                            unit: "hour"
                        })
                    }
                    return r.default.h(e, t)
                },
                H: function(e, t, n) {
                    return "Ho" === t ? n.ordinalNumber(e.getUTCHours(), {
                        unit: "hour"
                    }) : r.default.H(e, t)
                },
                K: function(e, t, n) {
                    var r = e.getUTCHours() % 12;
                    return "Ko" === t ? n.ordinalNumber(r, {
                        unit: "hour"
                    }) : (0, u.default)(r, t.length)
                },
                k: function(e, t, n) {
                    var r = e.getUTCHours();
                    return 0 === r && (r = 24), "ko" === t ? n.ordinalNumber(r, {
                        unit: "hour"
                    }) : (0, u.default)(r, t.length)
                },
                m: function(e, t, n) {
                    return "mo" === t ? n.ordinalNumber(e.getUTCMinutes(), {
                        unit: "minute"
                    }) : r.default.m(e, t)
                },
                s: function(e, t, n) {
                    return "so" === t ? n.ordinalNumber(e.getUTCSeconds(), {
                        unit: "second"
                    }) : r.default.s(e, t)
                },
                S: function(e, t) {
                    return r.default.S(e, t)
                },
                X: function(e, t, n, r) {
                    var o = (r._originalDate || e).getTimezoneOffset();
                    if (0 === o) return "Z";
                    switch (t) {
                        case "X":
                            return v(o);
                        case "XXXX":
                        case "XX":
                            return y(o);
                        case "XXXXX":
                        case "XXX":
                        default:
                            return y(o, ":")
                    }
                },
                x: function(e, t, n, r) {
                    var o = (r._originalDate || e).getTimezoneOffset();
                    switch (t) {
                        case "x":
                            return v(o);
                        case "xxxx":
                        case "xx":
                            return y(o);
                        case "xxxxx":
                        case "xxx":
                        default:
                            return y(o, ":")
                    }
                },
                O: function(e, t, n, r) {
                    var o = (r._originalDate || e).getTimezoneOffset();
                    switch (t) {
                        case "O":
                        case "OO":
                        case "OOO":
                            return "GMT" + g(o, ":");
                        case "OOOO":
                        default:
                            return "GMT" + y(o, ":")
                    }
                },
                z: function(e, t, n, r) {
                    var o = (r._originalDate || e).getTimezoneOffset();
                    switch (t) {
                        case "z":
                        case "zz":
                        case "zzz":
                            return "GMT" + g(o, ":");
                        case "zzzz":
                        default:
                            return "GMT" + y(o, ":")
                    }
                },
                t: function(e, t, n, r) {
                    var o = r._originalDate || e,
                        a = Math.floor(o.getTime() / 1e3);
                    return (0, u.default)(a, t.length)
                },
                T: function(e, t, n, r) {
                    var o = (r._originalDate || e).getTime();
                    return (0, u.default)(o, t.length)
                }
            };
            t.default = w, e.exports = t.default
        },
        374: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r, o = (r = n(332)) && r.__esModule ? r : {
                default: r
            };
            var a = {
                y: function(e, t) {
                    var n = e.getUTCFullYear(),
                        r = n > 0 ? n : 1 - n;
                    return (0, o.default)("yy" === t ? r % 100 : r, t.length)
                },
                M: function(e, t) {
                    var n = e.getUTCMonth();
                    return "M" === t ? String(n + 1) : (0, o.default)(n + 1, 2)
                },
                d: function(e, t) {
                    return (0, o.default)(e.getUTCDate(), t.length)
                },
                a: function(e, t) {
                    var n = e.getUTCHours() / 12 >= 1 ? "pm" : "am";
                    switch (t) {
                        case "a":
                        case "aa":
                            return n.toUpperCase();
                        case "aaa":
                            return n;
                        case "aaaaa":
                            return n[0];
                        case "aaaa":
                        default:
                            return "am" === n ? "a.m." : "p.m."
                    }
                },
                h: function(e, t) {
                    return (0, o.default)(e.getUTCHours() % 12 || 12, t.length)
                },
                H: function(e, t) {
                    return (0, o.default)(e.getUTCHours(), t.length)
                },
                m: function(e, t) {
                    return (0, o.default)(e.getUTCMinutes(), t.length)
                },
                s: function(e, t) {
                    return (0, o.default)(e.getUTCSeconds(), t.length)
                },
                S: function(e, t) {
                    var n = t.length,
                        r = e.getUTCMilliseconds(),
                        a = Math.floor(r * Math.pow(10, n - 3));
                    return (0, o.default)(a, t.length)
                }
            };
            t.default = a, e.exports = t.default
        },
        375: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                (0, o.default)(1, arguments);
                var t = (0, r.default)(e),
                    n = t.getTime();
                t.setUTCMonth(0, 1), t.setUTCHours(0, 0, 0, 0);
                var a = t.getTime(),
                    i = n - a;
                return Math.floor(i / 864e5) + 1
            };
            var r = a(n(314)),
                o = a(n(313));

            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            e.exports = t.default
        },
        376: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                (0, i.default)(1, arguments);
                var t = (0, r.default)(e),
                    n = (0, o.default)(t).getTime() - (0, a.default)(t).getTime();
                return Math.round(n / 6048e5) + 1
            };
            var r = s(n(314)),
                o = s(n(326)),
                a = s(n(377)),
                i = s(n(313));

            function s(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            e.exports = t.default
        },
        377: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                (0, a.default)(1, arguments);
                var t = (0, r.default)(e),
                    n = new Date(0);
                n.setUTCFullYear(t, 0, 4), n.setUTCHours(0, 0, 0, 0);
                var i = (0, o.default)(n);
                return i
            };
            var r = i(n(333)),
                o = i(n(326)),
                a = i(n(313));

            function i(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            e.exports = t.default
        },
        378: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e, t) {
                (0, i.default)(1, arguments);
                var n = (0, r.default)(e),
                    s = (0, o.default)(n, t).getTime() - (0, a.default)(n, t).getTime();
                return Math.round(s / 6048e5) + 1
            };
            var r = s(n(314)),
                o = s(n(327)),
                a = s(n(379)),
                i = s(n(313));

            function s(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            e.exports = t.default
        },
        379: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e, t) {
                (0, i.default)(1, arguments);
                var n = t || {},
                    s = n.locale,
                    c = s && s.options && s.options.firstWeekContainsDate,
                    u = null == c ? 1 : (0, r.default)(c),
                    l = null == n.firstWeekContainsDate ? u : (0, r.default)(n.firstWeekContainsDate),
                    d = (0, o.default)(e, t),
                    f = new Date(0);
                f.setUTCFullYear(d, 0, l), f.setUTCHours(0, 0, 0, 0);
                var p = (0, a.default)(f, t);
                return p
            };
            var r = s(n(321)),
                o = s(n(334)),
                a = s(n(327)),
                i = s(n(313));

            function s(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }
            e.exports = t.default
        },
        380: function(e, t, n) {
            "use strict";

            function r(e, t) {
                switch (e) {
                    case "P":
                        return t.date({
                            width: "short"
                        });
                    case "PP":
                        return t.date({
                            width: "medium"
                        });
                    case "PPP":
                        return t.date({
                            width: "long"
                        });
                    case "PPPP":
                    default:
                        return t.date({
                            width: "full"
                        })
                }
            }

            function o(e, t) {
                switch (e) {
                    case "p":
                        return t.time({
                            width: "short"
                        });
                    case "pp":
                        return t.time({
                            width: "medium"
                        });
                    case "ppp":
                        return t.time({
                            width: "long"
                        });
                    case "pppp":
                    default:
                        return t.time({
                            width: "full"
                        })
                }
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = {
                p: o,
                P: function(e, t) {
                    var n, a = e.match(/(P+)(p+)?/),
                        i = a[1],
                        s = a[2];
                    if (!s) return r(e, t);
                    switch (i) {
                        case "P":
                            n = t.dateTime({
                                width: "short"
                            });
                            break;
                        case "PP":
                            n = t.dateTime({
                                width: "medium"
                            });
                            break;
                        case "PPP":
                            n = t.dateTime({
                                width: "long"
                            });
                            break;
                        case "PPPP":
                        default:
                            n = t.dateTime({
                                width: "full"
                            })
                    }
                    return n.replace("{{date}}", r(i, t)).replace("{{time}}", o(s, t))
                }
            };
            t.default = a, e.exports = t.default
        },
        381: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                var t = new Date(e.getTime()),
                    n = Math.ceil(t.getTimezoneOffset());
                t.setSeconds(0, 0);
                var o = n > 0 ? (6e4 + r(t)) % 6e4 : r(t);
                return 6e4 * n + o
            };

            function r(e) {
                return e.getTime() % 6e4
            }
            e.exports = t.default
        },
        382: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.isProtectedDayOfYearToken = function(e) {
                return -1 !== r.indexOf(e)
            }, t.isProtectedWeekYearToken = function(e) {
                return -1 !== o.indexOf(e)
            }, t.throwProtectedError = function(e, t, n) {
                if ("YYYY" === e) throw new RangeError("Use `yyyy` instead of `YYYY` (in `".concat(t, "`) for formatting years to the input `").concat(n, "`; see: https://git.io/fxCyr"));
                if ("YY" === e) throw new RangeError("Use `yy` instead of `YY` (in `".concat(t, "`) for formatting years to the input `").concat(n, "`; see: https://git.io/fxCyr"));
                if ("D" === e) throw new RangeError("Use `d` instead of `D` (in `".concat(t, "`) for formatting days of the month to the input `").concat(n, "`; see: https://git.io/fxCyr"));
                if ("DD" === e) throw new RangeError("Use `dd` instead of `DD` (in `".concat(t, "`) for formatting days of the month to the input `").concat(n, "`; see: https://git.io/fxCyr"))
            };
            var r = ["D", "DD"],
                o = ["YY", "YYYY"]
        },
        383: function(e, t, n) {
            e.exports = n(335)
        },
        384: function(e, t) {
            function n(e, t, n, r, o, a, i) {
                try {
                    var s = e[a](i),
                        c = s.value
                } catch (u) {
                    return void n(u)
                }
                s.done ? t(c) : Promise.resolve(c).then(r, o)
            }
            e.exports = function(e) {
                return function() {
                    var t = this,
                        r = arguments;
                    return new Promise((function(o, a) {
                        var i = e.apply(t, r);

                        function s(e) {
                            n(i, o, a, s, c, "next", e)
                        }

                        function c(e) {
                            n(i, o, a, s, c, "throw", e)
                        }
                        s(void 0)
                    }))
                }
            }
        },
        385: function(e, t, n) {
            "use strict";
            var r = n(9),
                o = n(386);
            r({
                target: "String",
                proto: !0,
                forced: n(387)("link")
            }, {
                link: function(e) {
                    return o(this, "a", "href", e)
                }
            })
        },
        386: function(e, t, n) {
            var r = n(26),
                o = /"/g;
            e.exports = function(e, t, n, a) {
                var i = String(r(e)),
                    s = "<" + t;
                return "" !== n && (s += " " + n + '="' + String(a).replace(o, "&quot;") + '"'), s + ">" + i + "</" + t + ">"
            }
        },
        387: function(e, t, n) {
            var r = n(10);
            e.exports = function(e) {
                return r((function() {
                    var t = "" [e]('"');
                    return t !== t.toLowerCase() || t.split('"').length > 3
                }))
            }
        },
        388: function(e, t, n) {
            "use strict";
            var r = n(9),
                o = n(86).every,
                a = n(85),
                i = n(35),
                s = a("every"),
                c = i("every");
            r({
                target: "Array",
                proto: !0,
                forced: !s || !c
            }, {
                every: function(e) {
                    return o(this, e, arguments.length > 1 ? arguments[1] : void 0)
                }
            })
        },
        389: function(e, t, n) {
            var r = n(9),
                o = n(212).entries;
            r({
                target: "Object",
                stat: !0
            }, {
                entries: function(e) {
                    return o(e)
                }
            })
        },
        390: function(e, t, n) {
            "use strict";
            var r = n(19),
                o = n(8),
                a = n(83),
                i = n(30),
                s = n(17),
                c = n(39),
                u = n(213),
                l = n(56),
                d = n(10),
                f = n(154),
                p = n(99).f,
                b = n(55).f,
                h = n(27).f,
                m = n(123).trim,
                g = o.Number,
                v = g.prototype,
                y = "Number" == c(f(v)),
                w = function(e) {
                    var t, n, r, o, a, i, s, c, u = l(e, !1);
                    if ("string" == typeof u && u.length > 2)
                        if (43 === (t = (u = m(u)).charCodeAt(0)) || 45 === t) {
                            if (88 === (n = u.charCodeAt(2)) || 120 === n) return NaN
                        } else if (48 === t) {
                        switch (u.charCodeAt(1)) {
                            case 66:
                            case 98:
                                r = 2, o = 49;
                                break;
                            case 79:
                            case 111:
                                r = 8, o = 55;
                                break;
                            default:
                                return +u
                        }
                        for (i = (a = u.slice(2)).length, s = 0; s < i; s++)
                            if ((c = a.charCodeAt(s)) < 48 || c > o) return NaN;
                        return parseInt(a, r)
                    }
                    return +u
                };
            if (a("Number", !g(" 0o1") || !g("0b1") || g("+0x1"))) {
                for (var x, O = function(e) {
                        var t = arguments.length < 1 ? 0 : e,
                            n = this;
                        return n instanceof O && (y ? d((function() {
                            v.valueOf.call(n)
                        })) : "Number" != c(n)) ? u(new g(w(t)), n, O) : w(t)
                    }, j = r ? p(g) : "MAX_VALUE,MIN_VALUE,NaN,NEGATIVE_INFINITY,POSITIVE_INFINITY,EPSILON,isFinite,isInteger,isNaN,isSafeInteger,MAX_SAFE_INTEGER,MIN_SAFE_INTEGER,parseFloat,parseInt,isInteger,fromString,range".split(","), k = 0; j.length > k; k++) s(g, x = j[k]) && !s(O, x) && h(O, x, b(g, x));
                O.prototype = v, v.constructor = O, i(o, "Number", O)
            }
        },
        391: function(e, t, n) {
            var r = n(336),
                o = n(392),
                a = n(393),
                i = n(394),
                s = n(395);
            (t = r(!1)).i(o);
            var c = a(i),
                u = a(s);
            t.push([e.i, ".chat,.start-group{width:372px;position:absolute;bottom:26px;border-radius:16px;pointer-events:auto;box-shadow:0 8px 22px 0 rgba(0,18,46,0.16);overflow:hidden;z-index:1;right:48px;left:auto}.chat.chrome,.start-group.chrome{box-shadow:0 8px 36px 0 rgba(0,18,46,0.16)}.chat.safari,.start-group.safari{box-shadow:0 8px 30px 0 rgba(0,18,46,0.16)}.chat-on-site .chat,.chat-on-site .start-group{box-shadow:0 8px 26px 0 rgba(0,18,46,0.16)}.chat-in-preview .chat,.chat-in-preview .start-group{box-shadow:0 8px 18px 0 rgba(0,18,46,0.16)}textarea{border:0;width:100%;font-size:17px;padding:20px 0 14px 0;resize:none;line-height:24px;overflow-x:hidden;-ms-overflow-style:none}@-webkit-keyframes shake{10%,90%{transform:translateX(1px)}20%,80%{transform:translateX(-1px)}30%,50%,70%{transform:translateX(2px)}40%,60%{transform:translateX(-2px)}}@keyframes shake{10%,90%{transform:translateX(1px)}20%,80%{transform:translateX(-1px)}30%,50%,70%{transform:translateX(2px)}40%,60%{transform:translateX(-2px)}}button,button.material-icons{background:none;border:0;color:inherit;font:inherit;line-height:normal;overflow:visible;padding:0;-webkit-user-select:none;-moz-user-select:none;user-select:none;outline:none;cursor:pointer;-webkit-tap-highlight-color:rgba(0,0,0,0)}button.material-icons::-moz-focus-inner{border:0;padding:0}button.link{border-bottom:1px solid #444}body{overflow:hidden;margin:0}svg{fill:#fff;transition:all 0.2s ease-in-out}#button{position:absolute;width:112px;height:140px;bottom:12px;display:flex;align-items:center;justify-content:center;pointer-events:none;z-index:1;/*! @noflip */right:0}#button:not(.sidebar) .buttonWave{position:absolute;z-index:-1;width:60px;height:60px}#button:not(.sidebar) .buttonWave:after{content:'';position:absolute;width:60px;height:60px;border-radius:50%;background-color:#147fff;opacity:0.5}#button:not(.sidebar).clicked .buttonWave:after{-webkit-animation:buttonWave 0.5s ease-out;animation:buttonWave 0.5s ease-out}#button.chat-open:not(.sidebar){right:0;left:auto}#button button.disabled i.type1 svg{fill:#fff}#button button i{height:26px;width:26px;position:absolute;opacity:0;transition:all 0.2s ease-in-out;display:flex;align-items:center;justify-content:center}#button button i.active{opacity:1}#button button i.type1 svg{fill:currentColor}#button button i.type1::after{content:'';position:absolute;width:68px;height:68px;border-radius:32px;background:#fff;transition:all 0.2s ease-in-out;transform:scale(0)}#button button i.type1.for-opened{width:31px;height:28px}#button button i.type1.for-opened svg{width:28px;height:28px;/*! @noflip */margin-left:3px}#button button i.type2{width:32px;height:32px}#button button i.type2 svg{width:32px;height:32px;fill:currentColor;transform:scale(0)}#button button i.for-closed{/*! @noflip */transform:translateX(-10px)}#button button i.for-closed.active{/*! @noflip */transform:translateX(0)}#button button i.for-opened{/*! @noflip */transform:translateX(10px)}#button button i.for-opened.active{/*! @noflip */transform:translateX(0)}body:not(.mobile) #button button:hover i.type1 svg,body:not(.mobile) #button button:focus i.type1 svg{transform:scale(1.4)}body:not(.mobile) #button button:hover i.type1::after,body:not(.mobile) #button button:focus i.type1::after{transform:scale(1)}body:not(.mobile) #button button:hover i.type2 svg,body:not(.mobile) #button button:focus i.type2 svg{transform:scale(1)}body:not(.mobile) #button .sidebar-content:hover ~ #button-body{transform:scale(1.15)}body:not(.mobile) #button .sidebar-content:hover ~ button i.type1 svg{transform:scale(1.4)}body:not(.mobile) #button .sidebar-content:hover ~ button i.type1::after{transform:scale(1)}body:not(.mobile) #button .sidebar-content:hover ~ button i.type2 svg{transform:scale(1)}#button.sidebar{width:50px;pointer-events:auto}#button.sidebar svg{width:15px;height:15px}.sidebar-position-left #button.sidebar{/*! @noflip */left:0;/*! @noflip */right:auto}.sidebar-position-left #button.sidebar .sidebar-content{/*! @noflip */transform-origin:left top;/*! @noflip */transform:rotate(270deg);/*! @noflip */left:0;/*! @noflip */right:auto;/*! @noflip */border-bottom-right-radius:4px;/*! @noflip */border-bottom-left-radius:28px;/*! @noflip */padding:0 20px 0 30px}.sidebar-position-left #button.sidebar #button-body{/*! @noflip */left:7px}#button.sidebar .sidebar-content{background:#313fa0;color:#fff;/*! @noflip */padding:0 30px 0 20px;font-size:14px;line-height:30px;height:30px;font-weight:700;position:relative;overflow:hidden;/*! @noflip */border-bottom-right-radius:28px;/*! @noflip */border-bottom-left-radius:4px;/*! @noflip */transform:rotate(90deg);/*! @noflip */transform-origin:right top;position:absolute;bottom:0;/*! @noflip */right:0;white-space:nowrap;max-width:400px}#button.sidebar .sidebar-content span{display:inline-block;transform:rotate(180deg);max-width:265px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden}#button.sidebar .sidebar-content:hover{cursor:pointer}#button.sidebar #button-body{position:absolute;/*! @noflip */right:7px;bottom:20px;width:32px;height:32px;box-shadow:0 6px 20px 0 rgba(0,18,46,0.24)}#button.sidebar button i{width:15px;height:15px}#button.sidebar button i.type1::after{width:30px;height:30px;border-radius:28px}#button.sidebar button i.type2 svg{width:15px;height:15px}#button-body{width:60px;height:60px;border-radius:28px;display:inherit;align-items:center;justify-content:center;pointer-events:initial;background-size:130% 130%;transition:all 0.2s ease-in-out;position:relative}#button-body.disabled{cursor:not-allowed}#button-body:hover,#button-body:focus{outline:none}body:not(.mobile) #button-body:hover,body:not(.mobile) #button-body:focus{transform:scale(1.1)}#new-message,#dnd-indicator{position:absolute;top:37px;font-weight:700;color:#fff;right:23px;pointer-events:none;border-radius:10px;display:flex;justify-content:center;align-items:center;width:20px;height:20px}#new-message{font-size:12px;background:#f72e38;z-index:2;line-height:1}#new-message+#dnd-indicator{right:12px}#new-message.active{-webkit-animation:shake 0.82s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;animation:shake 0.82s cubic-bezier(0.36, 0.07, 0.19, 0.97) both}#dnd-indicator{background:#374ca6;z-index:1}#dnd-indicator svg{width:12px;height:12px}@-webkit-keyframes buttonWave{99%{transform:scale(2);opacity:0}100%{transform:scale(1);opacity:0}}@keyframes buttonWave{99%{transform:scale(2);opacity:0}100%{transform:scale(1);opacity:0}}*:focus{outline:thin dotted}.chat{max-height:calc(100% - 47px);display:flex;flex-direction:column}svg{width:24px;height:24px}.chat-header{padding:24px 28px 0;background:linear-gradient(-61deg, #00e0d8, #201d8e);position:relative;z-index:4;flex:0 0 auto}.chat-header #ic-minimize{padding:3px 0;transform:rotate(270deg) translate(3px, 0)}.chat ::-webkit-scrollbar{display:none}.avatars-wrapper{width:52px;height:52px;margin:0px 18px 0 0;float:left}.operators-avatar-2{padding-top:11px}.operators-avatar-0{display:none}.header-ava{width:52px;height:52px;border-radius:24px;background-size:cover;background-position:center;background-image:url(" + c + ");float:left}.mobile .header-ava{width:42px;height:42px;border-radius:19px}.operators-avatar-2 .header-ava{width:30px;height:30px;margin-left:-6px}.operators-avatar-3 .header-ava{width:28px;height:28px}.operators-avatar-3 .header-ava:last-child{margin-left:-5px}.operators-avatar-3 .header-ava:first-child{clear:both;float:none;margin:0 auto}.operators-avatar-3 .header-ava:not(:first-child){margin-top:-4px}.operators-avatar-4 .header-ava{width:28px;height:28px}.operators-avatar-4 .header-ava:nth-child(2n){margin-left:-5px}.operators-avatar-4 .header-ava:nth-child(n+3){margin-top:-4px}.mobile .operators-avatar-2 .header-ava{width:26px;height:26px}.mobile .operators-avatar-3 .header-ava{width:23px;height:23px}.mobile .operators-avatar-3 .header-ava:first-child{margin-top:2px}.mobile .operators-avatar-4 .header-ava{width:23px;height:23px}.mobile .operators-avatar-4 .header-ava:nth-child(-n+2){margin-top:2px}.chat h2{font-size:22px;font-weight:600;color:currentColor;margin:4px 0 0 0;padding:0;display:inline-block;position:relative;max-width:calc(100% - 145px);text-overflow:ellipsis;white-space:nowrap;overflow:hidden;vertical-align:bottom}.chat h2 .emoji{width:31px;height:31px}.chat h2.oneline{margin-top:0;line-height:52px;min-height:52px}.chat h2.twolines{margin-bottom:5px}.chat h2 .top-heading{font-size:16px;display:block;line-height:15px;margin-top:4px}.heading-hover{position:absolute;color:#fff;background:rgba(0,0,0,0.88);top:70px;font-size:13px;padding:10px 15px;z-index:3;width:auto;border-radius:8px;max-width:100%;opacity:0;transition:opacity 0.3s ease-in-out;left:50px}.chat h2:hover+.heading-hover{opacity:1}#conversation-group{padding:0 28px;width:100%;height:357px;overflow-y:auto;overflow-x:hidden;-ms-overflow-style:none;background:#fff;transition:all 0.3s;max-height:357px;min-height:160px;flex:0 1 auto}#conversation-group.ios-ipad{-webkit-overflow-scrolling:touch;width:calc(100% + 6px);/*! @noflip */margin-right:0}.lang-rtl #conversation-group.ios-ipad{/*! @noflip */margin-right:-6px}#conversation-group .uploadIconWrapper{position:absolute;display:flex;height:100%;width:100%;align-items:center;justify-content:center;top:0;left:0;right:0;z-index:3}#conversation-group .uploadIconWrapper span{font-size:19px;max-width:120px;text-align:center;color:#080f1a;line-height:1.3}#conversation-group .uploadIconWrapper .ic_upload{fill:#287efc;width:73px;height:73px;margin-bottom:10px;margin-top:-5px}#conversation-group .upload-circle{width:230px;height:230px;border-radius:50%;background:rgba(182,198,229,0.24);display:flex;flex-direction:column;align-items:center;justify-content:center;-webkit-animation:scale-up 0.3s ease;animation:scale-up 0.3s ease;position:relative;z-index:1}#conversation-group.drag-active::after{content:'';position:absolute;width:100%;height:100%;top:0;left:0;right:0;bottom:0;background:rgba(255,255,255,0.92);z-index:2;-webkit-animation:fade-in 0.3s ease;animation:fade-in 0.3s ease}.transition-container #conversation-group{flex:1 1}.transition-container{height:399px;background:#fff;flex:0 1 auto;min-height:160px;position:relative;display:flex;flex-direction:column}.transition-container #conversation-group{overflow-y:hidden}#messages{position:relative;-ms-overflow-style:none;margin-top:10px;width:100%;padding-bottom:24px;float:left}#conversation-group #conversation-scroll{width:24px;height:calc(339px - 26px);position:absolute;right:2px;padding:0 12px 0 4px}#conversation-group #conversation-scroll div{width:6px;margin:0 1px;background:#00173b;opacity:0;top:0;position:absolute;border-radius:4px;cursor:pointer;transition:opacity 0.1s ease-in-out, width 0.1s ease-in-out, margin 0.1s ease-in-out;z-index:2;-webkit-user-select:none;-moz-user-select:none;user-select:none}body:not(.mobile) #conversation-group:hover #conversation-scroll div{opacity:0.16}body:not(.mobile) #conversation-group #conversation-scroll div:hover{opacity:0.32;width:8px;margin:0}hr{margin:0;border:0;border-bottom:1px solid #dbdfe6}input.disabled,textarea.disabled{cursor:not-allowed;color:#8894ab}button.material-icons,label.material-icons{position:relative;z-index:1;margin:15px 0 8px 11px;float:right}button.material-icons svg,label.material-icons svg{fill:#8894ab}button.material-icons svg#ic-minimize,button.material-icons svg.options-icon,label.material-icons svg#ic-minimize,label.material-icons svg.options-icon{fill:currentColor}button.material-icons::before,label.material-icons::before{content:'';position:absolute;background:#eff2f6;width:40px;height:40px;border-radius:50%;z-index:-1;transition:all 0.16s ease-in-out;transform:scale(0);top:calc(50% - 20px);left:calc(50% - 20px)}body:not(.mobile) button.material-icons:hover::before,body:not(.mobile) label.material-icons:hover::before{transform:scale(1)}button.material-icons:focus svg,label.material-icons:focus svg{fill:currentColor}button.material-icons:focus svg.bots-icon,label.material-icons:focus svg.bots-icon{fill:#007dfc}button.material-icons.disabled svg,button.material-icons.disabled:focus svg,label.material-icons.disabled svg,label.material-icons.disabled:focus svg{fill:#c9cbd8}button.material-icons.options,button.material-icons.exit-chat,label.material-icons.options,label.material-icons.exit-chat{z-index:unset}.mobile button.material-icons.options,.mobile button.material-icons.exit-chat,.mobile label.material-icons.options,.mobile label.material-icons.exit-chat{margin:5px -10px -2px 1px;padding:10px}button.material-icons.options svg,button.material-icons.exit-chat svg,label.material-icons.options svg,label.material-icons.exit-chat svg{fill:currentColor;width:26px;height:26px}button.material-icons.options::before,button.material-icons.exit-chat::before,label.material-icons.options::before,label.material-icons.exit-chat::before{background:rgba(0,36,92,0.16)}body:not(.mobile) button.material-icons.options:focus::before,body:not(.mobile) button.material-icons.options:hover::before,body:not(.mobile) button.material-icons.exit-chat:focus::before,body:not(.mobile) button.material-icons.exit-chat:hover::before,body:not(.mobile) label.material-icons.options:focus::before,body:not(.mobile) label.material-icons.options:hover::before,body:not(.mobile) label.material-icons.exit-chat:focus::before,body:not(.mobile) label.material-icons.exit-chat:hover::before{transform:scale(1)}button.material-icons.exit-chat,label.material-icons.exit-chat{margin-right:-3px}.mobile button.material-icons.exit-chat,.mobile label.material-icons.exit-chat{margin-right:-13px}body:not(.mobile) .footer-bottom .bots-button{margin-right:22px}body:not(.mobile) .footer-bottom .bots-button::after{content:'';display:block;position:absolute;top:2px;right:-12px;height:24px;width:1px;background:#dfe3e9}.input-group{padding:0 28px 6px;width:100%;position:relative;background:#fff;z-index:3;flex:0 0 auto}.input-group.drag-active .drag-active-wrapper::after{content:'';position:absolute;width:100%;height:100%;top:0;left:0;right:0;bottom:0;background:rgba(255,255,255,0.7);z-index:1;-webkit-animation:fade-in 0.3s ease;animation:fade-in 0.3s ease}.input-group.footer-disabled{background:#f0f2f7}.input-group.footer-disabled #new-message-textarea{background:transparent}.input-group.footer-disabled hr{display:none}.input-group .material-icons svg{width:26px;height:26px}.input-group .material-icons:hover svg{fill:#007dfc}.input-group .material-icons:hover::before{background-color:rgba(0,125,252,0.12)}.input-group .footer-bottom{height:42px;position:relative}.input-group .footer-bottom button{float:left;margin:0 16px 14px 0}.emoji-wrapper{height:215px;position:absolute;overflow:hidden;width:340px;bottom:100%;z-index:10;left:18px}.emoji-mart{border:0;position:absolute;width:100% !important;height:100%;right:0}.emoji-mart input:focus{border:1px solid #d9d9d9}.emoji-mart-scroll{height:140px}.emoji-mart .emoji-mart-emoji{cursor:pointer}.emoji-mart .emoji-mart-emoji span{cursor:pointer}.emoji-mart-anchor{-ms-flex:1 1 auto}.no-start-message .emoji-wrapper{height:175px}.no-start-message .emoji-mart-scroll{height:100px}.options-dropdown,.bots-dropdown{position:absolute;top:72px;background:#fff;border-radius:8px;box-shadow:0 6px 32px 0 rgba(0,18,46,0.16);padding:12px 6px;z-index:6;transition:all 0.2s ease-in-out;right:24px}.options-dropdown ul,.bots-dropdown ul{margin:0;padding:0}.options-dropdown ul li,.bots-dropdown ul li{border-radius:6px;display:flex}.options-dropdown ul li:nth-of-type(2) button svg,.bots-dropdown ul li:nth-of-type(2) button svg{fill:#ffb926}.options-dropdown li button,.bots-dropdown li button{padding:8px 16px;display:flex;margin:0;position:initial;float:initial;width:100%;border-radius:6px}body:not(.mobile) .options-dropdown li button:hover,body:not(.mobile) .bots-dropdown li button:hover,body:not(.mobile) .options-dropdown li button:focus,body:not(.mobile) .bots-dropdown li button:focus{background:#eff2f6}.options-dropdown li button svg,.bots-dropdown li button svg,.options-dropdown li button:focus svg,.bots-dropdown li button:focus svg{fill:#8894ab;height:22px;width:22px}.options-dropdown li button span,.bots-dropdown li button span{margin-left:10px;color:#06132b}.options-dropdown li button::before,.bots-dropdown li button::before{content:none}.bots-dropdown{top:auto;bottom:0;transform:translateY(-60px);max-height:275px;overflow-y:auto;z-index:11;right:auto;left:0px}.bots-dropdown button.material-icons{margin:0}.bots-dropdown ul li{padding:0}.bots-dropdown ul li span{cursor:pointer;padding:8px 16px;display:flex;align-items:center;width:100%}.bots-dropdown ul li span svg{margin-right:10px}.bots-dropdown ul li span.bot-disabled{cursor:not-allowed;color:#8894ab}.bots-dropdown ul.bots-cancel span{color:#0ab6ff;display:flex;align-items:center}.bots-dropdown ul.bots-cancel svg{fill:red;margin-right:10px}.offline-message{margin:18px -28px 0px;color:currentColor;width:calc(100% + 56px);padding:14px 28px 7px;position:relative;background-size:100% calc(100% + 12px);z-index:1}.no-clip-path .offline-message{padding:14px 28px 20px}.no-clip-path .offline-message:after{content:'';position:absolute;width:calc(100% + 10px);bottom:-8px;left:-5px;border-image-source:url(" + u + ");border-image-slice:0 0 100%;border-image-width:0 0 15px;border-image-repeat:stretch stretch;border-bottom:solid 15px;border-top:0;border-left:0;border-right:0}.offline-message span{z-index:2;position:relative;display:inline-block;font-size:16px}.offline-message span.online{padding-left:20px}.offline-message span.online:before{content:'';display:block;width:8px;height:8px;position:absolute;top:calc(50% - 4px);background:#58b743;border-radius:50%;left:0}.emoji-switch.active svg{fill:currentColor}.bots-animation svg{will-change:transform;-webkit-animation:botsAnimation 3s;animation:botsAnimation 3s;-webkit-animation-iteration-count:1;animation-iteration-count:1}.bots-animation .pulse,.bots-animation .pulse-white{will-change:transform;display:block;width:26px;height:26px;position:absolute;top:0;left:0;border-radius:50%;-webkit-animation-iteration-count:1;animation-iteration-count:1}.bots-animation .pulse{background:#c9cbd8;z-index:-4;-webkit-animation:waterPulse 3s;animation:waterPulse 3s}.bots-animation .pulse.animation-delay{z-index:-2}.bots-animation .pulse-white{background:#fff;z-index:-3;-webkit-animation:waterPulseWhite 3s;animation:waterPulseWhite 3s}.bots-animation .pulse-white.animation-delay{z-index:-1}.footer-disabled .bots-animation .pulse-white{background:#f0f2f7}.bots-animation .animation-delay{-webkit-animation-delay:0.8s;animation-delay:0.8s}@-webkit-keyframes waterPulseWhite{from{transform:scale(0.7)}29%{transform:scale(0.7)}60%{transform:scale(2.8)}}@keyframes waterPulseWhite{from{transform:scale(0.7)}29%{transform:scale(0.7)}60%{transform:scale(2.8)}}@-webkit-keyframes waterPulse{from{opacity:0;transform:scale(0.8)}19%{opacity:0.3}23%{transform:scale(0.8)}24%{opacity:0.5;transform:scale(0.8)}31%{opacity:0.4}55%{opacity:0.1;transform:scale(2.8)}100%{opacity:0}}@keyframes waterPulse{from{opacity:0;transform:scale(0.8)}19%{opacity:0.3}23%{transform:scale(0.8)}24%{opacity:0.5;transform:scale(0.8)}31%{opacity:0.4}55%{opacity:0.1;transform:scale(2.8)}100%{opacity:0}}@-webkit-keyframes botsAnimation{12%{transform:scale(1)}20%{transform:scale(1.2)}25%{transform:scale(0.9)}29%{transform:scale(1.05)}31%{transform:scale(1)}}@keyframes botsAnimation{12%{transform:scale(1)}20%{transform:scale(1.2)}25%{transform:scale(0.9)}29%{transform:scale(1.05)}31%{transform:scale(1)}}@-webkit-keyframes scale-up{0%{transform:scale(0.8)}100%{transform:scale(1)}}@keyframes scale-up{0%{transform:scale(0.8)}100%{transform:scale(1)}}@-webkit-keyframes fade-in{0%{opacity:0}100%{opacity:1}}@keyframes fade-in{0%{opacity:0}100%{opacity:1}}.chat-in-preview--tour .exit-chat,.chat-in-preview--tour .options-icon{opacity:0.3}.chat-in-preview--tour .input-group{opacity:0.4}.start-group{display:flex;flex-direction:column}.start-group .h2-banner{font-weight:400;font-size:42px;margin:6px 0 16px 0;padding-top:4px;display:inline-block;position:relative;max-width:calc(100% - 90px);line-height:50px;word-wrap:break-word;white-space:pre-line;-webkit-text-stroke:0.4px;padding-left:14px}.start-group .h2-banner .emoji{width:31px;height:31px}.start-group .operators{display:flex;position:absolute;top:84px;flex-direction:column;height:calc(100% - 84px);width:66px;right:42px}.start-group .operators>div:hover span{opacity:1}.start-group .operators>div:hover:not(:first-child) .ava48:hover{transform:translate3d(0, -20px, 0)}.start-group .ava48{width:66px;height:66px;border-radius:31px;background-size:cover;background-position:center;background-image:url(" + c + ");position:absolute;top:0;left:0;transition:transform 0.2s ease-in-out;will-change:transform;transform:translate3d(0, 0px, 0)}.start-group .ava48 span{background:#fff;padding:6px 8px;border-radius:2px;box-shadow:0 2px 8px 0 rgba(0,18,46,0.32);font-size:13px;position:absolute;opacity:0;white-space:nowrap;transition:all 0.16s ease-in-out;right:calc(100% + 10px);top:50%;transform:translateY(-50%);color:#06132b}.start-group button.i-banner svg{fill:currentColor}.start-group button.i-banner::before{background:rgba(0,36,92,0.16);width:38px;height:38px;top:calc(50% - 19px);left:calc(50% - 19px)}.start-group .get-started{width:100%;overflow:hidden;z-index:3;position:relative}.start-group .get-started button{color:#3f88f3;display:block;width:100%;padding:1em 0;background:#fff;border-radius:0;font-size:19px;transition:color 0.2s ease-in-out;margin:0}.start-group .input-group{z-index:4}.banner{width:100%;height:100%;position:absolute;top:0;left:0;border-radius:8px 8px 0 0;overflow:hidden;opacity:0.16;background-size:cover}.start-message{color:currentColor;font-size:16px;margin:0 0 32px 0;line-height:22px;position:relative;padding-left:14px;padding-right:100px;z-index:2}.user-data-modal{background:#fff;height:100%;width:100%;display:flex;justify-content:center;align-items:center;position:absolute;z-index:10;padding:50px 55px;background-image:linear-gradient(#fff, #fff),linear-gradient(#fff, #fff);background-size:100% 40px,100% calc(100% - 40px);background-repeat:no-repeat;background-position:top, bottom}.user-data-modal .user-data-modal-filler{width:280%;background-color:#fff;display:block;position:absolute;left:-90%;top:0;height:100%;z-index:-1;border-radius:0 0 53% 53%;background-clip:padding-box}.user-data-modal .user-data-modal-close{position:absolute;right:16px;top:16px}.user-data-modal .user-data-modal-close svg#ic_close{width:17px;height:17px;fill:#6d7e9e;position:static;top:10px;left:12px}.user-data-modal .pre-chat,.user-data-modal .always-online{max-width:100%}.user-data-modal .user-data-modal-text{font-size:20px;font-weight:600;text-align:center;color:#00122e;margin-bottom:32px}.user-data-modal .user-data-modal-fields #ic_arrow{fill:#007dfc}.user-data-modal .user-data-modal-fields svg{width:24px;height:24px}.user-data-modal .user-data-modal-fields input{border:solid 1px rgba(108,125,159,0.24);font-size:15px;padding:9px 12px 10px 40px;margin:0 0 8px 0}.user-data-modal .user-data-modal-fields label{padding-top:12px;padding-right:0;margin:0 0 8px 10px}.user-data-modal .user-data-modal-fields label input{margin-left:5px;margin-top:4px}.user-data-modal .user-data-modal-fields label span{font-size:11px;text-align:justify;color:#00122e;max-height:120px;display:block;overflow-y:auto}.user-data-modal .user-data-modal-fields label span a{color:#00122e}.user-data-modal .user-data-modal-submit{width:100%;height:40px;font-size:16px;font-weight:600;color:#ffffff;border-radius:6px;background:linear-gradient(99deg, #2a27da, #0cf);margin:16px 0;position:relative}.user-data-modal .user-data-modal-submit::after{transition:background 0.2s;content:'';border-radius:6px;background:rgba(0,0,0,0);left:0;top:0;position:absolute;width:100%;height:100%}.user-data-modal .user-data-modal-submit:hover::after{background:rgba(0,0,0,0.08)}.user-data-modal .user-data-modal-operators{text-align:center;white-space:nowrap;margin-bottom:32px}.user-data-modal .user-data-modal-operators .user-data-modal-operator{width:66px;height:66px;border-radius:31px;background-size:cover;background-position:center;display:inline-block;background-image:url(" + c + ");margin-right:-4%}.user-data-modal .emoji{margin:0}.flyMessage{background-color:#fff;padding:0 24px;max-width:340px;position:absolute;bottom:26px;border-radius:12px;box-shadow:0 8px 26px 0 rgba(0,18,46,0.16);display:flex;flex-direction:column;z-index:1;max-height:calc(100% - 76px);right:48px;margin-left:20px}.chat-in-preview .flyMessage{box-shadow:0 8px 13px 0 rgba(0,18,46,0.16)}.flyMessage:hover .close-button-wrapper{opacity:1;transform:translateY(0px)}.mobile .flyMessage{max-width:calc(100% - 48px - 55px)}.mobile .flyMessage.with-buttons{width:calc(100% - 48px - 55px);max-width:250px}.flyMessage .close-button-wrapper{position:absolute;bottom:100%;opacity:0;width:100%;height:45px;transition:all 0.3s;transform:translateY(10px);left:0}.mobile .flyMessage .close-button-wrapper{opacity:1;height:100%;width:45px;bottom:auto;top:0;transform:translateY(0);right:100%;left:auto;transform:translateX(-10px)}.flyMessage .close-button-wrapper button.material-icons.exit-chat.mobile-close{position:absolute;top:0;border-radius:50%;margin:0;padding:3px;box-shadow:0 3px 6px rgba(0,0,0,0.16),0 3px 6px rgba(0,0,0,0.23);height:24px;width:24px;display:flex;background:#fff;right:5px}.flyMessage .close-button-wrapper button.material-icons.exit-chat.mobile-close svg#ic_close{width:20px;height:20px;fill:#8894ab}.flyMessage .close-button-wrapper button.material-icons.exit-chat.mobile-close:before{content:none}.flyMessage .input-group{padding:9px 22px 9px 0}.flyMessage .material-icons.emoji-switch{position:absolute;top:0;right:36px}.flyMessage .material-icons.emoji-switch svg{width:20px;height:20px}.flyMessage .material-icons.emoji-switch:hover:before{width:32px;height:32px;margin:-6px 0 0 -6px}.flyMessage .emoji-wrapper{width:300px;left:auto;right:26px;border-radius:6px;box-shadow:0 1px 4px 0 rgba(0,0,0,0.14);left:auto;right:26px}.flyMessage .input-group .fly-new-message-button{transition:min-width 0.3s;min-width:180px;padding:4px 0 8px;line-height:21px;text-align:left;cursor:pointer;font-size:17px;color:#8894ab;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.flyMessage .input-group .fly-new-message-button::-webkit-input-placeholder{white-space:nowrap}.flyMessage .input-group .fly-new-message-button::-moz-placeholder{white-space:nowrap}.flyMessage .input-group .fly-new-message-button:-ms-input-placeholder{white-space:nowrap}.flyMessage .input-group .fly-new-message-button:-moz-placeholder{white-space:nowrap}.flyMessage.ie .message-container{max-height:300px}.flyMessage .message-container{padding:19px 0;max-width:290px;font-size:17px;background:#fff;position:relative;word-wrap:break-word;overflow:hidden;overflow-y:auto;white-space:pre-line;padding-right:38px}.flyMessage .message-container.image-content{overflow-y:hidden;padding-left:0;padding-right:0}.flyMessage .message-container.image-content button{float:left;height:200px;width:100%;min-width:200px;background-color:#fff}.flyMessage .message-container.image-content button .image-preview{background-size:cover;background-repeat:no-repeat;background-position:center;border-radius:8px;height:100%}.flyMessage .message-container.image-content span{display:inline-block;margin-top:10px}.mobile .flyMessage .message-container{width:100%;font-size:15px;padding-right:22px}.mobile .flyMessage .message-container.image-content{padding-left:0;padding-right:0}.mobile .flyMessage .message-container.image-content button{height:132px;min-width:auto}.flyMessage .message-container:after{content:'';border-bottom:1px solid #dedede;display:block;position:absolute;bottom:0;width:calc(100% - 38px)}.mobile .flyMessage .message-container:after{width:calc(100% - 22px)}.flyMessage .button-wrapper{width:100%;display:flex;flex-wrap:wrap}.mobile .flyMessage .button-wrapper{flex-direction:column;align-items:flex-start}.flyMessage .button-wrapper button,.flyMessage .button-wrapper .button-url{font-size:17px;color:#007dfc;background:#fff;line-height:21px;margin-top:6px;margin-bottom:6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;border-bottom:1px solid transparent;transition:border-color 0.2s;margin-right:16px;text-align:left}.flyMessage .button-wrapper button:hover,.flyMessage .button-wrapper .button-url:hover{border-color:#007dfc}.mobile .flyMessage .button-wrapper button,.mobile .flyMessage .button-wrapper .button-url{max-width:100%;display:block;padding:4px 0}.flyMessage .button-wrapper button .emoji,.flyMessage .button-wrapper .button-url .emoji{vertical-align:top}.flyMessage .button-wrapper .button-url__anchor{color:#007dfc;text-decoration:none}.flyMessage .button-wrapper .more-replies{border:1px solid #007dfc;border-radius:20px;padding:3px 10px;line-height:7px;align-self:center}.mobile .flyMessage .button-wrapper .more-replies{align-self:flex-start;padding:3px 10px;margin:6px 0}.flyMessage .button-wrapper .more-replies svg{transform:rotate(90deg);width:13px;height:13px;fill:#007dfc}.widgetLabel{position:absolute;height:42px;bottom:61px;z-index:1;white-space:nowrap;font-size:17px;line-height:17px;border-radius:16px;padding:10px 15px;box-shadow:0 6px 32px 0 rgba(0,18,46,0.24);background:#fff}.widget-position-left .widgetLabel{/*! @noflip */left:100px}.widget-position-right .widgetLabel{/*! @noflip */right:100px}.widgetLabel.hidden{display:none}.dropdownFade-enter{opacity:0.01;top:62px}.dropdownFade-enter.dropdownFade-enter-active{opacity:1;top:72px}.dropdownFade-exit{opacity:1;top:72px}.dropdownFade-exit.dropdownFade-exit-active{opacity:0.01;top:62px}.botsListFade-enter{opacity:0;transform:translateY(-52px)}.botsListFade-enter.botsListFade-enter-active{opacity:1;transform:translateY(-60px)}.botsListFade-appear{opacity:0;transform:translateY(-52px)}.botsListFade-appear.botsListFade-appear-active{opacity:1;transform:translateY(-60px)}.botsListFade-exit{opacity:1;transform:translateY(-60px)}.botsListFade-exit.botsListFade-exit-active{opacity:0;transform:translateY(-52px)}.fade-enter{opacity:0.01}.fade-enter.fade-enter-active{transition:all 0.3s;opacity:1}.fade-exit{opacity:1;transition:all 0.3s}.fade-exit.fade-exit-active{opacity:0.01}.fade200-enter{opacity:0.01}.fade200-enter.fade200-enter-active{transition:opacity 0.2s;opacity:1}.fade200-exit{opacity:1;transition:opacity 0.2s}.fade200-exit.fade200-exit-active{opacity:0.01}.emojiFade-enter{opacity:0.01;bottom:calc(100% - 10px)}.emojiFade-enter.emojiFade-enter-active{opacity:1;bottom:100%;transition:all 0.3s}.emojiFade-exit{opacity:1;bottom:100%;transition:all 0.3s}.emojiFade-exit.emojiFade-exit-active{opacity:0.01;bottom:calc(100% - 10px)}.scale-enter{transform:scale(0.01);opacity:0}.scale-enter.scale-enter-active{transform:scale(1);opacity:1}.scale-exit{transform:scale(1);opacity:1}.scale-exit.scale-exit-active{transform:scale(0.01);opacity:0}#button.sidebar{transition:all 0.3s}#button.sidebar.bubbleAnimation-appear{/*! @noflip */right:-8px;opacity:0.01}#button.sidebar.bubbleAnimation-appear-active{opacity:1;/*! @noflip */right:0}#button.sidebar.bubbleAnimation-enter{/*! @noflip */right:-8px;opacity:0.01}#button.sidebar.bubbleAnimation-enter-active{opacity:1;/*! @noflip */right:0}#button.sidebar.bubbleAnimation-exit{opacity:1;/*! @noflip */right:0}#button.sidebar.bubbleAnimation-exit-active{/*! @noflip */right:-8px;opacity:0.01}#button:not(.sidebar).bubbleAnimation-appear{right:-8px;opacity:0.01}#button:not(.sidebar).bubbleAnimation-appear.bubbleAnimation-appear-active{opacity:1;right:0;transition:all 0.3s}#button:not(.sidebar).bubbleAnimation-enter{right:-8px;opacity:0.01}#button:not(.sidebar).bubbleAnimation-enter.bubbleAnimation-enter-active{opacity:1;right:0;transition:all 0.3s}#button:not(.sidebar).bubbleAnimation-exit{opacity:1;right:0;transition:all 0.3s}.lang-rtl #button:not(.sidebar).bubbleAnimation-exit{display:none}#button:not(.sidebar).bubbleAnimation-exit.bubbleAnimation-exit-active{right:-8px;opacity:0.01}.widget-position-left #button:not(.sidebar).bubbleAnimation-appear{right:8px;opacity:0.01}.widget-position-left #button:not(.sidebar).bubbleAnimation-appear.bubbleAnimation-appear-active{opacity:1;right:0px;transition:all 0.3s}.widget-position-left #button:not(.sidebar).bubbleAnimation-enter{right:8px;opacity:0.01}.widget-position-left #button:not(.sidebar).bubbleAnimation-enter.bubbleAnimation-enter-active{opacity:1;right:0px;transition:all 0.3s}.widget-position-left #button:not(.sidebar).bubbleAnimation-exit{opacity:1;right:0px;transition:all 0.3s}.widget-position-left #button:not(.sidebar).bubbleAnimation-exit.bubbleAnimation-exit-active{right:8px;opacity:0.01}.mobile .widget-position-left #button:not(.sidebar).bubbleAnimation-appear{right:8px;opacity:0.01}.mobile .widget-position-left #button:not(.sidebar).bubbleAnimation-appear.bubbleAnimation-appear-active{opacity:1;right:0px;transition:all 0.3s}.mobile .widget-position-left #button:not(.sidebar).bubbleAnimation-enter{right:8px;opacity:0.01}.mobile .widget-position-left #button:not(.sidebar).bubbleAnimation-enter.bubbleAnimation-enter-active{opacity:1;right:0px;transition:all 0.3s}.mobile .widget-position-left #button:not(.sidebar).bubbleAnimation-exit{display:none}.mobile .widget-position-left #button:not(.sidebar).bubbleAnimationReturn-exit-active{display:none}.widget-position-left #button:not(.sidebar).bubbleAnimationReturn-appear{/*! @noflip */left:8px;opacity:0.01}.widget-position-left #button:not(.sidebar).bubbleAnimationReturn-appear.bubbleAnimationReturn-appear-active{opacity:1;/*! @noflip */left:0px;transition:all 0.2s}.widget-position-left #button:not(.sidebar).bubbleAnimationReturn-enter{/*! @noflip */left:8px;opacity:0.01}.widget-position-left #button:not(.sidebar).bubbleAnimationReturn-enter.bubbleAnimationReturn-enter-active{/*! @noflip */left:0px;opacity:1;transition:all 0.2s}.widget-position-left #button:not(.sidebar).bubbleAnimationReturn-exit{opacity:1;/*! @noflip */left:0px;transition:all 0.2s}.widget-position-left #button:not(.sidebar).bubbleAnimationReturn-exit.bubbleAnimationReturn-exit-active{/*! @noflip */left:8px;opacity:0.01}.mobile .widget-position-left #button:not(.sidebar).bubbleAnimationReturn-exit{display:none}.sidebar-position-left #button.sidebar{transition:all 0.3s}.sidebar-position-left #button.sidebar.bubbleAnimationLeft-exit{opacity:1;/*! @noflip */left:0px}.sidebar-position-left #button.sidebar.bubbleAnimationLeft-exit-active{/*! @noflip */left:-8px;opacity:0.01}.sidebar-position-left #button.sidebar.bubbleAnimationLeft-appear{/*! @noflip */left:-8px;opacity:0.01}.sidebar-position-left #button.sidebar.bubbleAnimationLeft-appear-active{opacity:1;/*! @noflip */left:0px}.sidebar-position-left #button.sidebar.bubbleAnimationLeft-enter{/*! @noflip */left:-8px;opacity:0.01}.sidebar-position-left #button.sidebar.bubbleAnimationLeft-enter-active{opacity:1;/*! @noflip */left:0px}.moveFromRight-appear{right:40px;opacity:0.01}.moveFromRight-appear.moveFromRight-appear-active{opacity:1;right:48px;transition:all 0.3s}.moveFromRight-enter{right:40px;opacity:0.01}.moveFromRight-enter.moveFromRight-enter-active{opacity:1;right:48px;transition:all 0.3s}.moveFromRight-exit{opacity:1;right:48px;transition:all 0.3s}.moveFromRight-exit.moveFromRight-exit-active{right:40px;opacity:0.01}.moveFromRightLabel-appear{/*! @noflip */right:92px;opacity:0.01}.moveFromRightLabel-appear.moveFromRightLabel-appear-active{opacity:1;/*! @noflip */right:100px;transition:all 0.3s}.moveFromRightLabel-enter{/*! @noflip */right:92px;opacity:0.01}.moveFromRightLabel-enter.moveFromRightLabel-enter-active{opacity:1;/*! @noflip */right:100px;transition:all 0.3s}.moveFromRightLabel-exit{opacity:1;/*! @noflip */right:100px;transition:all 0.3s}.moveFromRightLabel-exit.moveFromRightLabel-exit-active{/*! @noflip */right:92px;opacity:0.01}.moveFromLeftLabel-appear{/*! @noflip */left:92px;opacity:0.01}.moveFromLeftLabel-appear.moveFromLeftLabel-appear-active{opacity:1;/*! @noflip */left:100px;transition:all 0.3s}.moveFromLeftLabel-enter{/*! @noflip */left:92px;opacity:0.01}.moveFromLeftLabel-enter.moveFromLeftLabel-enter-active{opacity:1;/*! @noflip */left:100px;transition:all 0.3s}.moveFromLeftLabel-exit{opacity:1;/*! @noflip */left:100px;transition:all 0.3s}.moveFromLeftLabel-exit.moveFromLeftLabel-exit-active{/*! @noflip */left:92px;opacity:0.01}body:not(.mobile) .widget-position-left .chat.moveFromRight-appear{right:40px;left:auto;opacity:0.01}body:not(.mobile) .widget-position-left .chat.moveFromRight-appear.moveFromRight-appear-active{opacity:1;right:48px;left:auto;transition:all 0.3s}body:not(.mobile) .widget-position-left .chat.moveFromRight-enter{right:40px;left:auto;opacity:0.01}body:not(.mobile) .widget-position-left .chat.moveFromRight-enter.moveFromRight-enter-active{opacity:1;right:48px;left:auto;transition:all 0.3s}body:not(.mobile) .widget-position-left .chat.moveFromRight-exit{opacity:1;right:48px;left:auto;transition:all 0.3s}body:not(.mobile) .widget-position-left .chat.moveFromRight-exit.moveFromRight-exit-active{right:40px;left:auto;opacity:0.01}.sidebarAnimation-appear{right:40px;opacity:0.01}.sidebarAnimation-appear.sidebarAnimation-appear-active{opacity:1;right:48px;transition:all 0.3s}.sidebarAnimation-enter{right:40px;opacity:0.01}.sidebarAnimation-enter.sidebarAnimation-enter-active{opacity:1;right:48px;transition:all 0.3s}.sidebarAnimation-exit{opacity:1;right:48px;transition:all 0.3s}.sidebarAnimation-exit.sidebarAnimation-exit-active{right:40px;opacity:0.01}.operatorTyping-enter{opacity:0.01;transform:translateY(10px)}.operatorTyping-enter.operatorTyping-enter-active{transform:translateY(0px);transition:all 0.3s;opacity:1}.operatorTyping-exit{display:none}.message{padding:10px 16px;border-radius:20px;margin:2px 0;font-size:15px;line-height:20px;word-wrap:break-word;display:inline-block;max-width:85%;clear:both;position:relative;transition:margin 0.28s ease-in-out}.message.timestamp-visible{margin-bottom:28px}.message.rating-visible{margin-bottom:35px}.message span.message-content{white-space:pre-line}.rating-visible+.message,.rating-visible+.bots-card-gallery-button-wrapper{margin-top:10px}.message-visitor{color:#fff;background:linear-gradient(332deg, #21dbdb, #2979ff);float:right}.message-visitor+.message-operator{margin-top:9px}.message-visitor span a{color:currentColor}.message-visitor.not-delivered{border:1px solid #f0f2f7;background:#fff;color:#8894ab;margin-bottom:22px;white-space:nowrap;padding:10px 15px}.message-visitor.not-delivered .resend-message{position:absolute;bottom:-22px;font-size:12px;right:0}.message-operator{color:#06132b;background:#f0f2f7;float:left}.message-operator span a{color:#06132b}.message-operator+.message-visitor{margin-top:9px}.message-operator.message-with-buttons,.message-operator .message-with-buttons,.message-operator.bots-quick-replies{padding-left:0;padding-right:0;padding-bottom:0;max-width:95%}.message-operator.message-with-buttons.buttons-hidden,.message-operator .message-with-buttons.buttons-hidden,.message-operator.bots-quick-replies.buttons-hidden{padding-bottom:10px}.message-operator.message-with-buttons>span,.message-operator .message-with-buttons>span,.message-operator.bots-quick-replies>span{padding:0 16px;display:inline-block;word-break:break-word}.message-operator.message-with-buttons .button-wrapper,.message-operator .message-with-buttons .button-wrapper,.message-operator.bots-quick-replies .button-wrapper{background:#fff;width:100%;margin-top:10px;border:1px solid #ebeef0;border-bottom-left-radius:20px;border-bottom-right-radius:20px;border-top:0;position:relative}.message-operator.message-with-buttons .button-icon,.message-operator .message-with-buttons .button-icon,.message-operator.bots-quick-replies .button-icon{display:flex;justify-content:center;transition:background-color 0.2s ease-in-out;padding:8px 16px;border-bottom-left-radius:20px;border-bottom-right-radius:20px;cursor:pointer;outline:none}.message-operator.message-with-buttons .button-icon svg,.message-operator .message-with-buttons .button-icon svg,.message-operator.bots-quick-replies .button-icon svg{fill:#3f88f6;width:20px;height:20px}.message-operator.message-with-buttons .button-icon:hover,.message-operator .message-with-buttons .button-icon:hover,.message-operator.bots-quick-replies .button-icon:hover{background-color:#f6f8fb}.message-operator.message-with-buttons button,.message-operator .message-with-buttons button,.message-operator.bots-quick-replies button{margin:0 auto;min-width:100%;display:block;font-size:16px;line-height:19px;padding:8px 16px;border-bottom:1px solid #ebeef0;color:#007dfc;background:transparent;position:relative;z-index:2}.message-operator.message-with-buttons button:hover,.message-operator .message-with-buttons button:hover,.message-operator.bots-quick-replies button:hover{text-decoration:underline}.message-operator .message-with-buttons button:last-child,.message-operator.message-with-buttons button:last-child{border-bottom:0}.message-operator.bots-quick-replies{width:85%;background-color:#fff;margin-top:0;float:right}.message-operator.bots-quick-replies .button-wrapper{margin-top:0;display:flex;flex-wrap:wrap;justify-content:flex-end;width:100%;border:none}.message-operator.bots-quick-replies button{font-size:15px;padding:8px 16px;border:1px solid;border-radius:20px;margin:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:inherit}.message-operator.bots-card-gallery{padding:0 28px;max-width:calc(100% + 56px);background:transparent;overflow:auto;border-radius:0;display:flex;scroll-snap-type:x mandatory;scroll-padding:28px;scroll-behavior:smooth;margin-bottom:5px;scrollbar-width:none;margin-left:-28px}.message-operator.bots-card-gallery .ios-ipad{-webkit-overflow-scrolling:touch}.safari .message-operator.bots-card-gallery{scroll-snap-type:x mandatory}.lang-rtl .safari .message-operator.bots-card-gallery{scroll-snap-type:none}.message-operator.bots-card-gallery.bots-card-gallery-single-card{display:block;margin-left:auto;margin-right:auto;width:100%}.message-operator.bots-card-gallery.bots-card-gallery-single-card .card{max-width:240px;margin:auto}.message-operator.bots-card-gallery.bots-card-gallery-multiple-cards .card:last-child{min-width:268px;padding-right:28px}.message-operator.bots-card-gallery .card{max-width:100%;min-width:240px;scroll-snap-align:center;margin:0 10px 0 0}.message-operator.bots-card-gallery .card .card-content-wrapper{padding:9px 12px 8px;border:1px solid #ebeef0;border-top:none}.message-operator.bots-card-gallery .card .card-content-wrapper a{text-decoration:none;color:#00122e}.message-operator.bots-card-gallery .card .card-content-wrapper a:hover,.message-operator.bots-card-gallery .card .card-content-wrapper a:focus,.message-operator.bots-card-gallery .card .card-content-wrapper a:active,.message-operator.bots-card-gallery .card .card-content-wrapper a:visited{color:#00122e;outline:none}.message-operator.bots-card-gallery .card .card-content-wrapper a:hover{text-decoration:underline}.message-operator.bots-card-gallery .card .card-image{border-radius:14px 14px 0 0;height:122px;background:#fff no-repeat center center;background-size:cover;border:1px solid #ebeef0;border-bottom:0}.message-operator.bots-card-gallery .card .card-title{font-size:15px;line-height:19px;font-weight:bold;color:#00122e}.message-operator.bots-card-gallery .card .card-subtitle{margin:4px 0 0;line-height:16.5px;font-size:14px;color:#4c596b}.message-operator.bots-card-gallery .card .card-subtitle .emoji{width:15px;margin:0 0 -2px 2px}.message-operator.bots-card-gallery .card .card-url{font-size:14px;line-height:17px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;color:#00122e}.message-operator.bots-card-gallery .card .card-url a{opacity:0.5}.message-operator.bots-card-gallery .card .card-buttons .button-wrapper{margin:0}.message-operator.bots-card-gallery .card .card-buttons .button-wrapper:before{content:none}.message-operator.bots-card-gallery .card .card-buttons .button-wrapper button{width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.message-operator.bots-card-gallery.bots-card-gallery-without-images .card-content-wrapper{border-radius:14px 14px 0 0;border-top:1px solid #ebeef0}.message-operator.buttons-message{padding:0;max-width:90%}.message-operator.buttons-message .message-with-buttons{max-width:100%}.message-operator.buttons-message .message-with-buttons-text{padding:9px 16px 1px;line-height:19px;white-space:pre-line}.message-operator.message-alert{border:2px solid #dee3e8;background:#fff !important;margin-bottom:22px;position:relative}.message-operator.message-alert svg.alert-icon{height:20px;width:20px;fill:red;position:absolute;top:-5px;background:#fff;right:-5px}.message-operator.typing-indicator{text-align:left}.message-operator.typing-indicator span{height:4px;width:4px;margin:11px 1px 0 1px;background-color:#000;display:inline-block;border-radius:50%;opacity:0.4;-webkit-animation:blink 1.3s linear infinite;animation:blink 1.3s linear infinite}.message-operator.typing-indicator span:first-child{margin-left:4px}.message-operator.typing-indicator span:nth-child(2){-webkit-animation-delay:-1.1s;animation-delay:-1.1s}.message-operator.typing-indicator span:nth-child(3){-webkit-animation-delay:-0.9s;animation-delay:-0.9s}.message-operator .button-url{font-size:16px;line-height:19px;padding:8px 16px;text-align:center}.message-operator .button-url__anchor{text-decoration:none;color:#007dfc}.message-operator .button-url__anchor:hover{text-decoration:underline}@-webkit-keyframes blink{0%,60%,100%{transform:initial}30%{transform:translateY(-5px)}}@keyframes blink{0%,60%,100%{transform:initial}30%{transform:translateY(-5px)}}.bots-card-gallery-button-wrapper{position:relative;clear:both;width:100%;float:left}.bots-card-gallery-button-wrapper.bots-card-gallery-without-images .bots-card-gallery-scroll-button{top:22px}.bots-card-gallery-scroll-button{position:absolute;background:#fff;border-radius:50%;width:42px;height:42px;box-shadow:0 4px 12px 0 rgba(0,0,0,0.24);z-index:3;top:140px;transition:box-shadow 0.2s, opacity 0.2s}.bots-card-gallery-scroll-button:hover{box-shadow:0 8px 12px 0 rgba(0,0,0,0.24)}.bots-card-gallery-scroll-button.scroll-button-right{right:-18px}.bots-card-gallery-scroll-button.scroll-button-right svg{transform:rotate(-90deg)}.lang-rtl .bots-card-gallery-scroll-button.scroll-button-right svg{transform:rotate(90deg)}.bots-card-gallery-scroll-button.scroll-button-left{left:-18px}.bots-card-gallery-scroll-button.scroll-button-left svg{transform:rotate(90deg)}.lang-rtl .bots-card-gallery-scroll-button.scroll-button-left svg{transform:rotate(-90deg)}.bots-card-gallery-scroll-button svg{width:42px;height:42px}.message .emoji{margin:0 1px 0 2px;vertical-align:-5px}.messageTimestamp{bottom:-24px;font-size:12px;color:#8894ab;position:absolute;transition:all 0.2s;white-space:nowrap}.message-operator .messageTimestamp{height:23px;display:flex;align-items:center;top:calc(100% + 4px);left:12px}.message-visitor .messageTimestamp{right:12px}.shake{-webkit-animation:shake 0.82s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;animation:shake 0.82s cubic-bezier(0.36, 0.07, 0.19, 0.97) both}.pre-chat,.rate-comment,.always-online{max-width:95%}.pre-chat .field-wrapper,.rate-comment .field-wrapper,.always-online .field-wrapper{position:relative;left:0}.pre-chat .field-wrapper.field-wrapper-with-error input,.rate-comment .field-wrapper.field-wrapper-with-error input,.always-online .field-wrapper.field-wrapper-with-error input{border-color:#f6303a}.pre-chat svg,.rate-comment svg,.always-online svg{width:19px;height:19px;position:absolute;top:8px;fill:green;left:9px}.pre-chat svg#ic_arrow,.rate-comment svg#ic_arrow,.always-online svg#ic_arrow{fill:#349ef3;transform:rotate(45deg)}.pre-chat svg#ic_close,.rate-comment svg#ic_close,.always-online svg#ic_close{fill:red}.pre-chat input,.rate-comment input,.always-online input{display:block;width:100%;border:0;font-size:16px;padding:6px 7px 7px 35px;border-radius:5px;margin:10px 0 5px}.pre-chat input[type='checkbox'],.rate-comment input[type='checkbox'],.always-online input[type='checkbox']{position:absolute;width:auto;display:inline-block;margin:0;top:9px;left:11px;padding:0}.mobile .firefox .pre-chat input[type='checkbox'],.mobile .firefox .rate-comment input[type='checkbox'],.mobile .firefox .always-online input[type='checkbox']{outline:solid 1px rgba(108,125,159,0.24)}.pre-chat label,.rate-comment label,.always-online label{font-size:12px;line-height:14px;text-align:justify;display:inline-block;min-height:24px;margin-left:5px;padding:10px 5px 0 31px}.pre-chat label a,.rate-comment label a,.always-online label a{word-break:break-all}.timestamp-avatar{width:23px;height:23px;position:absolute;top:0;background-position:center;background-size:cover;border-radius:25px;background-image:url(" + c + ");padding-left:23px;left:0}.timestamp-avatar+span{margin-left:30px;margin-right:5px}.loader-icon.circular{-webkit-animation:rotate 2s linear infinite;animation:rotate 2s linear infinite;height:100%;transform-origin:center center;position:absolute;top:0;bottom:0;margin:0;left:10px;right:0}.loader-icon .path{stroke-dasharray:1, 200;stroke-dashoffset:0;-webkit-animation:dash 1.5s ease-in-out infinite;animation:dash 1.5s ease-in-out infinite;stroke-linecap:round}@-webkit-keyframes rotate{100%{transform:rotate(360deg)}}@keyframes rotate{100%{transform:rotate(360deg)}}@-webkit-keyframes dash{0%{stroke-dasharray:1, 200;stroke-dashoffset:0}50%{stroke-dasharray:89, 200;stroke-dashoffset:-35px}100%{stroke-dasharray:89, 200;stroke-dashoffset:-124px}}@keyframes dash{0%{stroke-dasharray:1, 200;stroke-dashoffset:0}50%{stroke-dasharray:89, 200;stroke-dashoffset:-35px}100%{stroke-dasharray:89, 200;stroke-dashoffset:-124px}}.message-upload{max-width:75%}.message-upload span{padding-left:25px}.message-upload #ic_download{position:absolute;top:50%;transform:translateY(-50%)}.message-upload.message-operator #ic_download{right:-35px}.message-upload.message-visitor #ic_download{left:-35px}.message-upload a{display:flex;justify-content:space-between;align-items:center}.message-upload a:hover>svg{opacity:1}.message-upload a>svg{opacity:0;fill:#bfc5d7}.message-upload.message-image{background:none;padding:0}.message-upload.message-image span{padding-left:0}.message-upload.message-image img{width:100%;border-radius:20px}.message-upload.message-file span{display:inline-block;word-break:break-all;padding-left:0}.message-upload.message-file a{color:inherit;text-decoration:none;display:inline-block;padding-left:35px}.message-upload.message-file a svg{position:absolute;top:50%;transform:translateY(-50%);left:17px}.attachment-img{background:white;color:white;border:none;outline:none}.history-button-wrapper{clear:both;width:100%;float:left}.history-button{margin:0 auto;display:flex;align-items:center;background:#fff;margin-bottom:20px;letter-spacing:-0.1px;text-align:center;font-size:12px;font-weight:600;color:#8894ab;border-radius:14px;border:solid 1px rgba(136,148,171,0.24);padding-right:12px}.history-button svg{fill:#8894ab;width:19px;margin-right:5px}.history-button:hover{color:#2a7dfb}.history-button:hover svg{fill:#2a7dfb}@-webkit-keyframes ripple{from{background:rgba(239,242,246,0);transform:scale(0.5)}50%{background:rgba(239,242,246,0.6);transform:scale(1)}to{background:rgba(239,242,246,0);transform:scale(2)}}@keyframes ripple{from{background:rgba(239,242,246,0);transform:scale(0.5)}50%{background:rgba(239,242,246,0.6);transform:scale(1)}to{background:rgba(239,242,246,0);transform:scale(2)}}.mobile{-webkit-tap-highlight-color:rgba(0,0,0,0)}.mobile button.material-icons.exit-chat.mobile-close{border-radius:50%;position:absolute;top:10px;right:20px;margin:0;padding:3px;box-shadow:0 3px 6px rgba(0,0,0,0.16),0 3px 6px rgba(0,0,0,0.23);height:30px;width:30px;background:#fff;z-index:1}.mobile button.material-icons.exit-chat.mobile-close svg{fill:#000}.mobile .chat{width:100%;height:100%;bottom:0;background:#fff;display:flex;flex-direction:column;border-radius:0;right:0;left:auto;max-height:none}.mobile .input-group{align-self:flex-end}.mobile .input-group textarea{padding-right:50px}.mobile .input-group button,.mobile .input-group .button-url{margin-bottom:0}.mobile #conversation-group{max-height:none;flex:1 1 auto;overflow-y:scroll;-webkit-overflow-scrolling:touch}.mobile #button{width:80px;height:100px;bottom:0;transition:transform 0.2s;transform:translateY(-12px);/*! @noflip */right:0px;/*! @noflip */left:auto}.mobile #button.chat-open{right:0px;left:auto}.mobile #button.sidebar{width:50px}.mobile #button.chat-closed:not(.sidebar).mobile-size__small{transform:scale(0.6)}.mobile #button.chat-closed:not(.sidebar).mobile-size__medium{transform:scale(0.8)}.mobile #new-message{top:17px;right:13px}.mobile #new-message+#dnd-indicator{right:2px}.mobile #new-message.active{-webkit-animation:shake 0.82s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;animation:shake 0.82s cubic-bezier(0.36, 0.07, 0.19, 0.97) both}.mobile #dnd-indicator{top:17px;right:13px}.mobile button.ripple{touch-action:manipulation}.mobile button.ripple::after{content:'';position:absolute;height:50px;width:0px;top:calc(50% - 25px);background:rgba(239,242,246,0);border-radius:50%;z-index:-1;will-change:transform, opacity;left:calc(50% - 25px)}.mobile button.ripple:not(:active)::after{-webkit-animation:ripple 0.3s ease-in-out;animation:ripple 0.3s ease-in-out;transition:width 0.3s step-end}.mobile button.ripple:active::after{width:50px;transition:width 0s step-start}.mobile .widget-position-left #button.chat-open{right:0;left:auto}.mobile .chat-header{padding:8px 22px 0px}.mobile .offline-message{margin-top:3px;padding:10px 28px 12px}.mobile .offline-message span{font-size:13px}.mobile .avatars-wrapper{width:42px;height:42px;margin:0px 14px 0 0}.mobile .chat h2 .top-heading{font-size:13px;margin-top:-1px}.mobile .chat h2.oneline{line-height:49px;height:54px}.awesome-iframe .onlyBubble #button,.awesome-iframe .bubbleWithLabel #button{height:94px;width:94px;bottom:0}.awesome-iframe .widget-position-left .widgetLabel{/*! @noflip */left:100px}.awesome-iframe .widget-position-left.bubbleWithLabel .widgetLabel{/*! @noflip */left:91px}.awesome-iframe .widget-position-right .widgetLabel{/*! @noflip */right:100px}.awesome-iframe .widget-position-right.bubbleWithLabel .widgetLabel{/*! @noflip */right:91px}.awesome-iframe .bubbleWithLabel .widgetLabel{bottom:26px}.awesome-iframe .widgetLabel{bottom:61px;transition-property:opacity;box-shadow:0 2px 20px 0 rgba(0,18,46,0.18)}.awesome-iframe.mobile .chat+.chat-closed{bottom:0 !important}.awesome-iframe.mobile .flyMessage+.chat-closed{bottom:0 !important}.awesome-iframe [class*='chatSize'] .chat-closed #dnd-indicator{transition:none}.awesome-iframe .onlyBubble #new-message,.awesome-iframe .onlyBubble #dnd-indicator,.awesome-iframe .bubbleWithLabel #new-message,.awesome-iframe .bubbleWithLabel #dnd-indicator{top:14px;right:14px;transition:none}.awesome-iframe .onlyBubble #new-message+#dnd-indicator,.awesome-iframe .bubbleWithLabel #new-message+#dnd-indicator{right:3px}.awesome-iframe .onlyBubbleLarge #new-message,.awesome-iframe .onlyBubbleLarge #dnd-indicator{top:14px;right:20px;transition:none}.awesome-iframe .onlyBubbleLarge #new-message+#dnd-indicator{right:10px}.awesome-iframe .onlyBubbleMedium #new-message,.awesome-iframe .onlyBubbleMedium #dnd-indicator{top:7px;transition:none}.awesome-iframe .onlyBubbleSmall #new-message,.awesome-iframe .onlyBubbleSmall #dnd-indicator{top:-3px;transition:none;right:3px}.awesome-iframe .onlyBubbleSmall #new-message+#dnd-indicator{right:-7px}.awesome-iframe .onlyBubbleSmall #button,.awesome-iframe .onlyBubbleMedium #button,.awesome-iframe .onlyBubbleLarge #button{transition:none;transform:translateY(0)}.awesome-iframe .onlyBubbleSmall #button{width:60px;height:60px}.awesome-iframe .onlyBubbleMedium #button{width:80px;height:80px}.awesome-iframe .onlyBubbleLarge #button{width:94px;height:94px}html{box-sizing:border-box}*,*:before,*:after{box-sizing:inherit}body,input,textarea,select,button{font-family:'Mulish', sans-serif;letter-spacing:-0.24px;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;color:#06132b}input::-moz-placeholder, textarea::-moz-placeholder{color:#8894ab;opacity:1}input::placeholder,textarea::placeholder{color:#8894ab;opacity:1}input:focus,input:active,textarea:focus,textarea:active,select:focus,select:active{border:0;outline:0}table{border-spacing:0}i{-webkit-user-select:none;-moz-user-select:none;user-select:none}ul{list-style-type:none}.emoji{width:20px;margin:0 2px -5px 2px;-webkit-user-select:none;-moz-user-select:none;user-select:none}.lang-rtl{/*! @noflip */direction:rtl;unicode-bidi:embed}.widget-position-left .chat,.widget-position-left .start-group{right:48px;left:auto}.mobile .widget-position-left .chat,.mobile .widget-position-left .start-group{/*! @noflip */right:0}.widget-position-left #button:not(.sidebar){/*! @noflip */left:0px;/*! @noflip */right:auto}.widget-position-left #button.bubbleAnimation-exit{right:0px;left:auto}.widget-position-left #button.chat-open{right:0px;left:auto}.mobile .widget-position-left #button.chat-open{right:0px;left:auto}@media print{.frame-content{display:none !important}}\n", ""]), e.exports = t
        },
        392: function(e, t, n) {
            (t = n(336)(!1)).push([e.i, ".emoji-mart,\n.emoji-mart * {\n    box-sizing: border-box;\n    line-height: 1.15;\n}\n\n.emoji-mart {\n    font-family: -apple-system, BlinkMacSystemFont, 'Helvetica Neue', sans-serif;\n    font-size: 16px;\n    display: inline-block;\n    color: #222427;\n    border: 1px solid #d9d9d9;\n    border-radius: 5px;\n    background: #fff;\n}\n\n.emoji-mart .emoji-mart-emoji {\n    padding: 6px;\n}\n\n.emoji-mart-bar {\n    border: 0 solid #d9d9d9;\n}\n.emoji-mart-bar:first-child {\n    border-bottom-width: 1px;\n    border-top-left-radius: 5px;\n    border-top-right-radius: 5px;\n}\n.emoji-mart-bar:last-child {\n    border-top-width: 1px;\n    border-bottom-left-radius: 5px;\n    border-bottom-right-radius: 5px;\n}\n\n.emoji-mart-anchors {\n    display: flex;\n    flex-direction: row;\n    justify-content: space-between;\n    padding: 0 6px;\n    color: #858585;\n    line-height: 0;\n}\n\n.emoji-mart-anchor {\n    position: relative;\n    display: block;\n    flex: 1 1 auto;\n    color: #858585;\n    text-align: center;\n    padding: 12px 4px;\n    overflow: hidden;\n    transition: color 0.1s ease-out;\n    margin: 0;\n    box-shadow: none;\n    background: none;\n    border: none;\n}\n.emoji-mart-anchor:focus {\n    outline: 0;\n}\n.emoji-mart-anchor:hover,\n.emoji-mart-anchor:focus,\n.emoji-mart-anchor-selected {\n    color: #464646;\n}\n\n.emoji-mart-anchor-selected .emoji-mart-anchor-bar {\n    bottom: 0;\n}\n\n.emoji-mart-anchor-bar {\n    position: absolute;\n    bottom: -3px;\n    left: 0;\n    width: 100%;\n    height: 3px;\n    background-color: #464646;\n}\n\n.emoji-mart-anchors i {\n    display: inline-block;\n    width: 100%;\n    max-width: 22px;\n}\n\n.emoji-mart-anchors svg,\n.emoji-mart-anchors img {\n    fill: currentColor;\n    max-height: 18px;\n}\n\n.emoji-mart-scroll {\n    overflow-y: scroll;\n    overflow-x: hidden;\n    height: 270px;\n    padding: 0 6px 6px 6px;\n    will-change: transform; /* avoids \"repaints on scroll\" in mobile Chrome */\n}\n\n.emoji-mart-search {\n    margin-top: 6px;\n    padding: 0 6px;\n    position: relative;\n}\n\n.emoji-mart-search input {\n    font-size: 16px;\n    display: block;\n    width: 100%;\n    padding: 0.2em 0.6em;\n    border-radius: 25px;\n    border: 1px solid #d9d9d9;\n    outline: 0;\n}\n\n.emoji-mart-search input,\n.emoji-mart-search input::-webkit-search-decoration,\n.emoji-mart-search input::-webkit-search-cancel-button,\n.emoji-mart-search input::-webkit-search-results-button,\n.emoji-mart-search input::-webkit-search-results-decoration {\n    /* remove webkit/blink styles for <input type=\"search\">\n     * via https://stackoverflow.com/a/9422689 */\n    -webkit-appearance: none;\n}\n\n.emoji-mart-search-icon {\n    position: absolute;\n    top: 7px;\n    right: 11px;\n    z-index: 2;\n    padding: 2px 5px 1px;\n    border: none;\n    background: none;\n}\n\n.emoji-mart-category .emoji-mart-emoji span {\n    z-index: 1;\n    position: relative;\n    text-align: center;\n    cursor: default;\n}\n\n.emoji-mart-category .emoji-mart-emoji:hover:before {\n    z-index: 0;\n    content: '';\n    position: absolute;\n    top: 0;\n    left: 0;\n    width: 100%;\n    height: 100%;\n    background-color: #f4f4f4;\n    border-radius: 100%;\n}\n\n.emoji-mart-category-label {\n    z-index: 2;\n    position: relative;\n    position: -webkit-sticky;\n    position: sticky;\n    top: 0;\n}\n\n.emoji-mart-category-label span {\n    display: block;\n    width: 100%;\n    font-weight: 500;\n    padding: 5px 6px;\n    background-color: #fff;\n    background-color: rgba(255, 255, 255, 0.95);\n}\n\n.emoji-mart-category-list {\n    margin: 0;\n    padding: 0;\n}\n\n.emoji-mart-category-list li {\n    list-style: none;\n    margin: 0;\n    padding: 0;\n    display: inline-block;\n}\n\n.emoji-mart-emoji {\n    position: relative;\n    display: inline-block;\n    font-size: 0;\n    margin: 0;\n    padding: 0;\n    border: none;\n    background: none;\n    box-shadow: none;\n}\n\n.emoji-mart-emoji-native {\n    font-family: 'Segoe UI Emoji', 'Segoe UI Symbol', 'Segoe UI', 'Apple Color Emoji',\n        'Twemoji Mozilla', 'Noto Color Emoji', 'Android Emoji';\n}\n\n.emoji-mart-no-results {\n    font-size: 14px;\n    text-align: center;\n    padding-top: 70px;\n    color: #858585;\n}\n.emoji-mart-no-results-img {\n    display: block;\n    margin-left: auto;\n    margin-right: auto;\n    width: 50%;\n}\n.emoji-mart-no-results .emoji-mart-category-label {\n    display: none;\n}\n.emoji-mart-no-results .emoji-mart-no-results-label {\n    margin-top: 0.2em;\n}\n.emoji-mart-no-results .emoji-mart-emoji:hover:before {\n    content: none;\n}\n\n/* For screenreaders only, via https://stackoverflow.com/a/19758620 */\n.emoji-mart-sr-only {\n    position: absolute;\n    width: 1px;\n    height: 1px;\n    padding: 0;\n    margin: -1px;\n    overflow: hidden;\n    clip: rect(0, 0, 0, 0);\n    border: 0;\n}\n", ""]), e.exports = t
        },
        393: function(e, t, n) {
            "use strict";
            e.exports = function(e, t) {
                return t || (t = {}), "string" !== typeof(e = e && e.__esModule ? e.default : e) ? e : (/^['"].*['"]$/.test(e) && (e = e.slice(1, -1)), t.hash && (e += t.hash), /["'() \t\n]/.test(e) || t.needQuotes ? '"'.concat(e.replace(/"/g, '\\"').replace(/\n/g, "\\n"), '"') : e)
            }
        },
        394: function(e, t, n) {
            "use strict";
            n.r(t), t.default = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAMDAwMDAwQEBAQFBQUFBQcHBgYHBwsICQgJCAsRCwwLCwwLEQ8SDw4PEg8bFRMTFRsfGhkaHyYiIiYwLTA+PlQBAwMDAwMDBAQEBAUFBQUFBwcGBgcHCwgJCAkICxELDAsLDAsRDxIPDg8SDxsVExMVGx8aGRofJiIiJjAtMD4+VP/CABEIADwAPAMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABgEDBAUHAgn/2gAIAQEAAAAA+lYAj8cy5ndHO8VNN0IFrk62gjEYudH9iLQPN6lec+0VmtG038L9UpWh/8QAFAEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAhAAAAAAAP/EABQBAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMQAAAAAAD/xAAuEAABAwMACAUEAwAAAAAAAAABAgMEAAURBhASEyAhQVEiMmKRwSNxcoExQqH/2gAIAQEAAT8A14PHdbuuMvcMY2wPGs88Z6ClT5qzlUh0n8qjXmawoFay8jqlfwaZebkNIdbOUrGRwCpxJmySf53qtdgJNu+zq+G7N7u4yPUoK9xrsyC3bWfUVL9zw6QxiS1IA5Y2F/Gpplb7qGkeZasCkNpabQhPlQkJH64CMDJ5DvWkk+Gu3uRm3wp5ak42Dkp2TnJNC4S2hhyPvT0Wg4z9xVqmuN3SNJl/TabUcITzxkY2j3piRHkjLLrbg9Ks1gjVL0nnvLVuAllHTllf7Jp+VKknLz7jn5K+KAAGNY8JykkHuDg0xe7rG5JkqUB/VY2x/tR9LkBvEmMsud2/KfeumrtXSu9dKFZNf//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQIBAT8AB//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQMBAT8AB//Z"
        },
        395: function(e, t, n) {
            "use strict";
            n.r(t), t.default = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAzNzIgMTUiPgogIDxwYXRoIGQ9Ik0zNDkuOCAxLjRDMzM0LjUuNCAzMTguNSAwIDMwMiAwaC0yLjVjLTkuMSAwLTE4LjQuMS0yNy44LjQtMzQuNSAxLTY4LjMgMy0xMDIuMyA0LjctMTQgLjUtMjggMS4yLTQxLjUgMS42Qzg0IDcuNyA0MS42IDUuMyAwIDIuMnY4LjRjNDEuNiAzIDg0IDUuMyAxMjguMiA0LjEgMTMuNS0uNCAyNy41LTEuMSA0MS41LTEuNiAzMy45LTEuNyA2Ny44LTMuNiAxMDIuMy00LjcgOS40LS4zIDE4LjctLjQgMjcuOC0uNGgyLjVjMTYuNSAwIDMyLjQuNCA0Ny44IDEuNCA4LjQuMyAxNS42LjcgMjIgMS4yVjIuMmMtNi41LS41LTEzLjgtLjUtMjIuMy0uOHoiIGZpbGw9IiNmZmYiLz4KPC9zdmc+Cg=="
        },
        396: function(e, t, n) {
            t.hot = function(e) {
                return e
            }
        },
        403: function(e, t, n) {
            "use strict";
            n.r(t);
            n(37), n(69), n(79), n(53), n(76), n(80), n(77), n(43), n(118), n(81), n(121), n(119), n(205), n(70), n(25);
            var r = n(315),
                o = n.n(r),
                a = n(41),
                i = n.n(a),
                s = n(23),
                c = n.n(s),
                u = n(24),
                l = n.n(u),
                d = n(97),
                f = n.n(d),
                p = n(149),
                b = n.n(p),
                h = n(150),
                m = n.n(h),
                g = n(117),
                v = n.n(g),
                y = n(5),
                w = n.n(y),
                x = n(2),
                O = n.n(x),
                j = n(38),
                k = n(325),
                M = n.n(k),
                A = n(323),
                C = n(396),
                S = n(40),
                E = n(157),
                R = n(329),
                D = n.n(R),
                N = n(345),
                T = n.n(N);

            function P() {
                return (P = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }

            function L(e, t) {
                if (null == e) return {};
                var n, r, o = {},
                    a = Object.keys(e);
                for (r = 0; r < a.length; r++) n = a[r], t.indexOf(n) >= 0 || (o[n] = e[n]);
                return o
            }

            function _(e, t) {
                e.prototype = Object.create(t.prototype), e.prototype.constructor = e, e.__proto__ = t
            }
            var F = n(204),
                z = n.n(F);

            function I(e, t) {
                return e.replace(new RegExp("(^|\\s)" + t + "(?:\\s|$)", "g"), "$1").replace(/\s+/g, " ").replace(/^\s*|\s*$/g, "")
            }
            var B = n(100),
                H = n.n(B),
                W = !1,
                V = O.a.createContext(null),
                U = function(e) {
                    function t(t, n) {
                        var r;
                        r = e.call(this, t, n) || this;
                        var o, a = n && !n.isMounting ? t.enter : t.appear;
                        return r.appearStatus = null, t.in ? a ? (o = "exited", r.appearStatus = "entering") : o = "entered" : o = t.unmountOnExit || t.mountOnEnter ? "unmounted" : "exited", r.state = {
                            status: o
                        }, r.nextCallback = null, r
                    }
                    _(t, e), t.getDerivedStateFromProps = function(e, t) {
                        return e.in && "unmounted" === t.status ? {
                            status: "exited"
                        } : null
                    };
                    var n = t.prototype;
                    return n.componentDidMount = function() {
                        this.updateStatus(!0, this.appearStatus)
                    }, n.componentDidUpdate = function(e) {
                        var t = null;
                        if (e !== this.props) {
                            var n = this.state.status;
                            this.props.in ? "entering" !== n && "entered" !== n && (t = "entering") : "entering" !== n && "entered" !== n || (t = "exiting")
                        }
                        this.updateStatus(!1, t)
                    }, n.componentWillUnmount = function() {
                        this.cancelNextCallback()
                    }, n.getTimeouts = function() {
                        var e, t, n, r = this.props.timeout;
                        return e = t = n = r, null != r && "number" !== typeof r && (e = r.exit, t = r.enter, n = void 0 !== r.appear ? r.appear : t), {
                            exit: e,
                            enter: t,
                            appear: n
                        }
                    }, n.updateStatus = function(e, t) {
                        void 0 === e && (e = !1), null !== t ? (this.cancelNextCallback(), "entering" === t ? this.performEnter(e) : this.performExit()) : this.props.unmountOnExit && "exited" === this.state.status && this.setState({
                            status: "unmounted"
                        })
                    }, n.performEnter = function(e) {
                        var t = this,
                            n = this.props.enter,
                            r = this.context ? this.context.isMounting : e,
                            o = this.props.nodeRef ? [r] : [H.a.findDOMNode(this), r],
                            a = o[0],
                            i = o[1],
                            s = this.getTimeouts(),
                            c = r ? s.appear : s.enter;
                        !e && !n || W ? this.safeSetState({
                            status: "entered"
                        }, (function() {
                            t.props.onEntered(a)
                        })) : (this.props.onEnter(a, i), this.safeSetState({
                            status: "entering"
                        }, (function() {
                            t.props.onEntering(a, i), t.onTransitionEnd(c, (function() {
                                t.safeSetState({
                                    status: "entered"
                                }, (function() {
                                    t.props.onEntered(a, i)
                                }))
                            }))
                        })))
                    }, n.performExit = function() {
                        var e = this,
                            t = this.props.exit,
                            n = this.getTimeouts(),
                            r = this.props.nodeRef ? void 0 : H.a.findDOMNode(this);
                        t && !W ? (this.props.onExit(r), this.safeSetState({
                            status: "exiting"
                        }, (function() {
                            e.props.onExiting(r), e.onTransitionEnd(n.exit, (function() {
                                e.safeSetState({
                                    status: "exited"
                                }, (function() {
                                    e.props.onExited(r)
                                }))
                            }))
                        }))) : this.safeSetState({
                            status: "exited"
                        }, (function() {
                            e.props.onExited(r)
                        }))
                    }, n.cancelNextCallback = function() {
                        null !== this.nextCallback && (this.nextCallback.cancel(), this.nextCallback = null)
                    }, n.safeSetState = function(e, t) {
                        t = this.setNextCallback(t), this.setState(e, t)
                    }, n.setNextCallback = function(e) {
                        var t = this,
                            n = !0;
                        return this.nextCallback = function(r) {
                            n && (n = !1, t.nextCallback = null, e(r))
                        }, this.nextCallback.cancel = function() {
                            n = !1
                        }, this.nextCallback
                    }, n.onTransitionEnd = function(e, t) {
                        this.setNextCallback(t);
                        var n = this.props.nodeRef ? this.props.nodeRef.current : H.a.findDOMNode(this),
                            r = null == e && !this.props.addEndListener;
                        if (n && !r) {
                            if (this.props.addEndListener) {
                                var o = this.props.nodeRef ? [this.nextCallback] : [n, this.nextCallback],
                                    a = o[0],
                                    i = o[1];
                                this.props.addEndListener(a, i)
                            }
                            null != e && setTimeout(this.nextCallback, e)
                        } else setTimeout(this.nextCallback, 0)
                    }, n.render = function() {
                        var e = this.state.status;
                        if ("unmounted" === e) return null;
                        var t = this.props,
                            n = t.children,
                            r = (t.in, t.mountOnEnter, t.unmountOnExit, t.appear, t.enter, t.exit, t.timeout, t.addEndListener, t.onEnter, t.onEntering, t.onEntered, t.onExit, t.onExiting, t.onExited, t.nodeRef, L(t, ["children", "in", "mountOnEnter", "unmountOnExit", "appear", "enter", "exit", "timeout", "addEndListener", "onEnter", "onEntering", "onEntered", "onExit", "onExiting", "onExited", "nodeRef"]));
                        return O.a.createElement(V.Provider, {
                            value: null
                        }, "function" === typeof n ? n(e, r) : O.a.cloneElement(O.a.Children.only(n), r))
                    }, t
                }(O.a.Component);

            function q() {}
            U.contextType = V, U.propTypes = {}, U.defaultProps = { in: !1,
                mountOnEnter: !1,
                unmountOnExit: !1,
                appear: !1,
                enter: !0,
                exit: !0,
                onEnter: q,
                onEntering: q,
                onEntered: q,
                onExit: q,
                onExiting: q,
                onExited: q
            }, U.UNMOUNTED = "unmounted", U.EXITED = "exited", U.ENTERING = "entering", U.ENTERED = "entered", U.EXITING = "exiting";
            var G = U,
                Y = function(e, t) {
                    return e && t && t.split(" ").forEach((function(t) {
                        return r = t, void((n = e).classList ? n.classList.remove(r) : "string" === typeof n.className ? n.className = I(n.className, r) : n.setAttribute("class", I(n.className && n.className.baseVal || "", r)));
                        var n, r
                    }))
                },
                Q = function(e) {
                    function t() {
                        for (var t, n = arguments.length, r = new Array(n), o = 0; o < n; o++) r[o] = arguments[o];
                        return (t = e.call.apply(e, [this].concat(r)) || this).appliedClasses = {
                            appear: {},
                            enter: {},
                            exit: {}
                        }, t.onEnter = function(e, n) {
                            var r = t.resolveArguments(e, n),
                                o = r[0],
                                a = r[1];
                            t.removeClasses(o, "exit"), t.addClass(o, a ? "appear" : "enter", "base"), t.props.onEnter && t.props.onEnter(e, n)
                        }, t.onEntering = function(e, n) {
                            var r = t.resolveArguments(e, n),
                                o = r[0],
                                a = r[1] ? "appear" : "enter";
                            t.addClass(o, a, "active"), t.props.onEntering && t.props.onEntering(e, n)
                        }, t.onEntered = function(e, n) {
                            var r = t.resolveArguments(e, n),
                                o = r[0],
                                a = r[1] ? "appear" : "enter";
                            t.removeClasses(o, a), t.addClass(o, a, "done"), t.props.onEntered && t.props.onEntered(e, n)
                        }, t.onExit = function(e) {
                            var n = t.resolveArguments(e)[0];
                            t.removeClasses(n, "appear"), t.removeClasses(n, "enter"), t.addClass(n, "exit", "base"), t.props.onExit && t.props.onExit(e)
                        }, t.onExiting = function(e) {
                            var n = t.resolveArguments(e)[0];
                            t.addClass(n, "exit", "active"), t.props.onExiting && t.props.onExiting(e)
                        }, t.onExited = function(e) {
                            var n = t.resolveArguments(e)[0];
                            t.removeClasses(n, "exit"), t.addClass(n, "exit", "done"), t.props.onExited && t.props.onExited(e)
                        }, t.resolveArguments = function(e, n) {
                            return t.props.nodeRef ? [t.props.nodeRef.current, e] : [e, n]
                        }, t.getClassNames = function(e) {
                            var n = t.props.classNames,
                                r = "string" === typeof n,
                                o = r ? "" + (r && n ? n + "-" : "") + e : n[e];
                            return {
                                baseClassName: o,
                                activeClassName: r ? o + "-active" : n[e + "Active"],
                                doneClassName: r ? o + "-done" : n[e + "Done"]
                            }
                        }, t
                    }
                    _(t, e);
                    var n = t.prototype;
                    return n.addClass = function(e, t, n) {
                        var r = this.getClassNames(t)[n + "ClassName"],
                            o = this.getClassNames("enter").doneClassName;
                        "appear" === t && "done" === n && o && (r += " " + o), "active" === n && e && e.scrollTop, r && (this.appliedClasses[t][n] = r, function(e, t) {
                            e && t && t.split(" ").forEach((function(t) {
                                return r = t, void((n = e).classList ? n.classList.add(r) : function(e, t) {
                                    return e.classList ? !!t && e.classList.contains(t) : -1 !== (" " + (e.className.baseVal || e.className) + " ").indexOf(" " + t + " ")
                                }(n, r) || ("string" === typeof n.className ? n.className = n.className + " " + r : n.setAttribute("class", (n.className && n.className.baseVal || "") + " " + r)));
                                var n, r
                            }))
                        }(e, r))
                    }, n.removeClasses = function(e, t) {
                        var n = this.appliedClasses[t],
                            r = n.base,
                            o = n.active,
                            a = n.done;
                        this.appliedClasses[t] = {}, r && Y(e, r), o && Y(e, o), a && Y(e, a)
                    }, n.render = function() {
                        var e = this.props,
                            t = (e.classNames, L(e, ["classNames"]));
                        return O.a.createElement(G, P({}, t, {
                            onEnter: this.onEnter,
                            onEntered: this.onEntered,
                            onEntering: this.onEntering,
                            onExit: this.onExit,
                            onExiting: this.onExiting,
                            onExited: this.onExited
                        }))
                    }, t
                }(O.a.Component);
            Q.defaultProps = {
                classNames: ""
            }, Q.propTypes = {};
            var K = Q,
                Z = function(e) {
                    return Object(S.d)(K, o()({}, e, { in: e.in,
                        timeout: e.timeout,
                        classNames: e.classNames,
                        mountOnEnter: !0,
                        unmountOnExit: !0,
                        appear: !0
                    }), e.children)
                };
            Z.defaultProps = {
                timeout: 200
            };
            var X = Z;
            n(52);

            function $(e, t, n, r) {
                return new(n || (n = Promise))((function(o, a) {
                    function i(e) {
                        try {
                            c(r.next(e))
                        } catch (t) {
                            a(t)
                        }
                    }

                    function s(e) {
                        try {
                            c(r.throw(e))
                        } catch (t) {
                            a(t)
                        }
                    }

                    function c(e) {
                        var t;
                        e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                            e(t)
                        }))).then(i, s)
                    }
                    c((r = r.apply(e, t || [])).next())
                }))
            }

            function J(e, t) {
                var n, r, o, a, i = {
                    label: 0,
                    sent: function() {
                        if (1 & o[0]) throw o[1];
                        return o[1]
                    },
                    trys: [],
                    ops: []
                };
                return a = {
                    next: s(0),
                    throw: s(1),
                    return: s(2)
                }, "function" === typeof Symbol && (a[Symbol.iterator] = function() {
                    return this
                }), a;

                function s(a) {
                    return function(s) {
                        return function(a) {
                            if (n) throw new TypeError("Generator is already executing.");
                            for (; i;) try {
                                if (n = 1, r && (o = 2 & a[0] ? r.return : a[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, a[1])).done) return o;
                                switch (r = 0, o && (a = [2 & a[0], o.value]), a[0]) {
                                    case 0:
                                    case 1:
                                        o = a;
                                        break;
                                    case 4:
                                        return i.label++, {
                                            value: a[1],
                                            done: !1
                                        };
                                    case 5:
                                        i.label++, r = a[1], a = [0];
                                        continue;
                                    case 7:
                                        a = i.ops.pop(), i.trys.pop();
                                        continue;
                                    default:
                                        if (!(o = (o = i.trys).length > 0 && o[o.length - 1]) && (6 === a[0] || 2 === a[0])) {
                                            i = 0;
                                            continue
                                        }
                                        if (3 === a[0] && (!o || a[1] > o[0] && a[1] < o[3])) {
                                            i.label = a[1];
                                            break
                                        }
                                        if (6 === a[0] && i.label < o[1]) {
                                            i.label = o[1], o = a;
                                            break
                                        }
                                        if (o && i.label < o[2]) {
                                            i.label = o[2], i.ops.push(a);
                                            break
                                        }
                                        o[2] && i.ops.pop(), i.trys.pop();
                                        continue
                                }
                                a = t.call(e, i)
                            } catch (s) {
                                a = [6, s], r = 0
                            } finally {
                                n = o = 0
                            }
                            if (5 & a[0]) throw a[1];
                            return {
                                value: a[0] ? a[1] : void 0,
                                done: !0
                            }
                        }([a, s])
                    }
                }
            }
            Object.create;

            function ee(e, t) {
                var n = "function" === typeof Symbol && e[Symbol.iterator];
                if (!n) return e;
                var r, o, a = n.call(e),
                    i = [];
                try {
                    for (;
                        (void 0 === t || t-- > 0) && !(r = a.next()).done;) i.push(r.value)
                } catch (s) {
                    o = {
                        error: s
                    }
                } finally {
                    try {
                        r && !r.done && (n = a.return) && n.call(a)
                    } finally {
                        if (o) throw o.error
                    }
                }
                return i
            }
            Object.create;
            var te = new Map([
                ["avi", "video/avi"],
                ["gif", "image/gif"],
                ["ico", "image/x-icon"],
                ["jpeg", "image/jpeg"],
                ["jpg", "image/jpeg"],
                ["mkv", "video/x-matroska"],
                ["mov", "video/quicktime"],
                ["mp4", "video/mp4"],
                ["pdf", "application/pdf"],
                ["png", "image/png"],
                ["zip", "application/zip"],
                ["doc", "application/msword"],
                ["docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"]
            ]);

            function ne(e, t) {
                var n = function(e) {
                    var t = e.name;
                    if (t && -1 !== t.lastIndexOf(".") && !e.type) {
                        var n = t.split(".").pop().toLowerCase(),
                            r = te.get(n);
                        r && Object.defineProperty(e, "type", {
                            value: r,
                            writable: !1,
                            configurable: !1,
                            enumerable: !0
                        })
                    }
                    return e
                }(e);
                if ("string" !== typeof n.path) {
                    var r = e.webkitRelativePath;
                    Object.defineProperty(n, "path", {
                        value: "string" === typeof t ? t : "string" === typeof r && r.length > 0 ? r : e.name,
                        writable: !1,
                        configurable: !1,
                        enumerable: !0
                    })
                }
                return n
            }
            var re = [".DS_Store", "Thumbs.db"];

            function oe(e) {
                return (null !== e.target && e.target.files ? se(e.target.files) : []).map((function(e) {
                    return ne(e)
                }))
            }

            function ae(e, t) {
                return $(this, void 0, void 0, (function() {
                    var n;
                    return J(this, (function(r) {
                        switch (r.label) {
                            case 0:
                                return e.items ? (n = se(e.items).filter((function(e) {
                                    return "file" === e.kind
                                })), "drop" !== t ? [2, n] : [4, Promise.all(n.map(ce))]) : [3, 2];
                            case 1:
                                return [2, ie(ue(r.sent()))];
                            case 2:
                                return [2, ie(se(e.files).map((function(e) {
                                    return ne(e)
                                })))]
                        }
                    }))
                }))
            }

            function ie(e) {
                return e.filter((function(e) {
                    return -1 === re.indexOf(e.name)
                }))
            }

            function se(e) {
                for (var t = [], n = 0; n < e.length; n++) {
                    var r = e[n];
                    t.push(r)
                }
                return t
            }

            function ce(e) {
                if ("function" !== typeof e.webkitGetAsEntry) return le(e);
                var t = e.webkitGetAsEntry();
                return t && t.isDirectory ? fe(t) : le(e)
            }

            function ue(e) {
                return e.reduce((function(e, t) {
                    return function() {
                        for (var e = [], t = 0; t < arguments.length; t++) e = e.concat(ee(arguments[t]));
                        return e
                    }(e, Array.isArray(t) ? ue(t) : [t])
                }), [])
            }

            function le(e) {
                var t = e.getAsFile();
                if (!t) return Promise.reject(e + " is not a File");
                var n = ne(t);
                return Promise.resolve(n)
            }

            function de(e) {
                return $(this, void 0, void 0, (function() {
                    return J(this, (function(t) {
                        return [2, e.isDirectory ? fe(e) : pe(e)]
                    }))
                }))
            }

            function fe(e) {
                var t = e.createReader();
                return new Promise((function(e, n) {
                    var r = [];
                    ! function o() {
                        var a = this;
                        t.readEntries((function(t) {
                            return $(a, void 0, void 0, (function() {
                                var a, i, s;
                                return J(this, (function(c) {
                                    switch (c.label) {
                                        case 0:
                                            if (t.length) return [3, 5];
                                            c.label = 1;
                                        case 1:
                                            return c.trys.push([1, 3, , 4]), [4, Promise.all(r)];
                                        case 2:
                                            return a = c.sent(), e(a), [3, 4];
                                        case 3:
                                            return i = c.sent(), n(i), [3, 4];
                                        case 4:
                                            return [3, 6];
                                        case 5:
                                            s = Promise.all(t.map(de)), r.push(s), o(), c.label = 6;
                                        case 6:
                                            return [2]
                                    }
                                }))
                            }))
                        }), (function(e) {
                            n(e)
                        }))
                    }()
                }))
            }

            function pe(e) {
                return $(this, void 0, void 0, (function() {
                    return J(this, (function(t) {
                        return [2, new Promise((function(t, n) {
                            e.file((function(n) {
                                var r = ne(n, e.fullPath);
                                t(r)
                            }), (function(e) {
                                n(e)
                            }))
                        }))]
                    }))
                }))
            }
            var be = n(346),
                he = n.n(be);

            function me(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" === typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        o = !1,
                        a = void 0;
                    try {
                        for (var i, s = e[Symbol.iterator](); !(r = (i = s.next()).done) && (n.push(i.value), !t || n.length !== t); r = !0);
                    } catch (c) {
                        o = !0, a = c
                    } finally {
                        try {
                            r || null == s.return || s.return()
                        } finally {
                            if (o) throw a
                        }
                    }
                    return n
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" === typeof e) return ge(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return ge(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function ge(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }
            var ve = function(e) {
                    e = Array.isArray(e) && 1 === e.length ? e[0] : e;
                    var t = Array.isArray(e) ? "one of ".concat(e.join(", ")) : e;
                    return {
                        code: "file-invalid-type",
                        message: "File type must be ".concat(t)
                    }
                },
                ye = function(e) {
                    return {
                        code: "file-too-large",
                        message: "File is larger than ".concat(e, " bytes")
                    }
                },
                we = function(e) {
                    return {
                        code: "file-too-small",
                        message: "File is smaller than ".concat(e, " bytes")
                    }
                },
                xe = {
                    code: "too-many-files",
                    message: "Too many files"
                };

            function Oe(e, t) {
                var n = "application/x-moz-file" === e.type || he()(e, t);
                return [n, n ? null : ve(t)]
            }

            function je(e, t, n) {
                if (ke(e.size))
                    if (ke(t) && ke(n)) {
                        if (e.size > n) return [!1, ye(n)];
                        if (e.size < t) return [!1, we(t)]
                    } else {
                        if (ke(t) && e.size < t) return [!1, we(t)];
                        if (ke(n) && e.size > n) return [!1, ye(n)]
                    }
                return [!0, null]
            }

            function ke(e) {
                return void 0 !== e && null !== e
            }

            function Me(e) {
                var t = e.files,
                    n = e.accept,
                    r = e.minSize,
                    o = e.maxSize,
                    a = e.multiple,
                    i = e.maxFiles;
                return !(!a && t.length > 1 || a && i >= 1 && t.length > i) && t.every((function(e) {
                    var t = me(Oe(e, n), 1)[0],
                        a = me(je(e, r, o), 1)[0];
                    return t && a
                }))
            }

            function Ae(e) {
                return "function" === typeof e.isPropagationStopped ? e.isPropagationStopped() : "undefined" !== typeof e.cancelBubble && e.cancelBubble
            }

            function Ce(e) {
                return e.dataTransfer ? Array.prototype.some.call(e.dataTransfer.types, (function(e) {
                    return "Files" === e || "application/x-moz-file" === e
                })) : !!e.target && !!e.target.files
            }

            function Se(e) {
                e.preventDefault()
            }

            function Ee(e) {
                return -1 !== e.indexOf("MSIE") || -1 !== e.indexOf("Trident/")
            }

            function Re(e) {
                return -1 !== e.indexOf("Edge/")
            }

            function De() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : window.navigator.userAgent;
                return Ee(e) || Re(e)
            }

            function Ne() {
                for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                return function(e) {
                    for (var n = arguments.length, r = new Array(n > 1 ? n - 1 : 0), o = 1; o < n; o++) r[o - 1] = arguments[o];
                    return t.some((function(t) {
                        return !Ae(e) && t && t.apply(void 0, [e].concat(r)), Ae(e)
                    }))
                }
            }

            function Te(e) {
                return function(e) {
                    if (Array.isArray(e)) return _e(e)
                }(e) || function(e) {
                    if ("undefined" !== typeof Symbol && Symbol.iterator in Object(e)) return Array.from(e)
                }(e) || Le(e) || function() {
                    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function Pe(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" === typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        o = !1,
                        a = void 0;
                    try {
                        for (var i, s = e[Symbol.iterator](); !(r = (i = s.next()).done) && (n.push(i.value), !t || n.length !== t); r = !0);
                    } catch (c) {
                        o = !0, a = c
                    } finally {
                        try {
                            r || null == s.return || s.return()
                        } finally {
                            if (o) throw a
                        }
                    }
                    return n
                }(e, t) || Le(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function Le(e, t) {
                if (e) {
                    if ("string" === typeof e) return _e(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? _e(e, t) : void 0
                }
            }

            function _e(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }

            function Fe(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function ze(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Fe(Object(n), !0).forEach((function(t) {
                        Ie(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Fe(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function Ie(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }

            function Be(e, t) {
                if (null == e) return {};
                var n, r, o = function(e, t) {
                    if (null == e) return {};
                    var n, r, o = {},
                        a = Object.keys(e);
                    for (r = 0; r < a.length; r++) n = a[r], t.indexOf(n) >= 0 || (o[n] = e[n]);
                    return o
                }(e, t);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    for (r = 0; r < a.length; r++) n = a[r], t.indexOf(n) >= 0 || Object.prototype.propertyIsEnumerable.call(e, n) && (o[n] = e[n])
                }
                return o
            }
            var He = Object(x.forwardRef)((function(e, t) {
                var n = e.children,
                    r = Ue(Be(e, ["children"])),
                    o = r.open,
                    a = Be(r, ["open"]);
                return Object(x.useImperativeHandle)(t, (function() {
                    return {
                        open: o
                    }
                }), [o]), O.a.createElement(x.Fragment, null, n(ze(ze({}, a), {}, {
                    open: o
                })))
            }));
            He.displayName = "Dropzone";
            var We = {
                disabled: !1,
                getFilesFromEvent: function(e) {
                    return $(this, void 0, void 0, (function() {
                        return J(this, (function(t) {
                            return [2, (n = e, n.dataTransfer && e.dataTransfer ? ae(e.dataTransfer, e.type) : oe(e))];
                            var n
                        }))
                    }))
                },
                maxSize: 1 / 0,
                minSize: 0,
                multiple: !0,
                maxFiles: 0,
                preventDropOnDocument: !0,
                noClick: !1,
                noKeyboard: !1,
                noDrag: !1,
                noDragEventsBubbling: !1,
                validator: null
            };
            He.defaultProps = We, He.propTypes = {
                children: z.a.func,
                accept: z.a.oneOfType([z.a.string, z.a.arrayOf(z.a.string)]),
                multiple: z.a.bool,
                preventDropOnDocument: z.a.bool,
                noClick: z.a.bool,
                noKeyboard: z.a.bool,
                noDrag: z.a.bool,
                noDragEventsBubbling: z.a.bool,
                minSize: z.a.number,
                maxSize: z.a.number,
                maxFiles: z.a.number,
                disabled: z.a.bool,
                getFilesFromEvent: z.a.func,
                onFileDialogCancel: z.a.func,
                onDragEnter: z.a.func,
                onDragLeave: z.a.func,
                onDragOver: z.a.func,
                onDrop: z.a.func,
                onDropAccepted: z.a.func,
                onDropRejected: z.a.func,
                validator: z.a.func
            };
            var Ve = {
                isFocused: !1,
                isFileDialogActive: !1,
                isDragActive: !1,
                isDragAccept: !1,
                isDragReject: !1,
                draggedFiles: [],
                acceptedFiles: [],
                fileRejections: []
            };

            function Ue() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                    t = ze(ze({}, We), e),
                    n = t.accept,
                    r = t.disabled,
                    o = t.getFilesFromEvent,
                    a = t.maxSize,
                    i = t.minSize,
                    s = t.multiple,
                    c = t.maxFiles,
                    u = t.onDragEnter,
                    l = t.onDragLeave,
                    d = t.onDragOver,
                    f = t.onDrop,
                    p = t.onDropAccepted,
                    b = t.onDropRejected,
                    h = t.onFileDialogCancel,
                    m = t.preventDropOnDocument,
                    g = t.noClick,
                    v = t.noKeyboard,
                    y = t.noDrag,
                    w = t.noDragEventsBubbling,
                    O = t.validator,
                    j = Object(x.useRef)(null),
                    k = Object(x.useRef)(null),
                    M = Object(x.useReducer)(qe, Ve),
                    A = Pe(M, 2),
                    C = A[0],
                    S = A[1],
                    E = C.isFocused,
                    R = C.isFileDialogActive,
                    D = C.draggedFiles,
                    N = Object(x.useCallback)((function() {
                        k.current && (S({
                            type: "openDialog"
                        }), k.current.value = null, k.current.click())
                    }), [S]),
                    T = function() {
                        R && setTimeout((function() {
                            k.current && (k.current.files.length || (S({
                                type: "closeDialog"
                            }), "function" === typeof h && h()))
                        }), 300)
                    };
                Object(x.useEffect)((function() {
                    return window.addEventListener("focus", T, !1),
                        function() {
                            window.removeEventListener("focus", T, !1)
                        }
                }), [k, R, h]);
                var P = Object(x.useCallback)((function(e) {
                        j.current && j.current.isEqualNode(e.target) && (32 !== e.keyCode && 13 !== e.keyCode || (e.preventDefault(), N()))
                    }), [j, k]),
                    L = Object(x.useCallback)((function() {
                        S({
                            type: "focus"
                        })
                    }), []),
                    _ = Object(x.useCallback)((function() {
                        S({
                            type: "blur"
                        })
                    }), []),
                    F = Object(x.useCallback)((function() {
                        g || (De() ? setTimeout(N, 0) : N())
                    }), [k, g]),
                    z = Object(x.useRef)([]),
                    I = function(e) {
                        j.current && j.current.contains(e.target) || (e.preventDefault(), z.current = [])
                    };
                Object(x.useEffect)((function() {
                    return m && (document.addEventListener("dragover", Se, !1), document.addEventListener("drop", I, !1)),
                        function() {
                            m && (document.removeEventListener("dragover", Se), document.removeEventListener("drop", I))
                        }
                }), [j, m]);
                var B = Object(x.useCallback)((function(e) {
                        e.preventDefault(), e.persist(), Y(e), z.current = [].concat(Te(z.current), [e.target]), Ce(e) && Promise.resolve(o(e)).then((function(t) {
                            Ae(e) && !w || (S({
                                draggedFiles: t,
                                isDragActive: !0,
                                type: "setDraggedFiles"
                            }), u && u(e))
                        }))
                    }), [o, u, w]),
                    H = Object(x.useCallback)((function(e) {
                        if (e.preventDefault(), e.persist(), Y(e), e.dataTransfer) try {
                            e.dataTransfer.dropEffect = "copy"
                        } catch (t) {}
                        return Ce(e) && d && d(e), !1
                    }), [d, w]),
                    W = Object(x.useCallback)((function(e) {
                        e.preventDefault(), e.persist(), Y(e);
                        var t = z.current.filter((function(e) {
                                return j.current && j.current.contains(e)
                            })),
                            n = t.indexOf(e.target); - 1 !== n && t.splice(n, 1), z.current = t, t.length > 0 || (S({
                            isDragActive: !1,
                            type: "setDraggedFiles",
                            draggedFiles: []
                        }), Ce(e) && l && l(e))
                    }), [j, l, w]),
                    V = Object(x.useCallback)((function(e) {
                        e.preventDefault(), e.persist(), Y(e), z.current = [], Ce(e) && Promise.resolve(o(e)).then((function(t) {
                            if (!Ae(e) || w) {
                                var r = [],
                                    o = [];
                                t.forEach((function(e) {
                                    var t = Pe(Oe(e, n), 2),
                                        s = t[0],
                                        c = t[1],
                                        u = Pe(je(e, i, a), 2),
                                        l = u[0],
                                        d = u[1],
                                        f = O ? O(e) : null;
                                    if (s && l && !f) r.push(e);
                                    else {
                                        var p = [c, d];
                                        f && (p = p.concat(f)), o.push({
                                            file: e,
                                            errors: p.filter((function(e) {
                                                return e
                                            }))
                                        })
                                    }
                                })), (!s && r.length > 1 || s && c >= 1 && r.length > c) && (r.forEach((function(e) {
                                    o.push({
                                        file: e,
                                        errors: [xe]
                                    })
                                })), r.splice(0)), S({
                                    acceptedFiles: r,
                                    fileRejections: o,
                                    type: "setFiles"
                                }), f && f(r, o, e), o.length > 0 && b && b(o, e), r.length > 0 && p && p(r, e)
                            }
                        })), S({
                            type: "reset"
                        })
                    }), [s, n, i, a, c, o, f, p, b, w]),
                    U = function(e) {
                        return r ? null : e
                    },
                    q = function(e) {
                        return v ? null : U(e)
                    },
                    G = function(e) {
                        return y ? null : U(e)
                    },
                    Y = function(e) {
                        w && e.stopPropagation()
                    },
                    Q = Object(x.useMemo)((function() {
                        return function() {
                            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                                t = e.refKey,
                                n = void 0 === t ? "ref" : t,
                                o = e.onKeyDown,
                                a = e.onFocus,
                                i = e.onBlur,
                                s = e.onClick,
                                c = e.onDragEnter,
                                u = e.onDragOver,
                                l = e.onDragLeave,
                                d = e.onDrop,
                                f = Be(e, ["refKey", "onKeyDown", "onFocus", "onBlur", "onClick", "onDragEnter", "onDragOver", "onDragLeave", "onDrop"]);
                            return ze(ze(Ie({
                                onKeyDown: q(Ne(o, P)),
                                onFocus: q(Ne(a, L)),
                                onBlur: q(Ne(i, _)),
                                onClick: U(Ne(s, F)),
                                onDragEnter: G(Ne(c, B)),
                                onDragOver: G(Ne(u, H)),
                                onDragLeave: G(Ne(l, W)),
                                onDrop: G(Ne(d, V))
                            }, n, j), r || v ? {} : {
                                tabIndex: 0
                            }), f)
                        }
                    }), [j, P, L, _, F, B, H, W, V, v, y, r]),
                    K = Object(x.useCallback)((function(e) {
                        e.stopPropagation()
                    }), []),
                    Z = Object(x.useMemo)((function() {
                        return function() {
                            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                                t = e.refKey,
                                r = void 0 === t ? "ref" : t,
                                o = e.onChange,
                                a = e.onClick,
                                i = Be(e, ["refKey", "onChange", "onClick"]),
                                c = Ie({
                                    accept: n,
                                    multiple: s,
                                    type: "file",
                                    style: {
                                        display: "none"
                                    },
                                    onChange: U(Ne(o, V)),
                                    onClick: U(Ne(a, K)),
                                    autoComplete: "off",
                                    tabIndex: -1
                                }, r, k);
                            return ze(ze({}, c), i)
                        }
                    }), [k, n, s, V, r]),
                    X = D.length,
                    $ = X > 0 && Me({
                        files: D,
                        accept: n,
                        minSize: i,
                        maxSize: a,
                        multiple: s,
                        maxFiles: c
                    }),
                    J = X > 0 && !$;
                return ze(ze({}, C), {}, {
                    isDragAccept: $,
                    isDragReject: J,
                    isFocused: E && !r,
                    getRootProps: Q,
                    getInputProps: Z,
                    rootRef: j,
                    inputRef: k,
                    open: U(N)
                })
            }

            function qe(e, t) {
                switch (t.type) {
                    case "focus":
                        return ze(ze({}, e), {}, {
                            isFocused: !0
                        });
                    case "blur":
                        return ze(ze({}, e), {}, {
                            isFocused: !1
                        });
                    case "openDialog":
                        return ze(ze({}, e), {}, {
                            isFileDialogActive: !0
                        });
                    case "closeDialog":
                        return ze(ze({}, e), {}, {
                            isFileDialogActive: !1
                        });
                    case "setDraggedFiles":
                        var n = t.isDragActive,
                            r = t.draggedFiles;
                        return ze(ze({}, e), {}, {
                            draggedFiles: r,
                            isDragActive: n
                        });
                    case "setFiles":
                        return ze(ze({}, e), {}, {
                            acceptedFiles: t.acceptedFiles,
                            fileRejections: t.fileRejections
                        });
                    case "reset":
                        return ze(ze({}, e), {}, {
                            isFileDialogActive: !1,
                            isDragActive: !1,
                            draggedFiles: [],
                            acceptedFiles: [],
                            fileRejections: []
                        });
                    default:
                        return e
                }
            }
            n(51), n(151), n(156), n(153), n(215);
            var Ge = n(15),
                Ye = (n(120), function() {
                    var e = {
                            base: "https://twemoji.maxcdn.com/v/13.0.1/",
                            ext: ".png",
                            size: "72x72",
                            className: "emoji",
                            convert: {
                                fromCodePoint: function(e) {
                                    var t = "string" === typeof e ? parseInt(e, 16) : e;
                                    if (t < 65536) return s(t);
                                    return s(55296 + ((t -= 65536) >> 10), 56320 + (1023 & t))
                                },
                                toCodePoint: m
                            },
                            onerror: function() {
                                this.parentNode && this.parentNode.replaceChild(c(this.alt, !1), this)
                            },
                            parse: function(t, n) {
                                n && "function" !== typeof n || (n = {
                                    callback: n
                                });
                                return ("string" === typeof t ? f : d)(t, {
                                    callback: n.callback || u,
                                    attributes: "function" === typeof n.attributes ? n.attributes : b,
                                    base: "string" === typeof n.base ? n.base : e.base,
                                    ext: n.ext || e.ext,
                                    size: n.folder || (r = n.size || e.size, "number" === typeof r ? r + "x" + r : r),
                                    className: n.className || e.className,
                                    onerror: n.onerror || e.onerror
                                });
                                var r
                            },
                            replace: h,
                            test: function(e) {
                                n.lastIndex = 0;
                                var t = n.test(e);
                                return n.lastIndex = 0, t
                            }
                        },
                        t = {
                            "&": "&amp;",
                            "<": "&lt;",
                            ">": "&gt;",
                            "'": "&#39;",
                            '"': "&quot;"
                        },
                        n = /(?:\ud83d\udc68\ud83c\udffb\u200d\ud83e\udd1d\u200d\ud83d\udc68\ud83c[\udffc-\udfff]|\ud83d\udc68\ud83c\udffc\u200d\ud83e\udd1d\u200d\ud83d\udc68\ud83c[\udffb\udffd-\udfff]|\ud83d\udc68\ud83c\udffd\u200d\ud83e\udd1d\u200d\ud83d\udc68\ud83c[\udffb\udffc\udffe\udfff]|\ud83d\udc68\ud83c\udffe\u200d\ud83e\udd1d\u200d\ud83d\udc68\ud83c[\udffb-\udffd\udfff]|\ud83d\udc68\ud83c\udfff\u200d\ud83e\udd1d\u200d\ud83d\udc68\ud83c[\udffb-\udffe]|\ud83d\udc69\ud83c\udffb\u200d\ud83e\udd1d\u200d\ud83d\udc68\ud83c[\udffc-\udfff]|\ud83d\udc69\ud83c\udffb\u200d\ud83e\udd1d\u200d\ud83d\udc69\ud83c[\udffc-\udfff]|\ud83d\udc69\ud83c\udffc\u200d\ud83e\udd1d\u200d\ud83d\udc68\ud83c[\udffb\udffd-\udfff]|\ud83d\udc69\ud83c\udffc\u200d\ud83e\udd1d\u200d\ud83d\udc69\ud83c[\udffb\udffd-\udfff]|\ud83d\udc69\ud83c\udffd\u200d\ud83e\udd1d\u200d\ud83d\udc68\ud83c[\udffb\udffc\udffe\udfff]|\ud83d\udc69\ud83c\udffd\u200d\ud83e\udd1d\u200d\ud83d\udc69\ud83c[\udffb\udffc\udffe\udfff]|\ud83d\udc69\ud83c\udffe\u200d\ud83e\udd1d\u200d\ud83d\udc68\ud83c[\udffb-\udffd\udfff]|\ud83d\udc69\ud83c\udffe\u200d\ud83e\udd1d\u200d\ud83d\udc69\ud83c[\udffb-\udffd\udfff]|\ud83d\udc69\ud83c\udfff\u200d\ud83e\udd1d\u200d\ud83d\udc68\ud83c[\udffb-\udffe]|\ud83d\udc69\ud83c\udfff\u200d\ud83e\udd1d\u200d\ud83d\udc69\ud83c[\udffb-\udffe]|\ud83e\uddd1\ud83c\udffb\u200d\ud83e\udd1d\u200d\ud83e\uddd1\ud83c[\udffb-\udfff]|\ud83e\uddd1\ud83c\udffc\u200d\ud83e\udd1d\u200d\ud83e\uddd1\ud83c[\udffb-\udfff]|\ud83e\uddd1\ud83c\udffd\u200d\ud83e\udd1d\u200d\ud83e\uddd1\ud83c[\udffb-\udfff]|\ud83e\uddd1\ud83c\udffe\u200d\ud83e\udd1d\u200d\ud83e\uddd1\ud83c[\udffb-\udfff]|\ud83e\uddd1\ud83c\udfff\u200d\ud83e\udd1d\u200d\ud83e\uddd1\ud83c[\udffb-\udfff]|\ud83e\uddd1\u200d\ud83e\udd1d\u200d\ud83e\uddd1|\ud83d\udc6b\ud83c[\udffb-\udfff]|\ud83d\udc6c\ud83c[\udffb-\udfff]|\ud83d\udc6d\ud83c[\udffb-\udfff]|\ud83d[\udc6b-\udc6d])|(?:\ud83d[\udc68\udc69]|\ud83e\uddd1)(?:\ud83c[\udffb-\udfff])?\u200d(?:\u2695\ufe0f|\u2696\ufe0f|\u2708\ufe0f|\ud83c[\udf3e\udf73\udf7c\udf84\udf93\udfa4\udfa8\udfeb\udfed]|\ud83d[\udcbb\udcbc\udd27\udd2c\ude80\ude92]|\ud83e[\uddaf-\uddb3\uddbc\uddbd])|(?:\ud83c[\udfcb\udfcc]|\ud83d[\udd74\udd75]|\u26f9)((?:\ud83c[\udffb-\udfff]|\ufe0f)\u200d[\u2640\u2642]\ufe0f)|(?:\ud83c[\udfc3\udfc4\udfca]|\ud83d[\udc6e\udc70\udc71\udc73\udc77\udc81\udc82\udc86\udc87\ude45-\ude47\ude4b\ude4d\ude4e\udea3\udeb4-\udeb6]|\ud83e[\udd26\udd35\udd37-\udd39\udd3d\udd3e\uddb8\uddb9\uddcd-\uddcf\uddd6-\udddd])(?:\ud83c[\udffb-\udfff])?\u200d[\u2640\u2642]\ufe0f|(?:\ud83d\udc68\u200d\u2764\ufe0f\u200d\ud83d\udc8b\u200d\ud83d\udc68|\ud83d\udc68\u200d\ud83d\udc68\u200d\ud83d\udc66\u200d\ud83d\udc66|\ud83d\udc68\u200d\ud83d\udc68\u200d\ud83d\udc67\u200d\ud83d[\udc66\udc67]|\ud83d\udc68\u200d\ud83d\udc69\u200d\ud83d\udc66\u200d\ud83d\udc66|\ud83d\udc68\u200d\ud83d\udc69\u200d\ud83d\udc67\u200d\ud83d[\udc66\udc67]|\ud83d\udc69\u200d\u2764\ufe0f\u200d\ud83d\udc8b\u200d\ud83d[\udc68\udc69]|\ud83d\udc69\u200d\ud83d\udc69\u200d\ud83d\udc66\u200d\ud83d\udc66|\ud83d\udc69\u200d\ud83d\udc69\u200d\ud83d\udc67\u200d\ud83d[\udc66\udc67]|\ud83d\udc68\u200d\u2764\ufe0f\u200d\ud83d\udc68|\ud83d\udc68\u200d\ud83d\udc66\u200d\ud83d\udc66|\ud83d\udc68\u200d\ud83d\udc67\u200d\ud83d[\udc66\udc67]|\ud83d\udc68\u200d\ud83d\udc68\u200d\ud83d[\udc66\udc67]|\ud83d\udc68\u200d\ud83d\udc69\u200d\ud83d[\udc66\udc67]|\ud83d\udc69\u200d\u2764\ufe0f\u200d\ud83d[\udc68\udc69]|\ud83d\udc69\u200d\ud83d\udc66\u200d\ud83d\udc66|\ud83d\udc69\u200d\ud83d\udc67\u200d\ud83d[\udc66\udc67]|\ud83d\udc69\u200d\ud83d\udc69\u200d\ud83d[\udc66\udc67]|\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f|\ud83c\udff3\ufe0f\u200d\ud83c\udf08|\ud83c\udff4\u200d\u2620\ufe0f|\ud83d\udc15\u200d\ud83e\uddba|\ud83d\udc3b\u200d\u2744\ufe0f|\ud83d\udc41\u200d\ud83d\udde8|\ud83d\udc68\u200d\ud83d[\udc66\udc67]|\ud83d\udc69\u200d\ud83d[\udc66\udc67]|\ud83d\udc6f\u200d\u2640\ufe0f|\ud83d\udc6f\u200d\u2642\ufe0f|\ud83e\udd3c\u200d\u2640\ufe0f|\ud83e\udd3c\u200d\u2642\ufe0f|\ud83e\uddde\u200d\u2640\ufe0f|\ud83e\uddde\u200d\u2642\ufe0f|\ud83e\udddf\u200d\u2640\ufe0f|\ud83e\udddf\u200d\u2642\ufe0f|\ud83d\udc08\u200d\u2b1b)|[#*0-9]\ufe0f?\u20e3|(?:[\xa9\xae\u2122\u265f]\ufe0f)|(?:\ud83c[\udc04\udd70\udd71\udd7e\udd7f\ude02\ude1a\ude2f\ude37\udf21\udf24-\udf2c\udf36\udf7d\udf96\udf97\udf99-\udf9b\udf9e\udf9f\udfcd\udfce\udfd4-\udfdf\udff3\udff5\udff7]|\ud83d[\udc3f\udc41\udcfd\udd49\udd4a\udd6f\udd70\udd73\udd76-\udd79\udd87\udd8a-\udd8d\udda5\udda8\uddb1\uddb2\uddbc\uddc2-\uddc4\uddd1-\uddd3\udddc-\uddde\udde1\udde3\udde8\uddef\uddf3\uddfa\udecb\udecd-\udecf\udee0-\udee5\udee9\udef0\udef3]|[\u203c\u2049\u2139\u2194-\u2199\u21a9\u21aa\u231a\u231b\u2328\u23cf\u23ed-\u23ef\u23f1\u23f2\u23f8-\u23fa\u24c2\u25aa\u25ab\u25b6\u25c0\u25fb-\u25fe\u2600-\u2604\u260e\u2611\u2614\u2615\u2618\u2620\u2622\u2623\u2626\u262a\u262e\u262f\u2638-\u263a\u2640\u2642\u2648-\u2653\u2660\u2663\u2665\u2666\u2668\u267b\u267f\u2692-\u2697\u2699\u269b\u269c\u26a0\u26a1\u26a7\u26aa\u26ab\u26b0\u26b1\u26bd\u26be\u26c4\u26c5\u26c8\u26cf\u26d1\u26d3\u26d4\u26e9\u26ea\u26f0-\u26f5\u26f8\u26fa\u26fd\u2702\u2708\u2709\u270f\u2712\u2714\u2716\u271d\u2721\u2733\u2734\u2744\u2747\u2757\u2763\u2764\u27a1\u2934\u2935\u2b05-\u2b07\u2b1b\u2b1c\u2b50\u2b55\u3030\u303d\u3297\u3299])(?:\ufe0f|(?!\ufe0e))|(?:(?:\ud83c[\udfcb\udfcc]|\ud83d[\udd74\udd75\udd90]|[\u261d\u26f7\u26f9\u270c\u270d])(?:\ufe0f|(?!\ufe0e))|(?:\ud83c[\udf85\udfc2-\udfc4\udfc7\udfca]|\ud83d[\udc42\udc43\udc46-\udc50\udc66-\udc69\udc6e\udc70-\udc78\udc7c\udc81-\udc83\udc85-\udc87\udcaa\udd7a\udd95\udd96\ude45-\ude47\ude4b-\ude4f\udea3\udeb4-\udeb6\udec0\udecc]|\ud83e[\udd0c\udd0f\udd18-\udd1c\udd1e\udd1f\udd26\udd30-\udd39\udd3d\udd3e\udd77\uddb5\uddb6\uddb8\uddb9\uddbb\uddcd-\uddcf\uddd1-\udddd]|[\u270a\u270b]))(?:\ud83c[\udffb-\udfff])?|(?:\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f|\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc73\udb40\udc63\udb40\udc74\udb40\udc7f|\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc77\udb40\udc6c\udb40\udc73\udb40\udc7f|\ud83c\udde6\ud83c[\udde8-\uddec\uddee\uddf1\uddf2\uddf4\uddf6-\uddfa\uddfc\uddfd\uddff]|\ud83c\udde7\ud83c[\udde6\udde7\udde9-\uddef\uddf1-\uddf4\uddf6-\uddf9\uddfb\uddfc\uddfe\uddff]|\ud83c\udde8\ud83c[\udde6\udde8\udde9\uddeb-\uddee\uddf0-\uddf5\uddf7\uddfa-\uddff]|\ud83c\udde9\ud83c[\uddea\uddec\uddef\uddf0\uddf2\uddf4\uddff]|\ud83c\uddea\ud83c[\udde6\udde8\uddea\uddec\udded\uddf7-\uddfa]|\ud83c\uddeb\ud83c[\uddee-\uddf0\uddf2\uddf4\uddf7]|\ud83c\uddec\ud83c[\udde6\udde7\udde9-\uddee\uddf1-\uddf3\uddf5-\uddfa\uddfc\uddfe]|\ud83c\udded\ud83c[\uddf0\uddf2\uddf3\uddf7\uddf9\uddfa]|\ud83c\uddee\ud83c[\udde8-\uddea\uddf1-\uddf4\uddf6-\uddf9]|\ud83c\uddef\ud83c[\uddea\uddf2\uddf4\uddf5]|\ud83c\uddf0\ud83c[\uddea\uddec-\uddee\uddf2\uddf3\uddf5\uddf7\uddfc\uddfe\uddff]|\ud83c\uddf1\ud83c[\udde6-\udde8\uddee\uddf0\uddf7-\uddfb\uddfe]|\ud83c\uddf2\ud83c[\udde6\udde8-\udded\uddf0-\uddff]|\ud83c\uddf3\ud83c[\udde6\udde8\uddea-\uddec\uddee\uddf1\uddf4\uddf5\uddf7\uddfa\uddff]|\ud83c\uddf4\ud83c\uddf2|\ud83c\uddf5\ud83c[\udde6\uddea-\udded\uddf0-\uddf3\uddf7-\uddf9\uddfc\uddfe]|\ud83c\uddf6\ud83c\udde6|\ud83c\uddf7\ud83c[\uddea\uddf4\uddf8\uddfa\uddfc]|\ud83c\uddf8\ud83c[\udde6-\uddea\uddec-\uddf4\uddf7-\uddf9\uddfb\uddfd-\uddff]|\ud83c\uddf9\ud83c[\udde6\udde8\udde9\uddeb-\udded\uddef-\uddf4\uddf7\uddf9\uddfb\uddfc\uddff]|\ud83c\uddfa\ud83c[\udde6\uddec\uddf2\uddf3\uddf8\uddfe\uddff]|\ud83c\uddfb\ud83c[\udde6\udde8\uddea\uddec\uddee\uddf3\uddfa]|\ud83c\uddfc\ud83c[\uddeb\uddf8]|\ud83c\uddfd\ud83c\uddf0|\ud83c\uddfe\ud83c[\uddea\uddf9]|\ud83c\uddff\ud83c[\udde6\uddf2\uddfc]|\ud83c[\udccf\udd8e\udd91-\udd9a\udde6-\uddff\ude01\ude32-\ude36\ude38-\ude3a\ude50\ude51\udf00-\udf20\udf2d-\udf35\udf37-\udf7c\udf7e-\udf84\udf86-\udf93\udfa0-\udfc1\udfc5\udfc6\udfc8\udfc9\udfcf-\udfd3\udfe0-\udff0\udff4\udff8-\udfff]|\ud83d[\udc00-\udc3e\udc40\udc44\udc45\udc51-\udc65\udc6a\udc6f\udc79-\udc7b\udc7d-\udc80\udc84\udc88-\udca9\udcab-\udcfc\udcff-\udd3d\udd4b-\udd4e\udd50-\udd67\udda4\uddfb-\ude44\ude48-\ude4a\ude80-\udea2\udea4-\udeb3\udeb7-\udebf\udec1-\udec5\uded0-\uded2\uded5-\uded7\udeeb\udeec\udef4-\udefc\udfe0-\udfeb]|\ud83e[\udd0d\udd0e\udd10-\udd17\udd1d\udd20-\udd25\udd27-\udd2f\udd3a\udd3c\udd3f-\udd45\udd47-\udd76\udd78\udd7a-\uddb4\uddb7\uddba\uddbc-\uddcb\uddd0\uddde-\uddff\ude70-\ude74\ude78-\ude7a\ude80-\ude86\ude90-\udea8\udeb0-\udeb6\udec0-\udec2\uded0-\uded6]|[\u23e9-\u23ec\u23f0\u23f3\u267e\u26ce\u2705\u2728\u274c\u274e\u2753-\u2755\u2795-\u2797\u27b0\u27bf\ue50a])|\ufe0f/g,
                        r = /\uFE0F/g,
                        o = String.fromCharCode(8205),
                        a = /[&<>'"]/g,
                        i = /^(?:iframe|noframes|noscript|script|select|style|textarea)$/,
                        s = String.fromCharCode;
                    return e;

                    function c(e, t) {
                        return document.createTextNode(t ? e.replace(r, "") : e)
                    }

                    function u(e, t) {
                        return "".concat(t.base, t.size, "/", e, t.ext)
                    }

                    function l(e) {
                        return m(e.indexOf(o) < 0 ? e.replace(r, "") : e)
                    }

                    function d(e, t) {
                        for (var r, o, a, s, u, d, f, p, b, h, m, g, v, y = function e(t, n) {
                                for (var r, o, a = t.childNodes, s = a.length; s--;) 3 === (o = (r = a[s]).nodeType) ? n.push(r) : 1 !== o || "ownerSVGElement" in r || i.test(r.nodeName.toLowerCase()) || e(r, n);
                                return n
                            }(e, []), w = y.length; w--;) {
                            for (a = !1, s = document.createDocumentFragment(), d = (u = y[w]).nodeValue, p = 0; f = n.exec(d);) {
                                if ((b = f.index) !== p && s.appendChild(c(d.slice(p, b), !0)), g = l(m = f[0]), p = b + m.length, v = t.callback(g, t), g && v) {
                                    for (o in (h = new Image).onerror = t.onerror, h.setAttribute("draggable", "false"), r = t.attributes(m, g)) r.hasOwnProperty(o) && 0 !== o.indexOf("on") && !h.hasAttribute(o) && h.setAttribute(o, r[o]);
                                    h.className = t.className, h.alt = m, h.src = v, a = !0, s.appendChild(h)
                                }
                                h || s.appendChild(c(m, !1)), h = null
                            }
                            a && (p < d.length && s.appendChild(c(d.slice(p), !0)), u.parentNode.replaceChild(s, u))
                        }
                        return e
                    }

                    function f(e, t) {
                        return h(e, (function(e) {
                            var n, r, o = e,
                                i = l(e),
                                s = t.callback(i, t);
                            if (i && s) {
                                for (r in o = "<img ".concat('class="', t.className, '" ', 'draggable="false" ', 'alt="', e, '"', ' src="', s, '"'), n = t.attributes(e, i)) n.hasOwnProperty(r) && 0 !== r.indexOf("on") && -1 === o.indexOf(" " + r + "=") && (o = o.concat(" ", r, '="', n[r].replace(a, p), '"'));
                                o = o.concat("/>")
                            }
                            return o
                        }))
                    }

                    function p(e) {
                        return t[e]
                    }

                    function b() {
                        return null
                    }

                    function h(e, t) {
                        return String(e).replace(n, t)
                    }

                    function m(e, t) {
                        for (var n = [], r = 0, o = 0, a = 0; a < e.length;) r = e.charCodeAt(a++), o ? (n.push((65536 + (o - 55296 << 10) + (r - 56320)).toString(16)), o = 0) : 55296 <= r && r <= 56319 ? o = r : n.push(r.toString(16));
                        return n.join(t || "-")
                    }
                }()),
                Qe = n(347),
                Ke = {
                    ALLOWED_TAGS: ["img"],
                    ALLOWED_ATTR: ["class", "src", "alt"]
                },
                Ze = {
                    ALLOWED_TAGS: ["img", "a"],
                    ALLOWED_ATTR: ["class", "href", "target", "src", "alt"]
                },
                Xe = function(e) {
                    return e.replace(new RegExp("<", "g"), "&lt;").replace(new RegExp(">", "g"), "&gt;")
                },
                $e = function(e) {
                    if ("string" !== typeof e) return "";
                    var t, n = Xe(e);
                    return n = n.replace(/((?:href|src)=['"])?(\b(https?|ftp):\/\/[-A-Z0-9+&@#/%?=~_|!:,.;]*[-A-Z0-9+&@#/%=~_|])/gim, (function(e, t) {
                        return "undefined" !== typeof t ? e : '<a href="'.concat(e, '" target="_blank" rel="noopener noreferrer">').concat(e, "</a>")
                    })).replace(/(^|\s)(([a-zA-Z0-9-_.+])+@[a-zA-Z0-9_]+?(\.[a-zA-Z]{2,})+)/gim, (function(e) {
                        var t = "",
                            n = e;
                        return " " === e[0] && (t = " ", n = n.slice(1)), "".concat(t, '<a href="mailto:').concat(n, '" target="_blank" rel="noopener noreferrer">').concat(n, "</a>")
                    })).replace(/(^|[^/:>])(www\.[\S]+(\b|$))/gim, '$1<a href="http://$2" target="_blank" rel="noopener noreferrer">$2</a>'), n = Ye.parse(n), t = n, n = Object(Qe.sanitize)(t, Ze)
                },
                Je = function(e) {
                    if ("string" !== typeof e) return "";
                    var t = Xe(e);
                    return t = Ye.parse(t), t = Object(Qe.sanitize)(t, Ke)
                };

            function et(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function tt(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? et(Object(n), !0).forEach((function(t) {
                        w()(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : et(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }
            var nt = function(e) {
                var t = e.values.reduce((function(e, t) {
                    return tt(tt({}, e), {}, w()({}, t, Object(Ge.c)(t)))
                }), {});
                return e.render(t)
            };
            nt.propTypes = {
                values: z.a.arrayOf(z.a.string).isRequired,
                render: z.a.func.isRequired
            };
            var rt = function(e) {
                var t = e.value,
                    n = e.children,
                    r = e.replacements,
                    o = e.fallback,
                    a = e.linkify,
                    s = e.emojify,
                    c = Object(x.useState)(0),
                    u = i()(c, 2)[1],
                    l = function() {
                        u((function(e) {
                            return !e
                        }))
                    };
                return Object(x.useEffect)((function() {
                    return Ge.d.on("translationsChanged", l),
                        function() {
                            Ge.d.off("translationsChanged", l)
                        }
                }), []), n ? Object(S.d)(nt, {
                    values: t,
                    render: n
                }) : r ? Object(S.d)(O.a.Fragment, null, Object(Ge.c)(t, r, o)) : a || s ? Object(S.d)("span", {
                    dangerouslySetInnerHTML: {
                        __html: $e(Object(Ge.c)(t, null, o))
                    }
                }) : Object(S.d)(O.a.Fragment, null, Object(Ge.c)(t, null, o))
            };
            rt.defaultProps = {
                fallback: null,
                replacements: null,
                emojify: !1,
                linkify: !1,
                children: void 0
            };
            var ot = rt,
                at = function(e) {
                    return Object(S.d)("div", {
                        className: e.className,
                        style: e.avatarSrc ? {
                            backgroundImage: "url(".concat(e.avatarSrc, ")")
                        } : void 0
                    }, e.name && Object(S.d)("span", null, e.name))
                };
            at.defaultProps = {
                name: null,
                avatarSrc: null,
                className: null
            };
            var it = O.a.memo(at),
                st = function(e) {
                    var t = e.operators.slice(0, 4);
                    return Object(S.d)(O.a.Fragment, null, Object(S.d)("div", {
                        className: "avatars-wrapper operators-avatar-".concat(t.length > 3 ? "4" : t.length)
                    }, t.map((function(e) {
                        return Object(S.d)(it, {
                            key: e.id,
                            className: "header-ava",
                            avatarSrc: e.avatarSrc
                        })
                    }))), Object(S.d)("h2", {
                        className: "oneline"
                    }, Object(S.d)(ot, {
                        value: "newWidgetHeaderText",
                        fallback: "\xa0",
                        emojify: !0
                    })))
                },
                ct = (n(33), n(152), n(214), n(6)),
                ut = function(e) {
                    var t = e.operators,
                        n = e.assignedOperators,
                        r = n.map((function(e) {
                            return t.find((function(t) {
                                return t.id === e
                            }))
                        })).filter((function(e) {
                            return "undefined" !== typeof e
                        })).slice(0, 4),
                        o = function(e) {
                            try {
                                var t = "";
                                if (e.length > 1) {
                                    var n = e.map((function(e) {
                                            return e.name
                                        })),
                                        r = n.splice(-2).join(" ".concat(Object(Ge.c)("widgetHeaderAnd", null, "and"), " "));
                                    n.push(r), t = n.join(", ")
                                } else t = e[0].name;
                                return t.trim() ? t : "\xa0"
                            } catch (o) {
                                return Object(ct.a)(o), "\xa0"
                            }
                        }(r);
                    return Object(S.d)(O.a.Fragment, null, Object(S.d)("div", {
                        className: "avatars-wrapper operators-avatar-".concat(n.length > 3 ? "4" : n.length)
                    }, r.map((function(e) {
                        return Object(S.d)(it, {
                            key: e.id,
                            className: "header-ava",
                            avatarSrc: e.avatarSrc
                        })
                    }))), Object(S.d)("h2", {
                        className: "twolines"
                    }, Object(S.d)("span", {
                        className: "top-heading"
                    }, Object(S.d)(ot, {
                        value: "chatWith",
                        fallback: "Chat with"
                    }), " "), o), Object(S.d)("span", {
                        className: "heading-hover"
                    }, Object(S.d)(ot, {
                        value: "chatWith",
                        fallback: "Chat with"
                    }), " ", o))
                },
                lt = n(1),
                dt = Object(x.forwardRef)((function(e, t) {
                    var n = e.widgetColor,
                        r = e.isProjectOnline;
                    if (r && !Object(Ge.c)("weAreOnline") || !r && !Object(Ge.c)("alwaysOnlineTopBar")) return Object(S.d)("div", {
                        ref: t,
                        className: "offline-message",
                        style: {
                            height: 0,
                            padding: 0
                        }
                    });
                    var o = n[0] !== n[1] ? "linear-gradient(135deg, ".concat(Object(lt.v)(n[0], ".72"), " 0%, ").concat(Object(lt.v)(n[1], ".72"), " 100%)") : Object(lt.v)(Object(lt.f)(n[0], -.1), ".72");
                    return Object(S.d)("div", {
                        ref: t,
                        className: "offline-message",
                        style: w()({}, "".concat(o.includes("linear-gradient") ? "backgroundImage" : "backgroundColor"), o)
                    }, r ? Object(S.d)("span", {
                        className: "online"
                    }, Object(S.d)(ot, {
                        value: "weAreOnline",
                        emojify: !0
                    })) : Object(S.d)("span", null, Object(S.d)(ot, {
                        value: "alwaysOnlineTopBar",
                        emojify: !0
                    })))
                })),
                ft = n(312),
                pt = n(0),
                bt = n(11),
                ht = n(7),
                mt = n(32),
                gt = function() {
                    var e = Object(j.c)(),
                        t = Object(j.d)((function(e) {
                            return e.notificationSnoozed
                        })),
                        n = Object(j.d)((function(e) {
                            return e.newMessageDisabled
                        })),
                        r = Object(j.d)((function(e) {
                            return e.isSoundEnabled
                        })),
                        o = Object(j.d)((function(e) {
                            return e.view
                        })),
                        a = Object(x.useState)(t),
                        s = i()(a, 1)[0],
                        c = Object(x.useCallback)((function() {
                            e(Object(pt.qc)(!1)), e(Object(pt.oc)(!t))
                        }), [t, e]),
                        u = Object(x.useCallback)((function() {
                            if (e(Object(pt.Sc)(mt.a.rateConversationClicked)), e(Object(pt.qc)(!1)), n) e(Object(pt.Dc)(Object(Ge.c)("newMessageDisabledAlert", null, "Please enter your email first.")));
                            else {
                                var t = Object(bt.l)();
                                e(Object(pt.xb)(t))
                            }
                        }), [e, n]),
                        l = Object(x.useCallback)((function(t) {
                            e(Object(pt.qc)(t))
                        }), [e]);
                    return Object(S.d)("div", {
                        className: "options-dropdown"
                    }, Object(S.d)("ul", null, r && (s ? Object(S.d)("li", null, Object(S.d)("button", {
                        type: "button",
                        className: "material-icons",
                        onClick: c,
                        onFocus: function() {
                            l(!0)
                        },
                        onBlur: function() {
                            l(!1)
                        }
                    }, Object(S.d)(ft.t, null), Object(S.d)("span", null, Object(S.d)(ot, {
                        value: "turnOnNotifications"
                    })))) : Object(S.d)("li", null, Object(S.d)("button", {
                        type: "button",
                        className: "material-icons",
                        onClick: c,
                        onFocus: function() {
                            l(!0)
                        },
                        onBlur: function() {
                            l(!1)
                        }
                    }, Object(S.d)(ft.s, null), Object(S.d)("span", null, Object(S.d)(ot, {
                        value: "turnOffNotifications"
                    }))))), o !== ht.a.welcome && Object(S.d)("li", null, Object(S.d)("button", {
                        type: "button",
                        className: "material-icons",
                        onClick: u,
                        onFocus: function() {
                            l(!0)
                        },
                        onBlur: function() {
                            l(!1)
                        }
                    }, Object(S.d)(ft.w, null), Object(S.d)("span", null, Object(S.d)(ot, {
                        value: "rateConversation"
                    }))))))
                },
                vt = n(44),
                yt = 66,
                wt = 104,
                xt = 142,
                Ot = function(e) {
                    var t = e.statusBarRef,
                        n = Object(j.d)((function(e) {
                            return e.operators
                        })),
                        r = Object(x.useMemo)((function() {
                            return n.find((function(e) {
                                return e.isOnline
                            })) ? n.filter((function(e) {
                                return e.isOnline
                            })) : n
                        }), [n]),
                        o = Object(x.useState)(r),
                        a = i()(o, 2),
                        s = a[0],
                        c = a[1],
                        u = Object(x.useRef)(null);
                    Object(x.useEffect)((function() {
                        if (null !== t && void 0 !== t && t.current && null !== u && void 0 !== u && u.current) {
                            var e = t.current.clientHeight > 0 ? t.current.clientHeight - 0 : 40,
                                n = function(e) {
                                    var t = 3;
                                    return e < yt ? t = 0 : e < wt ? t = 1 : e < xt && (t = 2), t
                                }(u.current.clientHeight - e);
                            c(r.slice(0, n))
                        }
                    }), [r, t]);
                    var l = Object(A.useSpring)({
                        from: {
                            avatarTransition: 0
                        },
                        avatarTransition: 1
                    }).avatarTransition;
                    return Object(S.d)("div", {
                        className: "operators",
                        ref: u
                    }, s.map((function(e, t) {
                        return Object(S.d)(A.animated.div, {
                            style: {
                                zIndex: s.length - t + 1,
                                transform: l.interpolate((function(e) {
                                    var n = s.length - t - 1,
                                        r = 3 - s.length + 1;
                                    return "translate3d(0,".concat(-7 * r + 7 * r * e + 26 * n + e * n * 12, "px,0)")
                                }))
                            },
                            key: e.id
                        }, Object(S.d)(it, {
                            name: e.name,
                            avatarSrc: e.avatarSrc,
                            className: "ava48"
                        }))
                    })))
                };
            var jt = {
                    name: "k4xk3i",
                    styles: "span{background:#fff;padding:6px 8px;border-radius:2px;box-shadow:0 2px 8px 0 rgba(0, 18, 46, 0.32);font-size:13px;position:absolute;opacity:0;pointer-events:none;white-space:nowrap;transition:all 0.16s ease-in-out;z-index:1;right:calc(100% + 10px);top:50%;transform:translate(5px,-50%);color:#06132b;}&:hover{span{opacity:1;transform:translate(0,-50%);}}"
                },
                kt = function() {
                    return Object(Ge.c)("welcomeMessage", null, "") ? Object(S.d)("p", {
                        className: "start-message"
                    }, Object(S.d)(ot, {
                        value: "welcomeMessage",
                        emojify: !0
                    })) : null
                },
                Mt = function() {
                    var e = Object(x.useRef)(null),
                        t = Object(j.c)(),
                        n = Object(j.d)((function(e) {
                            return e.showOptionsDropdown
                        })),
                        r = Object(j.d)((function(e) {
                            return e.bannerImage
                        })),
                        o = Object(j.d)((function(e) {
                            return e.isProjectOnline
                        })),
                        a = Object(j.d)((function(e) {
                            return e.widgetColor
                        })),
                        s = Object(j.d)(vt.b),
                        c = Object(j.d)((function(e) {
                            return e.isMobile
                        })),
                        u = Object(j.d)((function(e) {
                            return e.isSoundEnabled
                        })),
                        l = Object(x.useState)(""),
                        d = i()(l, 2),
                        f = d[0],
                        p = d[1];
                    return Object(x.useEffect)((function() {
                        p(a[0] === a[1] ? a[0] : "linear-gradient(135deg, ".concat(a[0], " 0%, ").concat(a[1], " 100%)"))
                    }), [a]), Object(S.d)("div", {
                        className: "chat-header",
                        style: {
                            background: f,
                            color: a[2]
                        }
                    }, "" !== r && Object(S.d)("div", {
                        className: "banner",
                        style: {
                            backgroundImage: "url(".concat(r, ")")
                        }
                    }), Object(S.d)("h2", {
                        className: "h2-banner",
                        style: {
                            color: a[2]
                        }
                    }, Object(S.d)(ot, {
                        value: "newWidgetHeaderText",
                        fallback: "Chat with us",
                        emojify: !0
                    })), (!s || s && c) && Object(S.d)("button", {
                        className: "material-icons exit-chat i-banner",
                        onClick: function() {
                            t(Object(pt.Sc)(mt.a.chatClosed)), t(Object(pt.Ic)(!1)), t(Object(pt.gc)(!1))
                        },
                        style: {
                            color: a[2]
                        },
                        type: "button",
                        "aria-label": Object(Ge.c)("minimize", null, "Minimize"),
                        css: jt
                    }, Object(S.d)(ft.q, null), Object(S.d)("span", null, Object(Ge.c)("minimize", null, "Minimize"))), u && Object(S.d)(O.a.Fragment, null, Object(S.d)("button", {
                        className: "material-icons options i-banner",
                        onClick: function(e) {
                            !(0 === e.nativeEvent.pageX && 0 === e.nativeEvent.pageY) && n && e.currentTarget.blur(), t(Object(pt.Sc)(mt.a.optionsButtonClicked)), t(Object(pt.qc)(!n))
                        },
                        onBlur: function() {
                            t(Object(pt.qc)(!1))
                        },
                        style: {
                            color: a[2]
                        },
                        type: "button",
                        "aria-label": n ? Object(Ge.c)("closeOptions", null, "Close options") : Object(Ge.c)("openOptions", null, "Open options"),
                        css: jt
                    }, Object(S.d)(ft.u, null), Object(S.d)("span", null, n ? Object(Ge.c)("closeOptions", null, "Close options") : Object(Ge.c)("openOptions", null, "Open options"))), Object(S.d)(X, { in: n,
                        classNames: "dropdownFade"
                    }, Object(S.d)(gt, null))), Object(S.d)(kt, null), Object(S.d)(Ot, {
                        statusBarRef: e
                    }), Object(S.d)(dt, {
                        widgetColor: a,
                        isProjectOnline: o,
                        ref: e
                    }))
                },
                At = function() {
                    var e = Object(j.d)((function(e) {
                            return e.assignedOperators
                        })),
                        t = Object(j.d)((function(e) {
                            return e.operators
                        })),
                        n = Object(j.d)((function(e) {
                            return e.showOptionsDropdown
                        })),
                        r = Object(j.d)((function(e) {
                            return e.isProjectOnline
                        })),
                        o = Object(j.d)((function(e) {
                            return e.widgetColor
                        })),
                        a = Object(j.d)(vt.b),
                        s = Object(j.d)((function(e) {
                            return e.isMobile
                        })),
                        c = Object(j.c)(),
                        u = Object(x.useState)(""),
                        l = i()(u, 2),
                        d = l[0],
                        f = l[1];
                    return Object(x.useEffect)((function() {
                        f(o[0] === o[1] ? o[0] : "linear-gradient(135deg, ".concat(o[0], " 0%, ").concat(o[1], " 100%)"))
                    }), [o]), Object(S.d)("div", {
                        className: "chat-header ".concat(r ? "project-online" : ""),
                        style: {
                            background: d,
                            color: o[2]
                        }
                    }, 0 === e.length ? Object(S.d)(st, {
                        operators: t
                    }) : Object(S.d)(ut, {
                        operators: t,
                        assignedOperators: e
                    }), (!a || a && s) && Object(S.d)("button", {
                        className: "material-icons exit-chat ripple",
                        onClick: function() {
                            c(Object(pt.Sc)(mt.a.chatClosed)), c(Object(pt.Ic)(!1)), c(Object(pt.gc)(!1))
                        },
                        style: {
                            color: o[2]
                        },
                        type: "button",
                        "aria-label": Object(Ge.c)("minimize", null, "Minimize"),
                        css: jt
                    }, Object(S.d)(ft.q, null), Object(S.d)("span", null, Object(Ge.c)("minimize", null, "Minimize"))), Object(S.d)("button", {
                        className: "material-icons options ripple",
                        onClick: function(e) {
                            !(0 === e.nativeEvent.pageX && 0 === e.nativeEvent.pageY) && n && e.currentTarget.blur(), c(Object(pt.Sc)(mt.a.optionsButtonClicked)), c(Object(pt.qc)(!n))
                        },
                        onBlur: function() {
                            c(Object(pt.qc)(!1))
                        },
                        style: {
                            color: o[2]
                        },
                        type: "button",
                        "aria-label": n ? Object(Ge.c)("closeOptions", null, "Close options") : Object(Ge.c)("openOptions", null, "Open options"),
                        css: jt
                    }, Object(S.d)(ft.u, null), Object(S.d)("span", null, n ? Object(Ge.c)("closeOptions", null, "Close options") : Object(Ge.c)("openOptions", null, "Open options"))), Object(S.d)(X, { in: n,
                        classNames: "dropdownFade"
                    }, Object(S.d)(gt, null)), Object(S.d)(dt, {
                        widgetColor: o,
                        isProjectOnline: r
                    }))
                },
                Ct = n(18),
                St = n(42);

            function Et(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }

            function Rt() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 820,
                    t = O.a.useState(""),
                    n = i()(t, 2),
                    r = n[0],
                    o = n[1],
                    a = O.a.useRef();

                function s() {
                    o("shake"), clearTimeout(a.current), a.current = null, a.current = setTimeout((function() {
                        o("")
                    }), e)
                }
                return {
                    triggerShake: s,
                    shakeClassName: r,
                    shouldShake: "shake" === r
                }
            }
            var Dt = n(28),
                Nt = n(4);

            function Tt(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }
            var Pt = Ct.g,
                Lt = function(e, t) {
                    return function(e, t) {
                        var n = Object(St.c)();
                        if (!n) return 0;
                        var r = ("OffscreenCanvas" in window ? new OffscreenCanvas(500, 100) : n.createElement("canvas")).getContext("2d");
                        return r.font = t, Math.ceil(r.measureText(e).width)
                    }(e, '17px "Mulish", sans-serif') > t
                },
                _t = function(e) {
                    b()(n, e);
                    var t = Tt(n);

                    function n() {
                        var e;
                        c()(this, n);
                        for (var r = arguments.length, o = new Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                        return e = t.call.apply(t, [this].concat(o)), w()(f()(e), "state", {
                            input: "",
                            inputRows: 1,
                            isPlaceholderToLong: !1
                        }), w()(f()(e), "inputRef", null), w()(f()(e), "initialInputScrollHeight", 0), w()(f()(e), "oldInputRows", 1), w()(f()(e), "oldPlaceholder", ""), w()(f()(e), "windowRef", Object(St.e)()), w()(f()(e), "osName", Object(lt.r)().name.toLowerCase()), w()(f()(e), "setInputRef", (function(t) {
                            e.inputRef = t
                        })), w()(f()(e), "onInputChange", (function(t) {
                            var n = e.state.input.length,
                                r = t.target.value;
                            e.setState({
                                input: r
                            }, (function() {
                                e.adjustInputRows(n)
                            })), e.dispatchVisitorIsTyping(r, e.state.input)
                        })), w()(f()(e), "adjustInputRows", (function() {
                            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
                            if (e.oldInputRows = e.state.inputRows, "" === e.state.input && !e.state.isPlaceholderToLong) return e.setState({
                                inputRows: 1
                            }), 1 === e.oldInputRows || e.props.isMobile || e.props.dispatch(Object(pt.lc)("chatSize".concat(1))), !0;
                            if (3 === e.state.inputRows && null !== t && e.state.input.length > t) return !0;
                            var n = e.getCalculatedInputRows();
                            return n === e.oldInputRows || e.props.isMobile || e.props.dispatch(Object(pt.lc)("chatSize".concat(n))), e.setState({
                                inputRows: n
                            }), !0
                        })), w()(f()(e), "getCalculatedInputRows", (function() {
                            var t = Math.ceil((e.inputRef.scrollHeight - e.initialInputScrollHeight) / Pt) + 1;
                            return e.props.isMobile && t > 2 ? 2 : (t > 3 ? t = 3 : e.state.isPlaceholderToLong && t < 2 ? t = 2 : t < 1 && (t = 1), t)
                        })), w()(f()(e), "restoreMessage", (function() {
                            var t = e.props.blockedMessage;
                            setTimeout((function() {
                                e.setState({
                                    input: t
                                }, (function() {
                                    e.adjustInputRows()
                                }))
                            }), 0), e.props.dispatch(Object(pt.ec)())
                        })), w()(f()(e), "onKeyDown", (function(t) {
                            var n = 13 === t.keyCode;
                            return !(!n || n && t.shiftKey) && (t.preventDefault(), e.props.dispatch(Object(pt.kc)(!0)), !0)
                        })), w()(f()(e), "onClick", (function() {
                            e.props.newMessageDisabled && e.props.view !== ht.a.welcome && Object(St.a)()
                        })), w()(f()(e), "dispatchVisitorIsTyping", (function(t, n) {
                            var r = t.trim(),
                                o = n.trim();
                            return ("" !== r || r !== o) && (e.props.dispatch(Object(pt.vc)(r)), !0)
                        })), w()(f()(e), "sendMessage", (function() {
                            var t = e.props,
                                n = t.dispatch,
                                r = t.view,
                                o = t.isEmojiPanelVisible,
                                a = t.triggerShake,
                                i = e.state.input;
                            return "" === (i = i.trim()) && r === ht.a.welcome && n(Object(pt.Pc)()), "" === i ? (a(), !1) : (n(Object(pt.bc)(i)), e.setState({
                                input: ""
                            }), o && n(Object(pt.Ic)(!1)), e.setState({
                                inputRows: 1
                            }), !0)
                        })), w()(f()(e), "fixWebviewTouchAreas", (function() {
                            try {
                                e.props.isMobile && "ios" === e.osName && (e.windowRef.parent.scrollTo(e.windowRef.parent.scrollX, e.windowRef.parent.scrollY - 1), e.windowRef.parent.scrollTo(e.windowRef.parent.scrollX, e.windowRef.parent.scrollY + 1))
                            } catch (t) {}
                        })), e
                    }
                    return l()(n, [{
                        key: "componentDidMount",
                        value: function() {
                            var e = this;
                            setTimeout((function() {
                                e.inputRef && (e.initialInputScrollHeight = e.inputRef.scrollHeight)
                            }), 0), setTimeout((function() {
                                !e.props.newMessageDisabled && null !== e.props.blockedMessage && e.restoreMessage()
                            }), 0);
                            var t = this.inputRef,
                                n = t.placeholder,
                                r = t.offsetWidth;
                            this.oldPlaceholder = n, Lt(n, r) && this.setState({
                                inputRows: 2,
                                isPlaceholderToLong: !0
                            })
                        }
                    }, {
                        key: "componentDidUpdate",
                        value: function(e) {
                            this.props.sendVisitorMessageFlag && !e.sendVisitorMessageFlag && this.sendMessage();
                            var t = this.inputRef,
                                n = t.placeholder,
                                r = t.offsetWidth;
                            this.oldPlaceholder !== n && (this.oldPlaceholder = n, Lt(n, r) ? this.setState({
                                inputRows: 2,
                                isPlaceholderToLong: !0
                            }) : this.setState({
                                isPlaceholderToLong: !1
                            }))
                        }
                    }, {
                        key: "componentWillUnmount",
                        value: function() {
                            var e = this.state.input;
                            "" !== e && this.props.dispatch(Object(pt.ec)(e))
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this,
                                t = this.props.lastMessage,
                                n = this.props.newMessageDisabled && this.props.view !== ht.a.welcome;
                            return Object(S.d)(ot, {
                                value: ["clickToProvideEmail", "onlineMessagePlaceholder", "hitTheButtons"]
                            }, (function(r) {
                                var o = r.clickToProvideEmail,
                                    a = r.onlineMessagePlaceholder,
                                    i = r.hitTheButtons,
                                    s = a;
                                return n ? s = o : function(e) {
                                    if (!e) return !1;
                                    var t = e.type === bt.e.cards,
                                        n = e.quickReplies && e.quickReplies.length > 0,
                                        r = e.buttons && e.buttons.length > 0;
                                    return !!(t || n || r)
                                }(t) && !e.props.isLastMessage24h && (s = i), Object(S.d)("textarea", {
                                    id: "new-message-textarea",
                                    value: e.state.input,
                                    onChange: e.onInputChange,
                                    onKeyDown: e.onKeyDown,
                                    onClick: e.onClick,
                                    ref: e.setInputRef,
                                    rows: e.state.inputRows,
                                    placeholder: s,
                                    onFocus: function() {
                                        !n && e.props.isMobile && e.props.dispatch(Object(pt.Kb)(!0))
                                    },
                                    onBlur: function() {
                                        !n && e.props.isMobile && setTimeout((function() {
                                            e.props.dispatch(Object(pt.Kb)(!1)), e.fixWebviewTouchAreas()
                                        }), 100)
                                    },
                                    readOnly: n,
                                    className: "".concat(n ? "disabled" : "", " ").concat(e.props.shakeClassName),
                                    "aria-label": Object(Ge.c)("newMessage", null, "New message"),
                                    "data-testid": "newMessageTextarea"
                                })
                            }))
                        }
                    }], [{
                        key: "getDerivedStateFromProps",
                        value: function(e, t) {
                            return e.newMessageEmoji ? (e.dispatch(Object(pt.wb)()), {
                                input: t.input + e.newMessageEmoji
                            }) : e.blockedMessage && e.newMessageDisabled ? {
                                input: e.blockedMessage
                            } : null
                        }
                    }]), n
                }(O.a.Component);
            _t.defaultProps = {
                newMessageEmoji: null,
                blockedMessage: null,
                triggerShake: function() {},
                shakeClassName: "",
                lastMessage: void 0
            };
            var Ft, zt = Object(j.b)((function(e) {
                    return {
                        newMessageEmoji: e.newMessageEmoji,
                        isMobile: e.isMobile,
                        sendVisitorMessageFlag: e.sendVisitorMessageFlag,
                        isEmojiPanelVisible: e.isEmojiPanelVisible,
                        newMessageDisabled: e.newMessageDisabled,
                        blockedMessage: e.blockedMessage,
                        view: e.view,
                        lastMessage: Object(Dt.e)(e),
                        isLastMessage24h: Object(Dt.l)(e)
                    }
                }))((Ft = _t, function(e) {
                    b()(n, e);
                    var t = Et(n);

                    function n() {
                        var e;
                        c()(this, n);
                        for (var r = arguments.length, o = new Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                        return e = t.call.apply(t, [this].concat(o)), w()(f()(e), "state", {
                            shakeClassName: ""
                        }), w()(f()(e), "clearId", null), w()(f()(e), "isMounted", !1), w()(f()(e), "triggerShake", (function() {
                            e.setState({
                                shakeClassName: "shake"
                            }), clearTimeout(e.clearId), e.clearId = null, e.clearId = setTimeout((function() {
                                e.isMounted && e.setState({
                                    shakeClassName: ""
                                })
                            }), 820)
                        })), e
                    }
                    return l()(n, [{
                        key: "componentDidMount",
                        value: function() {
                            this.isMounted = !0
                        }
                    }, {
                        key: "componentWillUnmount",
                        value: function() {
                            this.isMounted = !1
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = {
                                triggerShake: this.triggerShake,
                                shakeClassName: this.state.shakeClassName
                            };
                            return Object(S.d)(Ft, o()({}, this.props, e))
                        }
                    }]), n
                }(O.a.Component))),
                It = function(e) {
                    return Object(S.d)("div", {
                        className: "bots-dropdown"
                    }, e.isBotActive && Object(S.d)("ul", {
                        className: "bots-cancel"
                    }, Object(S.d)("li", null, Object(S.d)("span", {
                        tabIndex: "0",
                        onClick: e.onCancelBotClick,
                        onKeyUp: function(t) {
                            13 === t.keyCode && e.onCancelBotClick()
                        },
                        onFocus: e.onBotFocus,
                        onBlur: e.onBotBlur,
                        role: "button"
                    }, Object(S.d)(ft.h, null), " ", Object(Ge.c)("startOver", null, "Start over")))), !e.isBotActive && Object(S.d)("ul", null, Object(S.d)("li", null, Object(S.d)("span", {
                        onClick: function() {
                            e.onBotClick()
                        },
                        onKeyUp: function(t) {
                            13 === t.keyCode && e.onBotClick()
                        },
                        onFocus: e.onBotFocus,
                        onBlur: e.onBotBlur,
                        role: "button",
                        tabIndex: e.isBotActive ? "-1" : "0"
                    }, Object(S.d)(ft.j, null), " ", Object(Ge.c)("startTheBot", null, "Start the Bot")))))
                },
                Bt = function(e) {
                    return Object(S.d)(O.a.Fragment, null, Object(S.d)("span", {
                        className: "pulse"
                    }), Object(S.d)("span", {
                        className: "pulse-white"
                    }), Object(S.d)("span", {
                        className: "pulse animation-delay",
                        onAnimationEnd: function() {
                            e.dispatch(Object(pt.Gb)())
                        }
                    }), Object(S.d)("span", {
                        className: "pulse-white animation-delay"
                    }))
                },
                Ht = Object(j.b)((function(e) {
                    return {
                        isBotActive: e.isBotActive,
                        assignedOperators: e.assignedOperators
                    }
                }))((function(e) {
                    return Object(S.d)("button", {
                        type: "button",
                        className: "bots-button material-icons ripple ".concat(e.isBotActive || 0 !== e.assignedOperators.length || e.disableButtonAnimation ? "" : "bots-animation"),
                        onClick: e.onClick,
                        onBlur: e.onBlur
                    }, Object(S.d)(ft.e, null), !e.isBotActive && 0 === e.assignedOperators.length && !e.disableButtonAnimation && Object(S.d)(Bt, {
                        dispatch: e.dispatch
                    }))
                })),
                Wt = function() {
                    var e = Object(x.useState)(!1),
                        t = i()(e, 2),
                        n = t[0],
                        r = t[1],
                        o = Object(j.d)((function(e) {
                            return e.bots
                        })),
                        a = Object(j.d)((function(e) {
                            return e.isBotActive
                        })),
                        s = Object(j.d)((function(e) {
                            return e.disableBotsButtonAnimation
                        })),
                        c = Object(j.c)();
                    return o && 0 !== o.length ? Object(S.d)(O.a.Fragment, null, Object(S.d)(Ht, {
                        onBlur: function() {
                            r(!1)
                        },
                        onClick: function() {
                            r((function(e) {
                                return !e
                            })), c(Object(pt.Sc)(mt.a.botsButtonClicked))
                        },
                        disableButtonAnimation: s
                    }), Object(S.d)(X, { in: n,
                        classNames: "botsListFade"
                    }, Object(S.d)(It, {
                        onBotClick: function() {
                            return !a && (c(Object(pt.Ab)()), r(!1), !0)
                        },
                        onBotFocus: function() {
                            r(!0)
                        },
                        onBotBlur: function() {
                            r(!1)
                        },
                        onCancelBotClick: function() {
                            c(Object(pt.Sc)(mt.a.botCanceled)), c(Object(pt.Bb)()), r(!1)
                        },
                        isBotActive: a
                    }))) : null
                };
            n(98);

            function Vt(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }
            var Ut = function(e) {
                    b()(n, e);
                    var t = Vt(n);

                    function n() {
                        var e;
                        c()(this, n);
                        for (var r = arguments.length, o = new Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                        return e = t.call.apply(t, [this].concat(o)), w()(f()(e), "state", {
                            hasError: !1
                        }), e
                    }
                    return l()(n, [{
                        key: "componentDidCatch",
                        value: function(e) {
                            Object(ct.b)("Error while loading EmojiPicker chunk - ".concat(e.message)), this.props.handleEmojiPanel()
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return this.state.hasError ? null : this.props.children
                        }
                    }], [{
                        key: "getDerivedStateFromError",
                        value: function() {
                            return {
                                hasError: !0
                            }
                        }
                    }]), n
                }(O.a.Component),
                qt = function() {
                    return Object(S.d)("div", {
                        className: "emoji-wrapper"
                    }, Object(S.d)("div", {
                        className: "emoji-mart"
                    }))
                },
                Gt = O.a.lazy((function() {
                    return n.e(0).then(n.bind(null, 404))
                })),
                Yt = function(e) {
                    return Object(S.d)(Ut, {
                        handleEmojiPanel: e.handleEmojiPanel
                    }, Object(S.d)(O.a.Suspense, {
                        fallback: Object(S.d)(qt, null)
                    }, Object(S.d)(Gt, {
                        onEmojiClick: e.onEmojiClick,
                        isMobile: e.isMobile
                    })))
                },
                Qt = function(e) {
                    return Object(S.d)(X, o()({}, e, { in: e.in,
                        classNames: "fade"
                    }), e.children)
                };
            var Kt = {
                    name: "135wcf7",
                    styles: "margin-right:40px;float:right;display:flex;text-decoration:none;color:#8894ab;font-weight:400;font-size:10px;/* @noflip */ direction:ltr;span{align-self:center;/* @noflip */ margin-right:8px;}svg{width:50px;}.mobile &{margin-right:70px;}"
                },
                Zt = function() {
                    var e = Object(j.d)((function(e) {
                            return e.publicKey
                        })),
                        t = Object(j.d)((function(e) {
                            return e.platform
                        })),
                        n = Object(j.d)((function(e) {
                            return e.isMobile
                        })),
                        r = Object(j.d)(vt.b),
                        o = Object(lt.n)(),
                        a = !Object(lt.F)(e);
                    return r ? Object(S.d)("div", null, Object(S.d)("span", {
                        css: Kt
                    }, Object(S.d)("span", null, "POWERED BY"), " ", Object(S.d)(ft.E, null))) : Object(S.d)("div", null, Object(S.d)("a", {
                        css: Kt,
                        href: "https://www.tidio.com/powered-by-tidio/?platform=".concat(t, "&project=").concat(e, "&device=").concat(n ? "mobile" : "desktop").concat(a ? "&utm_source=plugin_ref&utm_medium=widget_v4&utm_campaign=plugin_ref&utm_referrer=".concat(o) : ""),
                        target: "_blank",
                        rel: "noopener noreferrer",
                        "aria-label": Object(Ge.c)("poweredBy", null, "Powered by Tidio.")
                    }, Object(S.d)("span", null, "POWERED BY"), " ", Object(S.d)(ft.E, null)))
                };

            function Xt(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }
            var $t = function(e) {
                b()(n, e);
                var t = Xt(n);

                function n() {
                    var e;
                    c()(this, n);
                    for (var r = arguments.length, o = new Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                    return e = t.call.apply(t, [this].concat(o)), w()(f()(e), "bindInputRef", (function(t) {
                        e.inputRef = t
                    })), w()(f()(e), "onEmojiClick", (function(t) {
                        e.props.dispatch(Object(pt.Sc)(mt.a.emojiAdded)), e.props.dispatch(Object(pt.wb)(t.native))
                    })), w()(f()(e), "handleEmojiPanel", (function(t) {
                        t && (!(0 === t.nativeEvent.pageX && 0 === t.nativeEvent.pageY) && e.props.isEmojiPanelVisible && t.currentTarget.blur());
                        e.props.newMessageDisabled ? e.props.dispatch(Object(pt.Dc)(Object(Ge.c)("newMessageDisabledAlert", null, "Please enter your email first."))) : e.props.dispatch(Object(pt.Ic)(!e.props.isEmojiPanelVisible))
                    })), w()(f()(e), "handleUploadButton", (function(t) {
                        if (Object(lt.y)()) return !1;
                        t && (0 === t.nativeEvent.pageX && 0 === t.nativeEvent.pageY || t.currentTarget.blur());
                        return e.props.newMessageDisabled ? e.props.dispatch(Object(pt.Dc)(Object(Ge.c)("newMessageDisabledAlert", null, "Please enter your email first."))) : (e.props.dispatch(Object(pt.Sc)(mt.a.uploadButtonClicked)), e.inputRef.click()), !0
                    })), w()(f()(e), "sendFile", (function(t) {
                        var n = t.target.files[0];
                        e.props.dispatch(Object(pt.Oc)(n)), e.inputRef.value = ""
                    })), e
                }
                return l()(n, [{
                    key: "render",
                    value: function() {
                        return Object(S.d)("div", {
                            className: "input-group ".concat(this.props.newMessageDisabled && this.props.view !== ht.a.welcome ? "footer-disabled" : "", " ").concat(this.props.isDragAndDropActive ? "drag-active" : "")
                        }, Object(S.d)(K, { in: this.props.isEmojiPanelVisible,
                            classNames: "emojiFade",
                            timeout: 200,
                            mountOnEnter: !0,
                            unmountOnExit: !0,
                            appear: !0
                        }, Object(S.d)(Yt, {
                            isMobile: this.props.isMobile,
                            onEmojiClick: this.onEmojiClick,
                            handleEmojiPanel: this.handleEmojiPanel
                        })), Object(S.d)("div", {
                            className: "drag-active-wrapper"
                        }, this.props.hasSeparator && Object(S.d)("hr", null), Object(S.d)(zt, {
                            dispatch: this.props.dispatch
                        })), Object(S.d)("div", {
                            className: "footer-bottom"
                        }, Object(S.d)(Wt, null), Object(S.d)(Qt, { in: Boolean(this.props.messages.find((function(e) {
                                return "visitor" === e.sender
                            }))) && !this.props.isPreChatEnabledButNotFilled
                        }, Object(S.d)("button", {
                            type: "button",
                            className: "material-icons ripple ".concat(this.props.newMessageDisabled ? "disabled" : ""),
                            onClick: this.handleUploadButton,
                            style: {
                                color: "#007dfc"
                            },
                            "aria-label": Object(Ge.c)("attachFile", null, "Attach file button")
                        }, Object(S.d)(ft.d, null))), Object(S.d)("form", null, Object(S.d)("input", {
                            type: "file",
                            style: {
                                display: "none"
                            },
                            ref: this.bindInputRef,
                            name: "attachment",
                            onChange: this.sendFile,
                            "aria-label": Object(Ge.c)("attachFile", null, "Attach file input")
                        })), !this.props.isMobile && Object(S.d)("button", {
                            type: "button",
                            className: "material-icons emoji-switch ripple ".concat(this.props.isEmojiPanelVisible ? "active" : "", " ").concat(this.props.newMessageDisabled ? "disabled" : ""),
                            onClick: this.handleEmojiPanel,
                            style: {
                                color: "#007dfc"
                            },
                            "aria-label": this.props.isEmojiPanelVisible ? Object(Ge.c)("closeEmojiPanel", null, "Close Emoji picker") : Object(Ge.c)("openEmojiPanel", null, "Open Emoji picker")
                        }, Object(S.d)(ft.m, null)), this.props.showBranding && Object(S.d)(Zt, null)))
                    }
                }]), n
            }(O.a.Component);
            $t.defaultProps = {
                hasSeparator: !1
            };
            var Jt = Object(j.b)((function(e) {
                    return {
                        isEmojiPanelVisible: e.isEmojiPanelVisible,
                        isMobile: e.isMobile,
                        newMessageDisabled: e.newMessageDisabled,
                        showBranding: e.showBranding,
                        messages: e.messages,
                        view: e.view,
                        isDragAndDropActive: e.isDragAndDropActive,
                        isPreChatEnabledButNotFilled: Object(Dt.m)(e)
                    }
                }))($t),
                en = (n(330), n(78), n(207), n(356)),
                tn = n.n(en),
                nn = n(354),
                rn = n.n(nn),
                on = n(359),
                an = n.n(on),
                sn = function(e) {
                    var t = e.operator.avatarSrc ? {
                        backgroundImage: "url('".concat(e.operator.avatarSrc, "')")
                    } : null;
                    return Object(S.d)(O.a.Fragment, null, t && Object(S.d)("span", {
                        className: "timestamp-avatar",
                        style: t
                    }), Object(S.d)("span", null, "".concat(e.operator.name, " - ")))
                },
                cn = function(e) {
                    return Object(S.d)("div", {
                        className: "messageTimestamp"
                    }, e.operator && Object(S.d)(sn, {
                        operator: e.operator
                    }), "".concat(function(e) {
                        var t = new Date(1e3 * e);
                        return rn()(t) ? Object(Ge.c)("timeToday", null, "Today") : tn()(t) ? Object(Ge.c)("timeYesterday", null, "Yesterday") : an()(t, "d/M/yyyy")
                    }(e.time), ", ").concat(an()(new Date(1e3 * e.time), "H:mm")))
                };
            cn.defaultProps = {
                operator: null
            };
            var un = Object(j.b)((function(e, t) {
                return {
                    operator: t.operator_id ? Object(Dt.g)(e, t.operator_id) : null
                }
            }))(cn);

            function ln(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }
            var dn = function(e) {
                    b()(n, e);
                    var t = ln(n);

                    function n() {
                        var e;
                        c()(this, n);
                        for (var r = arguments.length, o = new Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                        return e = t.call.apply(t, [this].concat(o)), w()(f()(e), "state", {
                            isTimestampVisible: !1
                        }), w()(f()(e), "messageRef", O.a.createRef()), w()(f()(e), "wrapperRef", O.a.createRef()), w()(f()(e), "onMessageClick", (function() {
                            e.setState((function(e) {
                                return {
                                    isTimestampVisible: !e.isTimestampVisible
                                }
                            }))
                        })), e
                    }
                    return l()(n, [{
                        key: "componentDidMount",
                        value: function() {
                            this.props.adjustMessageWidth(this.messageRef.current, this.wrapperRef.current)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return Object(S.d)("div", {
                                className: "message message-operator ".concat(this.state.isTimestampVisible ? "timestamp-visible" : ""),
                                onClick: this.onMessageClick,
                                ref: this.wrapperRef
                            }, Object(S.d)("span", {
                                className: "message-content",
                                dangerouslySetInnerHTML: {
                                    __html: this.props.content
                                },
                                ref: this.messageRef
                            }), Object(S.d)(Qt, { in: this.state.isTimestampVisible
                            }, Object(S.d)(un, {
                                time: this.props.time_sent,
                                operator_id: this.props.operator_id
                            })))
                        }
                    }]), n
                }(O.a.Component),
                fn = function(e) {
                    var t = e.adjustMessageWidth,
                        n = Object(x.useState)(!1),
                        r = i()(n, 2),
                        o = r[0],
                        a = r[1],
                        s = Object(x.useRef)(null),
                        c = Object(x.useRef)(null);
                    Object(x.useEffect)((function() {
                        t(s.current, c.current)
                    }), [t]);
                    var u = Object(x.useCallback)((function() {
                        a((function(e) {
                            return !e
                        }))
                    }), []);
                    return Object(S.d)("div", {
                        className: "message message-visitor ".concat(o && e.isDelivered ? "timestamp-visible" : "", " ").concat(e.isDelivered ? "" : "not-delivered"),
                        onClick: u,
                        style: e.isDelivered ? {
                            background: "linear-gradient(135deg, ".concat(e.widgetColor[0], ", ").concat(e.widgetColor[1], ")"),
                            color: e.widgetColor[2]
                        } : {},
                        ref: c
                    }, Object(S.d)("span", {
                        className: "message-content",
                        dangerouslySetInnerHTML: {
                            __html: e.content
                        },
                        ref: s
                    }), Object(S.d)(Qt, { in: o && e.isDelivered
                    }, Object(S.d)(un, {
                        time: e.time_sent
                    })), !e.isDelivered && Object(S.d)("span", {
                        className: "resend-message",
                        style: {
                            color: "red"
                        }
                    }, Object(Ge.c)("messageNotDelivered", null, "Not delivered.")))
                },
                pn = n(22),
                bn = n.n(pn);

            function hn(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }

            function mn(e, t, n) {
                return n ? n(e) : "email" === t ? Object(lt.G)(e) : "tel" === t ? Object(lt.H)(e) : "" !== e.trim()
            }
            var gn = function(e) {
                b()(n, e);
                var t = hn(n);

                function n(e) {
                    var r;
                    c()(this, n), r = t.call(this, e), w()(f()(r), "onChange", (function(e) {
                        var t = e.target,
                            n = t.value,
                            o = t.checked,
                            a = "checkbox" !== t.type ? n : o,
                            i = mn(a, r.props.type, r.props.validator);
                        r.setState({
                            value: a,
                            isValid: i
                        }), r.props.onChange && r.props.onChange(a, i), r.props.isValidCallback && r.props.isValidCallback(i)
                    })), w()(f()(r), "onKeyDown", (function(e) {
                        var t = e.keyCode,
                            n = 13 === t;
                        return n && !r.state.isValid && (r.setState({
                            showErrorIcon: !0
                        }), r.props.onKeyDown && r.props.onKeyDown(!1), clearTimeout(r.errorIconHideTimer), r.errorIconHideTimer = null, r.errorIconHideTimer = setTimeout((function() {
                            r.setState({
                                showErrorIcon: !1
                            })
                        }), 820)), !(!n || !r.state.isValid) && (e.preventDefault(), r.props.onKeyDown && r.props.onKeyDown(t), !0)
                    })), w()(f()(r), "onFocus", (function() {
                        r.props.onFocus && r.props.onFocus(), r.props.shouldToggleHeader && !r.props.disabled && r.isMobile && r.props.dispatch(Object(pt.Kb)(!0))
                    })), w()(f()(r), "onBlur", (function() {
                        r.props.onBlur && r.props.onBlur(), r.props.shouldToggleHeader && !r.props.disabled && r.isMobile && setTimeout((function() {
                            r.props.dispatch(Object(pt.Kb)(!1))
                        }), 100)
                    })), w()(f()(r), "getError", (function() {
                        return void 0 === r.props.forceErrorIcon ? r.state.showErrorIcon : r.props.forceErrorIcon
                    }));
                    var o = null === e.value ? "" : e.value;
                    return r.state = {
                        value: o,
                        isValid: mn(o, e.type, e.validator),
                        showErrorIcon: !1
                    }, r.isMobile = Object(lt.D)(), r.errorIconHideTimer = null, r
                }
                return l()(n, [{
                    key: "componentDidMount",
                    value: function() {
                        var e = this.state.isValid;
                        this.state.isValid && (this.props.onChange && this.props.onChange(this.state.value, e), this.props.isValidCallback && this.props.isValidCallback(e))
                    }
                }, {
                    key: "render",
                    value: function() {
                        var e = this,
                            t = null,
                            n = null;
                        return "checkbox" !== this.props.type ? (t = Object(S.d)(ot, {
                            value: [this.props.placeholder]
                        }, (function(t) {
                            return Object(S.d)("input", {
                                type: e.props.type,
                                placeholder: t[e.props.placeholder],
                                onChange: e.onChange,
                                onKeyDown: e.onKeyDown,
                                value: e.state.value,
                                readOnly: e.props.disabled,
                                className: e.props.disabled ? "disabled" : "",
                                ref: e.props.bindInputRef,
                                onFocus: e.onFocus,
                                onBlur: e.onBlur
                            })
                        })), n = Object(S.d)(ft.b, null), this.state.isValid ? n = Object(S.d)(ft.y, null) : !this.state.isValid && this.getError() && (n = Object(S.d)(ft.h, null))) : t = Object(S.d)("label", {
                            htmlFor: this.props.id
                        }, Object(S.d)("input", {
                            id: this.props.id,
                            type: this.props.type,
                            onChange: this.onChange,
                            checked: this.state.value,
                            disabled: this.props.disabled,
                            className: this.props.disabled ? "disabled" : "",
                            ref: this.props.bindInputRef
                        }), Object(S.d)(ot, {
                            value: this.props.placeholder,
                            linkify: !0
                        })), Object(S.d)("div", {
                            className: "field-wrapper ".concat(this.props.shakeClassName, " ").concat(this.getError() ? "field-wrapper-with-error" : "")
                        }, n, t)
                    }
                }]), n
            }(O.a.Component);
            gn.defaultProps = {
                placeholder: "",
                bindInputRef: void 0,
                onChange: void 0,
                onKeyDown: null,
                disabled: !1,
                isValidCallback: null,
                value: null,
                forceErrorIcon: !1,
                id: void 0,
                validator: void 0,
                shouldToggleHeader: !0,
                onFocus: void 0,
                onBlur: void 0,
                shakeClassName: ""
            };
            var vn = Object(j.b)()(gn),
                yn = n(36),
                wn = O.a.forwardRef((function(e, t) {
                    var n = "",
                        r = {};
                    if ("email" === e.type) n = "email";
                    else if ("name" === e.type) n = "text";
                    else if ("phone" === e.type) n = "tel";
                    else if ("gdprConsent" === e.type) n = "checkbox", r.validator = function(e) {
                        return !0 === e
                    };
                    else if (e.type === yn.b) {
                        if (r.validator = function() {
                                return !0
                            }, r.placeholder = "signUpNewsletter", e.value && "object" === bn()(e.value)) {
                            var a = e.value;
                            r.value = "subscribed" === a.value
                        }
                        n = "checkbox"
                    } else {
                        if ("signUpNewsletter" !== e.type) return null;
                        r.validator = function() {
                            return !0
                        }, r.placeholder = "signUpNewsletter", n = "checkbox"
                    }
                    return Object(S.d)(vn, o()({
                        id: e.type,
                        type: n,
                        onChange: function(t, n) {
                            e.onInputChange(t, n, e.type)
                        },
                        value: e.value,
                        disabled: e.disabled,
                        placeholder: e.placeholder,
                        bindInputRef: t,
                        onKeyDown: e.onKeyDown,
                        forceErrorIcon: e.forceErrorIcon,
                        shakeClassName: e.shakeClassName
                    }, r))
                }));
            wn.defaultProps = {
                value: null,
                forceErrorIcon: !1,
                onKeyDown: void 0,
                onInputChange: function() {},
                shakeClassName: ""
            };
            var xn = wn,
                On = Object(j.b)((function(e) {
                    return {
                        visitor: e.visitor
                    }
                }))((function(e) {
                    return Object(S.d)("div", {
                        className: "message message-operator pre-chat"
                    }, Object(S.d)(ot, {
                        value: "preformMessage",
                        emojify: !0,
                        linkify: !0
                    }), e.preChatFields.map((function(t) {
                        return Object(S.d)(xn, {
                            key: t.type,
                            type: t.type,
                            placeholder: t.placeholder,
                            value: e.visitor[t.type],
                            disabled: !0
                        })
                    })))
                })),
                jn = Object(j.b)((function(e) {
                    return {
                        visitor: e.visitor
                    }
                }))((function(e) {
                    return Object(S.d)("div", {
                        className: "message message-operator always-online"
                    }, Object(S.d)(ot, {
                        value: "alwaysOnlineEngageMessage",
                        emojify: !0,
                        linkify: !0
                    }), Object(S.d)(vn, {
                        type: "email",
                        placeholder: "preformInput_email",
                        value: e.visitor.email,
                        disabled: !0
                    }))
                }));

            function kn(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }
            var Mn = function(e) {
                b()(n, e);
                var t = kn(n);

                function n() {
                    var e;
                    c()(this, n);
                    for (var r = arguments.length, o = new Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                    return e = t.call.apply(t, [this].concat(o)), w()(f()(e), "onRateUpClick", (function() {
                        e.props.dispatch(Object(pt.bc)(Object(Ge.c)("rateSatisfied", null, "Yes, I did!"), !1)), e.props.dispatch(Object(pt.Rc)(!0)), e.disableRateButtons()
                    })), w()(f()(e), "onRateDownClick", (function() {
                        e.props.dispatch(Object(pt.bc)(Object(Ge.c)("rateDissatisfied", null, "No. I\u2019m not satisfied."), !1)), e.props.dispatch(Object(pt.Rc)(!1)), e.disableRateButtons()
                    })), w()(f()(e), "disableRateButtons", (function() {
                        e.props.dispatch(Object(pt.mc)(e.props.id))
                    })), e
                }
                return l()(n, [{
                    key: "render",
                    value: function() {
                        return Object(S.d)("div", {
                            className: "message message-operator message-with-buttons ".concat(this.props.disabled ? "buttons-hidden" : "")
                        }, Object(S.d)("span", null, Object(S.d)(ot, {
                            value: "rateConversationMessage"
                        })), !this.props.disabled && Object(S.d)("div", {
                            className: "button-wrapper"
                        }, Object(S.d)("button", {
                            type: "button",
                            onClick: this.onRateUpClick
                        }, Object(S.d)("span", null, Object(S.d)(ot, {
                            value: "rateSatisfied"
                        }))), Object(S.d)("button", {
                            type: "button",
                            onClick: this.onRateDownClick
                        }, Object(S.d)("span", null, Object(S.d)(ot, {
                            value: "rateDissatisfied"
                        })))))
                    }
                }]), n
            }(O.a.Component);

            function An(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }
            var Cn = function(e) {
                    b()(n, e);
                    var t = An(n);

                    function n() {
                        var e;
                        c()(this, n);
                        for (var r = arguments.length, o = new Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                        return e = t.call.apply(t, [this].concat(o)), w()(f()(e), "state", {
                            isValid: !1
                        }), w()(f()(e), "comment", ""), w()(f()(e), "onChange", (function(t) {
                            e.comment = t
                        })), w()(f()(e), "onKeyDown", (function(t) {
                            return !(13 !== t || !e.state.isValid) && (e.props.dispatch(Object(pt.kc)(!0)), Object(St.b)(), !0)
                        })), w()(f()(e), "isMessageValid", (function(t) {
                            e.setState({
                                isValid: t
                            })
                        })), e
                    }
                    return l()(n, [{
                        key: "shouldComponentUpdate",
                        value: function() {
                            return !this.props.disabled
                        }
                    }, {
                        key: "componentDidUpdate",
                        value: function() {
                            !this.props.disabled && this.state.isValid && this.props.sendVisitorMessageFlag && this.props.dispatch(Object(pt.dc)(this.props.id, this.comment))
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return Object(S.d)("div", {
                                className: "message message-operator rate-comment"
                            }, Object(S.d)("span", {
                                dangerouslySetInnerHTML: {
                                    __html: $e(Object(Ge.c)(this.props.isRateGood ? "commentForGoodRating" : "commentForBadRating", null, this.props.isRateGood ? "Thank you for your rate \ud83d\ude0d Would you like to leave a comment?" : "Thank you for your rate \ud83d\ude25 Would you like to leave a comment?"))
                                }
                            }), Object(S.d)(vn, {
                                type: "text",
                                placeholder: "typeOptional",
                                onChange: this.onChange,
                                onKeyDown: this.onKeyDown,
                                isValidCallback: this.isMessageValid,
                                value: this.props.disabled ? this.props.content : null,
                                disabled: this.props.disabled
                            }))
                        }
                    }]), n
                }(O.a.Component),
                Sn = Object(j.b)((function(e) {
                    return {
                        sendVisitorMessageFlag: e.sendVisitorMessageFlag
                    }
                }))(Cn);
            n(54);

            function En(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }
            var Rn = function(e) {
                    b()(n, e);
                    var t = En(n);

                    function n() {
                        var e;
                        c()(this, n);
                        for (var r = arguments.length, o = new Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                        return e = t.call.apply(t, [this].concat(o)), w()(f()(e), "state", {
                            percentLoaded: 0
                        }), w()(f()(e), "removeMessageAndShowAlert", (function(t) {
                            e.props.dispatch(Object(pt.Wb)(e.props.id)), e.props.dispatch(Object(pt.Dc)(t))
                        })), w()(f()(e), "isFileValid", (function(t) {
                            try {
                                if (t.size / 1024 / 1024 > 10) return e.removeMessageAndShowAlert(Object(Ge.c)("fileToBigAlert", null, "File exceed 10MB limit.")), !1;
                                var n = t.name.split(".").pop().toLowerCase();
                                return -1 !== bt.a.indexOf(n) || (e.removeMessageAndShowAlert(Object(Ge.c)("extensionNotSupportedAlert", null, "File extension not supported.")), !1)
                            } catch (r) {
                                return Object(ct.a)(r), !1
                            }
                        })), w()(f()(e), "handleXhrError", (function(t) {
                            switch (t) {
                                case "ERR_INVALID_EXTENSION":
                                    return e.removeMessageAndShowAlert(Object(Ge.c)("extensionNotSupportedAlert", null, "File extension not supported.")), !1;
                                case "ERR_FILE_SIZE":
                                    return e.removeMessageAndShowAlert(Object(Ge.c)("fileToBigAlert", null, "File exceed 10MB limit.")), !1;
                                default:
                                    return e.removeMessageAndShowAlert(Object(Ge.c)("unknownErrorAlert", null, "Unknown error occurred.")), !1
                            }
                        })), w()(f()(e), "uploadFile", (function(t) {
                            if (!e.isFileValid(t)) return !1;
                            if (Object(lt.y)()) try {
                                var n = t.name.split(".").pop().toLowerCase(),
                                    r = Object(bt.c)(n),
                                    o = new FileReader;
                                o.onload = function(o) {
                                    e.props.dispatch(Object(pt.Kc)(e.props.id, r, o.target.result, t.name, n, o.target.result))
                                }, o.readAsDataURL(t)
                            } catch (c) {
                                Object(ct.a)(c)
                            } else try {
                                var a = "".concat("https://api-v2.tidio.co/", "upload/file/external?project_public_key=").concat(e.props.publicKey, "&visitor_id=").concat(e.props.visitorID),
                                    i = new XMLHttpRequest,
                                    s = new FormData;
                                i.open("POST", a, !0), i.onreadystatechange = function() {
                                    if (4 === i.readyState && 200 === i.status) {
                                        var n = JSON.parse(i.responseText);
                                        if (!1 === n.status) return e.handleXhrError(n.value), !1;
                                        e.props.dispatch(Object(pt.Kc)(e.props.id, n.value.type, n.value.url, t.name, n.value.meta.extension, n.value.thumb.medium))
                                    }
                                    return !0
                                }, s.append("upload", t), i.upload.addEventListener("progress", (function(t) {
                                    if (t.lengthComputable) {
                                        var n = Math.round(100 * t.loaded / t.total);
                                        e.setState({
                                            percentLoaded: n
                                        })
                                    }
                                }), !1), i.upload.addEventListener("load", (function() {
                                    e.setState({
                                        percentLoaded: 100
                                    })
                                }), !1), i.onerror = function() {
                                    Object(ct.a)("File upload error"), e.removeMessageAndShowAlert(Object(Ge.c)("genericFileUploadAlert", null, "Something went wrong when trying to upload your file."))
                                }, i.send(s)
                            } catch (c) {
                                Object(ct.a)(c)
                            }
                            return !0
                        })), e
                    }
                    return l()(n, [{
                        key: "componentDidMount",
                        value: function() {
                            this.uploadFile(this.props.file)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return Object(S.d)("div", {
                                className: "message message-upload message-".concat(this.props.sender),
                                role: "progressbar",
                                "aria-valuemin": "0",
                                "aria-valuemax": "100",
                                "aria-valuenow": this.state.percentLoaded,
                                style: {
                                    background: "linear-gradient(135deg, ".concat(this.props.widgetColor[0], ", ").concat(this.props.widgetColor[1], ")"),
                                    color: this.props.widgetColor[2]
                                }
                            }, Object(S.d)("span", null, Object(S.d)(O.a.Fragment, null, Object(S.d)(ft.p, null), "".concat(Object(Ge.c)("uploaded", null, "Uploaded"), " ").concat(this.state.percentLoaded, "%"))))
                        }
                    }]), n
                }(O.a.Component),
                Dn = Object(j.b)((function(e) {
                    return {
                        publicKey: e.publicKey,
                        visitorID: e.visitor.id
                    }
                }))(Rn);

            function Nn(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }
            var Tn = function(e) {
                    b()(n, e);
                    var t = Nn(n);

                    function n() {
                        return c()(this, n), t.apply(this, arguments)
                    }
                    return l()(n, [{
                        key: "render",
                        value: function() {
                            switch (this.props.extension) {
                                case "doc":
                                case "docx":
                                    return Object(S.d)(ft.k, null);
                                case "flv":
                                    return Object(S.d)(ft.n, null);
                                case "mpg":
                                case "mp4":
                                case "avi":
                                    return Object(S.d)(ft.r, null);
                                case "pdf":
                                    return Object(S.d)(ft.v, null);
                                case "txt":
                                case "rtf":
                                    return Object(S.d)(ft.F, null);
                                case "wma":
                                case "mp3":
                                    return Object(S.d)(ft.H, null);
                                case "xls":
                                case "xlsx":
                                case "csv":
                                    return Object(S.d)(ft.I, null);
                                default:
                                    return null
                            }
                        }
                    }]), n
                }(O.a.Component),
                Pn = (n(206), n(383)),
                Ln = n.n(Pn),
                _n = (n(335), n(384)),
                Fn = n.n(_n),
                zn = "https://assets.tidiochat.com/img/not_found.jpg";

            function In(e) {
                return Bn.apply(this, arguments)
            }

            function Bn() {
                return (Bn = Fn()(Ln.a.mark((function e(t) {
                    var n, r = arguments;
                    return Ln.a.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = r.length > 1 && void 0 !== r[1] ? r[1] : zn, e.abrupt("return", new Promise((function(e, n) {
                                    var r = new Image;
                                    r.src = t, r.onload = function() {
                                        return e(t)
                                    }, r.onerror = function(e) {
                                        n(e)
                                    }
                                })).catch((function() {
                                    return n
                                })));
                            case 2:
                            case "end":
                                return e.stop()
                        }
                    }), e)
                })))).apply(this, arguments)
            }
            var Hn = function(e) {
                var t = e.content,
                    n = e.extension,
                    r = e.thumb,
                    o = e.name,
                    a = e.id,
                    s = Object(j.c)(),
                    c = Object(j.d)((function(e) {
                        return e.publicKey
                    })),
                    u = Object(j.d)((function(e) {
                        return e.visitor.id
                    })),
                    l = Object(x.useState)(t),
                    d = i()(l, 2),
                    f = d[0],
                    p = d[1],
                    b = Object(x.useState)(r || ""),
                    h = i()(b, 2),
                    m = h[0],
                    g = h[1],
                    v = Object(x.useState)(!0),
                    y = i()(v, 2),
                    w = y[0],
                    O = y[1],
                    k = "gif" !== n ? m : f,
                    M = function() {
                        g(zn), p(zn)
                    },
                    A = Object(x.useCallback)(function() {
                        var e = Fn()(Ln.a.mark((function e(t) {
                            var n, r, o, a, i, s = arguments;
                            return Ln.a.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        if (n = s.length > 1 && void 0 !== s[1] && s[1], t !== zn) {
                                            e.next = 4;
                                            break
                                        }
                                        return O(!1), e.abrupt("return", "");
                                    case 4:
                                        if (-1 !== t.indexOf("/conversation/")) {
                                            e.next = 14;
                                            break
                                        }
                                        return r = Object(lt.K)(t), o = "/".concat(c, "/conversation/").concat(u), a = r ? "".concat(r.protocol, "//").concat(r.host).concat(o).concat(r.pathname).concat(r.search).concat(r.hash) : t, e.next = 10, In(a);
                                    case 10:
                                        i = e.sent, n ? g(i) : p(i), e.next = 15;
                                        break;
                                    case 14:
                                        M();
                                    case 15:
                                        return e.abrupt("return", "");
                                    case 16:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })));
                        return function(t) {
                            return e.apply(this, arguments)
                        }
                    }(), [c, u]);
                return w ? Object(S.d)("span", null, Object(S.d)("a", {
                    href: t,
                    target: "_blank",
                    rel: "noopener noreferrer",
                    onClick: function(t) {
                        t.preventDefault(), s(Object(pt.Pb)(f)), e.onClick()
                    }
                }, Object(S.d)(ft.l, null), Object(S.d)("img", {
                    className: "attachment-img",
                    src: k,
                    onLoad: function(e) {
                        e.currentTarget.setAttribute("alt", "".concat(o)), s(Object(pt.Lc)(a, !0))
                    },
                    onError: function() {
                        A(f), A(m, !0)
                    },
                    alt: ""
                }))) : null
            };
            var Wn = Object(S.c)({
                    position: "absolute",
                    bottom: Object(lt.D)() ? -37 : -31,
                    left: 16,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "flex-start",
                    width: 260
                }, ""),
                Vn = Object(S.c)({
                    fontSize: 12,
                    marginTop: Object(lt.D)() ? 6 : 11,
                    marginRight: 8
                }, ""),
                Un = {
                    name: "sycpdz",
                    styles: "position:relative;display:flex;align-items:center;justify-content:space-between;width:100px;height:48px;"
                },
                qn = {
                    name: "11tx334",
                    styles: "position:relative;display:flex;align-items:center;justify-content:space-between;padding:0px 7px;width:77px;height:40px;background-color:#F0F2F7;border:3px solid white;border-radius:20px;box-shadow:0px 3px 8px rgba(0, 18, 46, 0.12);::before{content:'';position:absolute;left:35px;width:1px;height:20px;background-color:#C9D1DD;}"
                },
                Gn = function(e, t) {
                    return Object(lt.D)() ? Object(S.c)({
                        outline: "none",
                        width: 48,
                        height: 48,
                        borderRadius: "50%",
                        backgroundColor: "#F0F2F7",
                        boxShadow: "0px 3px 8px 0px rgba(0, 27, 71, 0.08)",
                        border: "3px solid white",
                        svg: {
                            fill: e ? "#ACB8CB" : "#007DFC",
                            height: 22,
                            width: 22
                        }
                    }, "") : Object(S.c)({
                        position: "relative",
                        cursor: t ? "initial" : "pointer",
                        outline: "none",
                        "::before": {
                            content: "''",
                            position: "absolute",
                            backgroundColor: "rgba(0,125,252,0.12)",
                            width: 34,
                            height: 34,
                            borderRadius: "50%",
                            transition: "all 0.16s ease-in-out",
                            transform: "scale(0)",
                            top: "calc(50% - 17px)",
                            left: "calc(50% - 17px)"
                        },
                        "&:hover::before": {
                            transform: t ? "scale(0)" : "scale(1)"
                        },
                        svg: {
                            fill: e ? "#ACB8CB" : "#007DFC",
                            height: 20,
                            width: 20
                        }
                    }, "")
                },
                Yn = function(e) {
                    var t = Object(j.c)(),
                        n = function(n) {
                            !e.rating && e.ratingId && t(Object(pt.Vb)(e.messageId, e.ratingId, n))
                        };
                    return Object(S.d)("div", {
                        css: Wn
                    }, Object(S.d)("span", {
                        css: Vn
                    }, Object(S.d)(ot, {
                        value: "ratingLabel",
                        fallback: "Was this helpful?"
                    })), Object(S.d)("div", {
                        css: Object(lt.D)() ? Un : qn
                    }, Object(S.d)("button", {
                        type: "button",
                        "aria-label": "yes",
                        onClick: function() {
                            return n("yes")
                        },
                        css: Gn("no" === e.rating, Boolean(e.rating))
                    }, "yes" === e.rating ? Object(S.d)(ft.C, null) : Object(S.d)(ft.D, null)), Object(S.d)("button", {
                        type: "button",
                        "aria-label": "no",
                        onClick: function() {
                            return n("no")
                        },
                        css: Gn("yes" === e.rating, Boolean(e.rating))
                    }, "no" === e.rating ? Object(S.d)(ft.A, null) : Object(S.d)(ft.B, null))))
                },
                Qn = function(e) {
                    var t = Object(x.useState)(!1),
                        n = i()(t, 2),
                        r = n[0],
                        o = n[1],
                        a = Boolean(e.ratingId) && !r,
                        s = function() {
                            o((function(e) {
                                return !e
                            }))
                        };
                    return Object(S.d)(O.a.Fragment, null, Object(S.d)("div", {
                        className: "message message-upload ".concat("image" === e.attachmentType ? "message-image" : "message-file", " message-").concat("bot" === e.sender ? "operator" : e.sender, " ").concat(r ? "timestamp-visible" : "", " ").concat(e.ratingId ? "rating-visible" : ""),
                        style: "visitor" === e.sender ? {
                            background: "linear-gradient(135deg, ".concat(e.widgetColor[0], ", ").concat(e.widgetColor[1], ")"),
                            color: e.widgetColor[2]
                        } : {}
                    }, "image" === e.attachmentType ? Object(S.d)(O.a.Fragment, null, Object(S.d)(Hn, {
                        content: e.content,
                        extension: e.extension,
                        thumb: e.thumb,
                        name: e.name,
                        id: e.id,
                        onClick: s
                    }), Object(S.d)(Qt, { in: r
                    }, Object(S.d)(un, {
                        time: e.time_sent
                    })), Object(S.d)(Qt, { in: a
                    }, Object(S.d)(Yn, {
                        messageId: e.id,
                        ratingId: e.ratingId,
                        rating: e.rating
                    }))) : Object(S.d)(O.a.Fragment, null, Object(S.d)("a", {
                        href: e.content,
                        target: "_blank",
                        rel: "noopener noreferrer",
                        onClick: s
                    }, Object(S.d)(ft.l, null), Object(S.d)("span", null, Object(S.d)(Tn, {
                        extension: e.extension
                    }), "".concat(e.name))), Object(S.d)(Qt, { in: r
                    }, Object(S.d)(un, {
                        time: e.time_sent
                    })))))
                },
                Kn = function(e) {
                    return Object(S.d)("div", {
                        className: "message message-operator"
                    }, Object(S.d)("span", {
                        className: "message-content",
                        dangerouslySetInnerHTML: {
                            __html: e.content
                        }
                    }))
                },
                Zn = function(e) {
                    var t = Object(x.useState)(!1),
                        n = i()(t, 2),
                        r = n[0],
                        o = n[1],
                        a = Boolean(e.ratingId) && !r;
                    return Object(S.d)("div", {
                        className: "message message-operator ".concat(r ? "timestamp-visible" : "", " ").concat(e.ratingId ? "rating-visible" : "")
                    }, Object(S.d)("span", {
                        className: "message-content",
                        dangerouslySetInnerHTML: {
                            __html: e.content
                        },
                        onClick: function() {
                            o((function(e) {
                                return !e
                            }))
                        }
                    }), Object(S.d)(Qt, { in: r
                    }, Object(S.d)(un, {
                        time: e.time_sent
                    })), Object(S.d)(Qt, { in: a
                    }, Object(S.d)(Yn, {
                        messageId: e.id,
                        ratingId: e.ratingId,
                        rating: e.rating
                    })))
                },
                Xn = function(e) {
                    return Object(S.d)("div", {
                        className: "button-wrapper"
                    }, e.quickReplies.map((function(t) {
                        return Object(S.d)("button", {
                            type: "button",
                            key: "".concat(t.title).concat(t.payload),
                            title: t.title,
                            onClick: function() {
                                e.onButtonClick(t.payload, t.title, t.type)
                            }
                        }, Object(S.d)("span", {
                            dangerouslySetInnerHTML: {
                                __html: Je(t.title)
                            }
                        }))
                    })))
                };

            function $n(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }
            var Jn = function(e) {
                b()(n, e);
                var t = $n(n);

                function n() {
                    var e;
                    c()(this, n);
                    for (var r = arguments.length, o = new Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                    return e = t.call.apply(t, [this].concat(o)), w()(f()(e), "onButtonClick", (function(t, n, r) {
                        return e.props.dispatch(Object(pt.cc)(n, t)), e.props.dispatch(Object(pt.Sc)("bot" !== r ? mt.a.quickReplyClicked : mt.a.botStartedFromBotsMenu)), !0
                    })), e
                }
                return l()(n, [{
                    key: "componentDidMount",
                    value: function() {
                        this.props.isLastMessage || this.props.disabled || this.props.dispatch(Object(pt.mc)(this.props.messageId))
                    }
                }, {
                    key: "shouldComponentUpdate",
                    value: function() {
                        return !this.props.disabled
                    }
                }, {
                    key: "componentDidUpdate",
                    value: function(e) {
                        this.props.isLastMessage !== e.isLastMessage && this.props.dispatch(Object(pt.mc)(this.props.messageId))
                    }
                }, {
                    key: "render",
                    value: function() {
                        return this.props.disabled || !this.props.isLastMessage ? null : Object(S.d)(Xn, {
                            quickReplies: this.props.quickReplies,
                            onButtonClick: this.onButtonClick
                        })
                    }
                }]), n
            }(O.a.Component);
            Jn.defaultProps = {
                disabled: !1
            };
            var er = Object(j.b)((function(e, t) {
                    return {
                        isLastMessage: Object(Dt.k)(e, t.messageId)
                    }
                }))(Jn),
                tr = n(115),
                nr = n.n(tr),
                rr = (n(385), function(e) {
                    return e.link ? Object(S.d)("a", {
                        href: e.link,
                        onClick: e.openLink,
                        "data-testid": "cardImageLink"
                    }, Object(S.d)("div", {
                        className: "card-image",
                        style: {
                            backgroundImage: "url(".concat(e.imageUrl, ")")
                        }
                    })) : Object(S.d)("div", {
                        className: "card-image",
                        style: {
                            backgroundImage: "url(".concat(e.imageUrl, ")")
                        }
                    })
                });
            rr.defaultProps = {
                link: void 0,
                openLink: function() {}
            };
            var or = rr,
                ar = function(e) {
                    var t = e.title,
                        n = e.payload,
                        r = e.onClick,
                        o = e.cardClicked,
                        a = Je(t),
                        i = e.url || n,
                        s = Object(lt.q)(i);
                    return Object(S.d)("div", {
                        className: "button-url"
                    }, Object(S.d)("a", {
                        className: "button-url__anchor",
                        href: Object(lt.q)(i),
                        type: "button",
                        onClick: function(a) {
                            a.preventDefault();
                            var i = e.title;
                            o && (i = "".concat(o, " &rarr; ").concat(t)), r(n, i), Object(lt.J)(s)
                        },
                        "data-testid": "buttonUrl",
                        dangerouslySetInnerHTML: {
                            __html: a
                        }
                    }))
                },
                ir = function(e) {
                    return Object(S.d)("button", {
                        type: "button",
                        title: e.title,
                        onClick: function() {
                            var t = e.title;
                            e.cardClicked && (t = "".concat(e.cardClicked, " &rarr; ").concat(e.title)), e.onClick(e.payload, t)
                        }
                    }, Object(S.d)("span", {
                        dangerouslySetInnerHTML: {
                            __html: Je(e.title)
                        }
                    }))
                },
                sr = function(e) {
                    return Object(S.d)("div", {
                        className: "button-wrapper"
                    }, e.buttons.map((function(t) {
                        return Object(S.d)("div", {
                            key: "".concat(t.title).concat(t.payload)
                        }, "url" === t.type && Object(S.d)(ar, {
                            title: t.title,
                            payload: t.payload,
                            url: t.url,
                            cardClicked: t.cardClicked,
                            onClick: e.onButtonClick
                        }), "action" === t.type && Object(S.d)(ir, {
                            title: t.title,
                            payload: t.payload,
                            cardClicked: t.cardClicked,
                            onClick: e.onButtonClick
                        }))
                    })))
                };
            var cr = Object(j.b)()((function(e) {
                var t = e.dispatch,
                    n = e.buttons;
                return Object(S.d)(sr, {
                    buttons: n,
                    onButtonClick: function(e, n) {
                        return t(Object(pt.cc)(n, e)), t(Object(pt.Sc)(mt.a.buttonClicked)), !0
                    }
                })
            }));

            function ur(e) {
                var t = e.buttons,
                    n = Object(j.c)(),
                    r = t[0],
                    o = Object(lt.q)(r.url || r.payload);
                return Object(S.d)("div", {
                    className: "button-wrapper"
                }, Object(S.d)("a", {
                    href: o,
                    className: "button-icon",
                    onClick: function(e) {
                        e.preventDefault(), n(Object(pt.Sc)(mt.a.buttonClicked)), Object(lt.J)(o)
                    }
                }, Object(S.d)(ft.l, null)))
            }

            function lr(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function dr(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? lr(Object(n), !0).forEach((function(t) {
                        w()(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : lr(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function fr(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }
            var pr = function(e) {
                b()(n, e);
                var t = fr(n);

                function n() {
                    var e;
                    c()(this, n);
                    for (var r = arguments.length, o = new Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                    return e = t.call.apply(t, [this].concat(o)), w()(f()(e), "extendedButtons", e.props.buttons.map((function(t) {
                        return dr(dr({}, t), {}, {
                            cardClicked: e.props.title
                        })
                    }))), w()(f()(e), "parsedUrl", Object(lt.K)(e.props.url)), w()(f()(e), "parsedTitle", $e(e.props.title)), w()(f()(e), "parsedSubtitle", $e(e.props.subtitle)), w()(f()(e), "isSameHost", Object(lt.E)(Object(lt.p)(), e.props.url)), w()(f()(e), "openLink", (function(t) {
                        t.preventDefault();
                        var n = e.props.proxyUrl || e.getFullParsedUrl();
                        try {
                            e.isSameHost ? window.top.location = n : window.open(n)
                        } catch (r) {
                            window.open(n)
                        }
                    })), w()(f()(e), "getFullParsedUrl", (function() {
                        return e.parsedUrl ? "".concat(e.parsedUrl.protocol, "//").concat(e.parsedUrl.host).concat(e.parsedUrl.pathname).concat(e.parsedUrl.search).concat(e.parsedUrl.hash) : null
                    })), w()(f()(e), "getUrlWithoutProtocol", (function() {
                        return e.parsedUrl ? e.parsedUrl.host + e.parsedUrl.pathname + e.parsedUrl.search + e.parsedUrl.hash : null
                    })), e
                }
                return l()(n, [{
                    key: "render",
                    value: function() {
                        return Object(S.d)("div", {
                            className: "card message-with-buttons"
                        }, this.props.imageUrl && Object(S.d)(or, {
                            imageUrl: this.props.imageUrl,
                            link: this.getFullParsedUrl(),
                            openLink: this.openLink
                        }), Object(S.d)("div", {
                            className: "card-content-wrapper"
                        }, Object(S.d)("div", {
                            className: "card-title",
                            dangerouslySetInnerHTML: {
                                __html: this.parsedTitle
                            }
                        }), this.props.subtitle && Object(S.d)("div", {
                            className: "card-subtitle",
                            dangerouslySetInnerHTML: {
                                __html: this.parsedSubtitle
                            }
                        }), this.props.url && Object(S.d)("div", {
                            className: "card-url"
                        }, Object(S.d)("a", {
                            href: this.getFullParsedUrl(),
                            type: "button",
                            onClick: this.openLink,
                            "data-testid": "cardLink"
                        }, this.isSameHost ? this.getUrlWithoutProtocol() : this.parsedUrl.host))), Object(S.d)("div", {
                            className: "card-buttons"
                        }, this.props.isShopifyCard ? Object(S.d)(ur, {
                            buttons: this.extendedButtons
                        }) : Object(S.d)(cr, {
                            buttons: this.extendedButtons
                        })))
                    }
                }]), n
            }(O.a.Component);
            pr.defaultProps = {
                imageUrl: void 0,
                subtitle: void 0,
                url: void 0,
                proxyUrl: void 0
            };
            var br = pr;

            function hr(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }
            var mr = function(e) {
                b()(n, e);
                var t = hr(n);

                function n() {
                    var e;
                    c()(this, n);
                    for (var r = arguments.length, o = new Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                    return e = t.call.apply(t, [this].concat(o)), w()(f()(e), "state", {
                        galleryScrollLeft: 0,
                        galleryScrollWidth: 0,
                        scrollInRtlType: "reverse"
                    }), w()(f()(e), "cardGalleryRef", O.a.createRef()), w()(f()(e), "isLanguageRTL", Object(Ge.a)()), w()(f()(e), "hasImages", "string" === typeof e.props.cards[0].imageUrl), w()(f()(e), "isProductGallery", "number" === typeof e.props.operator_id), w()(f()(e), "scrollHandler", nr()((function() {
                        e.cardGalleryRef.current && e.setState({
                            galleryScrollLeft: e.cardGalleryRef.current.scrollLeft
                        })
                    }), 80)), e
                }
                return l()(n, [{
                    key: "componentDidMount",
                    value: function() {
                        var e = this;
                        return !!this.cardGalleryRef.current && (this.cardGalleryRef.current.scrollLeft > 0 ? this.setState({
                            scrollInRtlType: "default"
                        }) : (this.cardGalleryRef.current.scrollLeft = 1, 0 === this.cardGalleryRef.current.scrollLeft && this.setState({
                            scrollInRtlType: "negative"
                        })), this.setState((function(t) {
                            return {
                                galleryScrollWidth: e.cardGalleryRef.current.scrollWidth,
                                galleryWidth: e.cardGalleryRef.current.offsetWidth,
                                galleryScrollLeft: e.isLanguageRTL && "default" === t.scrollInRtlType ? e.cardGalleryRef.current.scrollWidth - e.cardGalleryRef.current.offsetWidth : 0
                            }
                        })), this.cardGalleryRef.current.addEventListener("scroll", this.scrollHandler), !0)
                    }
                }, {
                    key: "componentWillUnmount",
                    value: function() {
                        return !!this.cardGalleryRef.current && (this.cardGalleryRef.current.removeEventListener("scroll", this.scrollHandler), !0)
                    }
                }, {
                    key: "trackGalleryScrollClick",
                    value: function() {
                        this.props.dispatch(Object(pt.Sc)(mt.a.cardsScrolled))
                    }
                }, {
                    key: "render",
                    value: function() {
                        var e = this;
                        return Object(S.d)(O.a.Fragment, null, Object(S.d)("div", {
                            className: "bots-card-gallery-button-wrapper ".concat(this.hasImages ? "" : "bots-card-gallery-without-images")
                        }, this.isLanguageRTL ? Object(S.d)(O.a.Fragment, null, "default" === this.state.scrollInRtlType && Object(S.d)(O.a.Fragment, null, Object(S.d)(X, {
                            classNames: "fade200",
                            in: this.state.galleryScrollWidth - this.state.galleryWidth > this.state.galleryScrollLeft
                        }, Object(S.d)("button", {
                            type: "button",
                            className: "bots-card-gallery-scroll-button scroll-button-left",
                            onClick: function() {
                                e.cardGalleryRef.current.scrollLeft += 240, e.trackGalleryScrollClick()
                            }
                        }, Object(S.d)(ft.g, null))), Object(S.d)(X, {
                            classNames: "fade200",
                            in: this.state.galleryScrollLeft > 10
                        }, Object(S.d)("button", {
                            type: "button",
                            className: "bots-card-gallery-scroll-button scroll-button-right",
                            onClick: function() {
                                e.cardGalleryRef.current.scrollLeft -= 240, e.trackGalleryScrollClick()
                            }
                        }, Object(S.d)(ft.g, null)))), "negative" === this.state.scrollInRtlType && Object(S.d)(O.a.Fragment, null, Object(S.d)(X, {
                            classNames: "fade200",
                            in: this.state.galleryScrollLeft < -10
                        }, Object(S.d)("button", {
                            type: "button",
                            className: "bots-card-gallery-scroll-button scroll-button-left",
                            onClick: function() {
                                e.cardGalleryRef.current.scrollLeft += 240, e.trackGalleryScrollClick()
                            }
                        }, Object(S.d)(ft.g, null))), Object(S.d)(X, {
                            classNames: "fade200",
                            in: this.state.galleryScrollWidth - this.state.galleryWidth > -1 * this.state.galleryScrollLeft
                        }, Object(S.d)("button", {
                            type: "button",
                            className: "bots-card-gallery-scroll-button scroll-button-right",
                            onClick: function() {
                                e.cardGalleryRef.current.scrollLeft -= 240, e.trackGalleryScrollClick()
                            }
                        }, Object(S.d)(ft.g, null)))), "reverse" === this.state.scrollInRtlType && Object(S.d)(O.a.Fragment, null, Object(S.d)(X, {
                            classNames: "fade200",
                            in: this.state.galleryScrollLeft > 10
                        }, Object(S.d)("button", {
                            type: "button",
                            className: "bots-card-gallery-scroll-button scroll-button-left",
                            onClick: function() {
                                e.cardGalleryRef.current.scrollLeft -= 240, e.trackGalleryScrollClick()
                            }
                        }, Object(S.d)(ft.g, null))), Object(S.d)(X, {
                            classNames: "fade200",
                            in: this.state.galleryScrollWidth - this.state.galleryWidth > this.state.galleryScrollLeft
                        }, Object(S.d)("button", {
                            type: "button",
                            className: "bots-card-gallery-scroll-button scroll-button-right",
                            onClick: function() {
                                e.cardGalleryRef.current.scrollLeft += 240, e.trackGalleryScrollClick()
                            }
                        }, Object(S.d)(ft.g, null))))) : Object(S.d)(O.a.Fragment, null, Object(S.d)(X, {
                            classNames: "fade200",
                            in: this.state.galleryScrollLeft > 10
                        }, Object(S.d)("button", {
                            type: "button",
                            className: "bots-card-gallery-scroll-button scroll-button-left",
                            onClick: function() {
                                e.cardGalleryRef.current.scrollLeft -= 240, e.trackGalleryScrollClick()
                            }
                        }, Object(S.d)(ft.g, null))), Object(S.d)(X, {
                            classNames: "fade200",
                            in: this.state.galleryScrollWidth - this.state.galleryWidth > this.state.galleryScrollLeft
                        }, Object(S.d)("button", {
                            type: "button",
                            className: "bots-card-gallery-scroll-button scroll-button-right",
                            onClick: function() {
                                e.cardGalleryRef.current.scrollLeft += 240, e.trackGalleryScrollClick()
                            }
                        }, Object(S.d)(ft.g, null))))), Object(S.d)("div", {
                            className: "message message-operator bots-card-gallery ".concat(this.hasImages ? "" : "bots-card-gallery-without-images", " ").concat(1 === this.props.cards.length ? "bots-card-gallery-single-card" : "bots-card-gallery-multiple-cards"),
                            ref: this.cardGalleryRef
                        }, this.props.cards.map((function(t) {
                            return Object(S.d)(br, o()({}, t, {
                                key: t.id,
                                isShopifyCard: e.isProductGallery
                            }))
                        }))))
                    }
                }]), n
            }(O.a.Component);
            mr.defaultProps = {
                operator_id: void 0
            };
            var gr = mr,
                vr = function(e) {
                    return Object(S.d)("div", {
                        className: "message message-operator buttons-message"
                    }, Object(S.d)("div", {
                        className: "message-with-buttons"
                    }, Object(S.d)("div", {
                        className: "message-with-buttons-text",
                        dangerouslySetInnerHTML: {
                            __html: e.content
                        },
                        "data-testid": "buttonsText"
                    }), Object(S.d)(cr, {
                        buttons: e.buttons
                    })))
                };
            var yr = {
                name: "el2nz9",
                styles: "display:flex;flex-direction:column;align-items:center;color:#647491;margin:auto;text-align:center;padding-top:24px;p{margin:6px 0;}"
            };

            function wr(e) {
                var t = e.operator_id,
                    n = Object(j.d)((function(e) {
                        return e.operators
                    })).find((function(e) {
                        return e.id === t
                    }));
                return Object(S.d)("div", {
                    className: "message",
                    css: yr
                }, Object(S.d)(ft.z, null), Object(S.d)("p", null, n ? Object(S.d)(ot, {
                    value: "operatorMarkedConversationAsSolved",
                    replacements: {
                        "{operatorName}": n.name
                    },
                    fallback: "{operatorName} marked the conversation as solved"
                }) : Object(S.d)(ot, {
                    value: "conversationWasMarkedAsSolved",
                    fallback: "The conversation was marked as solved"
                })))
            }

            function xr(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }
            var Or = function(e) {
                b()(n, e);
                var t = xr(n);

                function n() {
                    var e;
                    c()(this, n);
                    for (var r = arguments.length, o = new Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                    return e = t.call.apply(t, [this].concat(o)), w()(f()(e), "windowRef", Object(St.e)()), w()(f()(e), "adjustMessageWidth", (function(t, n) {
                        var r = n;
                        t && e.windowRef && e.windowRef.requestAnimationFrame((function() {
                            r.style.width = "".concat(t.offsetWidth + 35, "px")
                        }))
                    })), e
                }
                return l()(n, [{
                    key: "render",
                    value: function() {
                        var e = $e(this.props.content);
                        if ("text" !== this.props.type) switch (this.props.type) {
                            case "preChat":
                                return Object(S.d)(On, o()({}, this.props, {
                                    content: e
                                }));
                            case "rateConversation":
                                return Object(S.d)(Mn, this.props);
                            case "rateConversationCommentRateWasGood":
                                return Object(S.d)(Sn, o()({
                                    isRateGood: !0
                                }, this.props));
                            case "rateConversationCommentRateWasBad":
                                return Object(S.d)(Sn, o()({
                                    isRateGood: !1
                                }, this.props));
                            case "alwaysOnline":
                                return Object(S.d)(jn, this.props);
                            case "uploadingFile":
                                return Object(S.d)(Dn, o()({}, this.props, {
                                    widgetColor: Object(lt.d)(this.props.widgetColor)
                                }));
                            case "uploadedFile":
                                return Object(S.d)(O.a.Fragment, null, Object(S.d)(Qn, o()({}, this.props, {
                                    widgetColor: Object(lt.d)(this.props.widgetColor)
                                })), this.props.quickReplies && this.props.quickReplies.length > 0 && !this.props.disabled && Object(S.d)("div", {
                                    className: "message message-operator bots-quick-replies"
                                }, Object(S.d)(er, {
                                    quickReplies: this.props.quickReplies,
                                    messageId: this.props.id,
                                    disabled: this.props.disabled
                                })));
                            case "system":
                                return Object(S.d)(Kn, o()({}, this.props, {
                                    content: e
                                }));
                            case "cardGallery":
                                return Object(S.d)(gr, o()({}, this.props, {
                                    dispatch: this.props.dispatch
                                }));
                            case "buttons":
                                return Object(S.d)(vr, o()({}, this.props, {
                                    content: e
                                }));
                            case Nt.c.CONVERSATION_MARKED_AS_SOLVED:
                                return Object(S.d)(wr, this.props);
                            default:
                                return !1
                        } else {
                            if (this.props.sender === bt.g.operator) return Object(S.d)(dn, o()({}, this.props, {
                                content: e,
                                adjustMessageWidth: this.adjustMessageWidth
                            }));
                            if (this.props.sender === bt.g.bot) return Object(S.d)(O.a.Fragment, null, Object(S.d)(Zn, o()({}, this.props, {
                                content: e
                            })), this.props.quickReplies && this.props.quickReplies.length > 0 && !this.props.disabled && Object(S.d)("div", {
                                className: "message message-operator bots-quick-replies"
                            }, Object(S.d)(er, {
                                quickReplies: this.props.quickReplies,
                                messageId: this.props.id,
                                disabled: this.props.disabled
                            })));
                            if (this.props.sender === bt.g.visitor) return Object(S.d)(fn, o()({}, this.props, {
                                content: e,
                                widgetColor: Object(lt.d)(this.props.widgetColor),
                                adjustMessageWidth: this.adjustMessageWidth
                            }))
                        }
                        return null
                    }
                }]), n
            }(O.a.Component);
            Or.defaultProps = {
                quickReplies: [],
                disabled: void 0
            };
            var jr = Object(j.b)((function(e) {
                return {
                    widgetColor: e.widgetColor
                }
            }))(Or);
            n(155);

            function kr(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }
            var Mr = function(e) {
                    b()(n, e);
                    var t = kr(n);

                    function n() {
                        var e;
                        c()(this, n);
                        for (var r = arguments.length, o = new Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                        return e = t.call.apply(t, [this].concat(o)), w()(f()(e), "state", {
                            scrollStartPosition: 0
                        }), w()(f()(e), "messageWasAdded", !1), w()(f()(e), "conversationPadding", 0), w()(f()(e), "calculateScrollDivHeight", (function() {
                            var t = e.props.conversationRef,
                                n = t.scrollHeight,
                                r = t.clientHeight,
                                o = r - e.conversationPadding;
                            e.scrollDiv.style.height = n === r ? "0px" : "".concat(o * o / +n, "px")
                        })), w()(f()(e), "bindScroll", (function(t) {
                            if (!t) return !1;
                            e.scrollDiv = t;
                            var n = e.props.conversationRef,
                                r = n.scrollHeight,
                                o = n.clientHeight;
                            return e.scrollDiv.style.top = "".concat((o + e.conversationPadding) * e.props.conversationRef.scrollTop / r, "px"), !0
                        })), w()(f()(e), "moveScrollFromMessages", (function() {
                            e.props.conversationRef.onscroll = function() {
                                var t = 0;
                                if (e.messageWasAdded) {
                                    var n = Array.from(e.props.iframeDocument.querySelectorAll(".message")).slice(-1)[0];
                                    t = n ? n.offsetHeight : 0, e.messageWasAdded = !1
                                }
                                e.scrollDiv.style.top = "".concat((e.props.conversationRef.clientHeight - e.conversationPadding) * e.props.conversationRef.scrollTop / (e.props.conversationRef.scrollHeight - t), "px")
                            }
                        })), w()(f()(e), "moveMessagesFromScroll", (function(t) {
                            var n = e.props.conversationRef,
                                r = n.scrollHeight,
                                o = n.clientHeight;
                            e.props.conversationRef.scrollTop = r * t / (o - e.conversationPadding)
                        })), w()(f()(e), "handleScrollMove", (function(t) {
                            e.props.conversationRef.onscroll = null, e.setState({
                                scrollStartPosition: t.clientY
                            }), e.scrollDiv.style.width = "8px", e.scrollDiv.style.margin = "0px", e.scrollDiv.style.opacity = .32, e.props.iframeDocument.onmousemove = e.scrollMove, e.props.iframeDocument.onmouseup = e.scrollStop
                        })), w()(f()(e), "scrollMove", (function(t) {
                            window.requestAnimationFrame((function() {
                                var n = e.props.conversationRef.clientHeight;
                                n -= e.conversationPadding;
                                var r = t.clientY - e.state.scrollStartPosition,
                                    o = parseInt(e.scrollDiv.style.top, 10) + r;
                                o >= 0 && o <= n - parseInt(e.scrollDiv.style.height, 10) ? (e.scrollDiv.style.top = "".concat(o, "px"), e.moveMessagesFromScroll(o)) : o < 0 ? (e.scrollDiv.style.top = "0px", e.moveMessagesFromScroll(0)) : (e.scrollDiv.style.top = "".concat(n - parseInt(e.scrollDiv.style.height, 10), "px"), e.moveMessagesFromScroll(n - parseInt(e.scrollDiv.style.height, 10))), e.props.iframeDocument.onmouseup = e.scrollStop, e.setState({
                                    scrollStartPosition: t.clientY
                                })
                            }))
                        })), w()(f()(e), "scrollStop", (function() {
                            e.props.iframeDocument.onmouseup = null, e.props.iframeDocument.onmousemove = null, e.moveScrollFromMessages(), e.scrollDiv.style.width = null, e.scrollDiv.style.margin = null, e.scrollDiv.style.opacity = null
                        })), e
                    }
                    return l()(n, [{
                        key: "componentDidMount",
                        value: function() {
                            this.moveScrollFromMessages(), this.calculateScrollDivHeight()
                        }
                    }, {
                        key: "componentDidUpdate",
                        value: function(e) {
                            var t = e.messagesLength !== this.props.messagesLength,
                                n = e.showOldMessages !== this.props.showOldMessages;
                            t && (this.messageWasAdded = !0), (t || n) && this.calculateScrollDivHeight()
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return Object(S.d)("div", {
                                id: "conversation-scroll"
                            }, Object(S.d)("div", {
                                onMouseDown: this.handleScrollMove,
                                ref: this.bindScroll
                            }))
                        }
                    }]), n
                }(O.a.Component),
                Ar = function(e) {
                    return Object(S.d)(X, { in: !1 !== e.operatorIsTyping,
                        classNames: "operatorTyping"
                    }, Object(S.d)("div", {
                        className: "message message-operator typing-indicator"
                    }, Object(S.d)("span", null), Object(S.d)("span", null), Object(S.d)("span", null)))
                };

            function Cr(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }
            var Sr = function(e) {
                    b()(n, e);
                    var t = Cr(n);

                    function n() {
                        return c()(this, n), t.apply(this, arguments)
                    }
                    return l()(n, [{
                        key: "componentDidMount",
                        value: function() {
                            var e = this;
                            setTimeout((function() {
                                e.props.dispatch(Object(pt.Jb)(e.props.content))
                            }), 6e3)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return Object(S.d)("div", {
                                className: "message message-operator message-alert",
                                role: "alert",
                                "aria-live": "assertive",
                                "aria-atomic": "true"
                            }, Object(S.d)(ft.a, null), this.props.content)
                        }
                    }]), n
                }(O.a.Component),
                Er = Object(j.b)((function(e) {
                    return {
                        content: e.alert.content
                    }
                }))(Sr),
                Rr = function() {
                    var e = Object(j.c)(),
                        t = Object(j.d)((function(e) {
                            return e.messages
                        })),
                        n = Object(j.d)((function(e) {
                            return e.operatorIsTyping
                        })),
                        r = Object(j.d)((function(e) {
                            return e.alert.isVisible
                        })),
                        a = Object(j.d)((function(e) {
                            return e.isMobile
                        })),
                        s = Object(j.d)((function(e) {
                            return e.showOldMessages
                        })),
                        c = Object(j.d)((function(e) {
                            return e.isDragAndDropActive
                        })),
                        u = Object(x.useRef)(Object(St.c)()),
                        l = Object(x.useRef)(),
                        d = Object(x.useRef)(),
                        f = Object(x.useRef)(0),
                        p = Object(x.useState)(!1),
                        b = i()(p, 2),
                        h = b[0],
                        m = b[1];
                    Object(x.useEffect)((function() {
                        d.current && m(!0)
                    }), []);
                    var g = function() {
                        d.current && (d.current.scrollTop = d.current.scrollHeight - d.current.clientHeight)
                    };
                    Object(x.useEffect)((function() {
                        return e(Object(pt.lc)(a ? Ct.f.mobile : Ct.f.chatSize1)), g(), f.current = setTimeout((function() {
                                d.current && d.current.scrollTop - d.current.scrollHeight !== d.current.clientHeight && g()
                            }), 100),
                            function() {
                                return clearTimeout(f.current)
                            }
                    }), [e, a]);
                    var v = Object(x.useState)(s),
                        y = i()(v, 2),
                        w = y[0],
                        O = y[1];
                    Object(x.useEffect)((function() {
                        w !== s && l.current && (l.current.scrollIntoView(), O(s))
                    }), [s, w]);
                    var k = Object(x.useState)(t),
                        M = i()(k, 2),
                        A = M[0],
                        C = M[1],
                        E = d.current && d.current.scrollHeight > d.current.clientHeight + 40,
                        R = t.length,
                        D = Boolean(t.length > 0 && "uploadedFile" === t[R - 1].type && t[R - 1].imageLoaded),
                        N = A.length < R;
                    Object(x.useEffect)((function() {
                        A.length !== t.length && g(), E && N && function() {
                            try {
                                for (var e = Array.from(u.current.querySelectorAll(".message")).slice(-9), t = e[e.length - 1].offsetHeight, n = 0; n < e.length; n += 1) e[n].style.transition = "none", e[n].style.transform = "translateY(".concat(t, "px)");
                                setTimeout((function() {
                                    for (var t = 0; t < e.length; t += 1) e[t].style.transition = "transform 0.2s, margin 0.2s", e[t].style.transform = ""
                                }), 0)
                            } catch (r) {
                                Object(ct.a)(r)
                            }
                        }(), C(t)
                    }), [E, u, t, A, N]), Object(x.useEffect)((function() {
                        (r || n || D) && g()
                    }), [r, n, D]);
                    var T = Object(lt.m)(),
                        P = Object(lt.I)(),
                        L = t.filter((function(e) {
                            return Math.floor(Date.now() / 1e3) - e.time_sent > 86400
                        })),
                        _ = t.filter((function(e) {
                            return Math.floor(Date.now() / 1e3) - e.time_sent <= 86400
                        })),
                        F = pt.Ec ? t : _,
                        z = Object(x.useState)(F.length),
                        I = i()(z, 1)[0];
                    return Object(x.useEffect)((function() {
                        I === F.length && (F.filter((function(e) {
                            return "uploadedFile" === e.type && "image" === e.attachmentType
                        })).find((function(e) {
                            return !e.imageLoaded
                        })) || g())
                    }), [I, F]), Object(S.d)("div", {
                        id: "conversation-group",
                        ref: d,
                        className: "".concat("Firefox" === T.name ? "native-scroll" : "", " ").concat(c ? "drag-active" : "", " ").concat(P ? "ios-ipad" : ""),
                        role: "log"
                    }, c && Object(S.d)("div", {
                        className: "uploadIconWrapper"
                    }, Object(S.d)("div", {
                        className: "upload-circle"
                    }, Object(S.d)(ft.G, null), Object(S.d)("span", null, Object(Ge.c)("dragAndDropInfo", null, "Drop here to attach")))), Object(S.d)("div", {
                        id: "messages",
                        "aria-live": "polite",
                        "aria-atomic": "false",
                        "data-testid": "messagesLog"
                    }, s && L.map((function(e) {
                        return Object(S.d)(jr, o()({
                            key: e.id
                        }, e, {
                            sender: e.sender
                        }))
                    })), !s && L.length > 0 && Object(S.d)("div", {
                        className: "history-button-wrapper",
                        "data-testid": "historyButtonWrapper"
                    }, Object(S.d)("button", {
                        className: "history-button",
                        type: "button",
                        onClick: function() {
                            e(Object(pt.Sc)(mt.a.showPreviousMessagesClicked)), e(Object(pt.Ec)(!0))
                        },
                        "data-testid": "historyButton"
                    }, Object(S.d)(ft.o, null), Object(Ge.c)("previousMessages", null, "Previous messages"))), L.length > 0 && Object(S.d)("div", {
                        ref: l,
                        style: {
                            float: "left",
                            clear: "both",
                            width: "100%"
                        }
                    }), _.map((function(e) {
                        return Object(S.d)(jr, o()({
                            key: e.id
                        }, e, {
                            sender: e.sender
                        }))
                    })), Object(S.d)(Qt, { in: r
                    }, Object(S.d)(Er, null)), Object(S.d)(Ar, {
                        operatorIsTyping: n
                    })), h && "Firefox" !== T.name && !a && Object(S.d)(Mr, {
                        messagesLength: t.length,
                        conversationRef: d.current,
                        iframeDocument: u.current,
                        showOldMessages: s
                    }))
                },
                Dr = function(e) {
                    return Object(S.d)("div", {
                        className: "get-started"
                    }, Object(S.d)("button", {
                        type: "button",
                        onClick: e.onClick
                    }, Object(S.d)(ot, {
                        value: "getStarted",
                        fallback: "Get started"
                    })))
                };

            function Nr(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function Tr(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Nr(Object(n), !0).forEach((function(t) {
                        w()(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Nr(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }
            var Pr = function(e) {
                return Object(S.d)(G, { in: e.in,
                    timeout: e.timeout,
                    appear: !0,
                    addEndListener: function(t) {
                        t.addEventListener("transitionend", e.onAnimationEnded, !1)
                    }
                }, (function(t) {
                    return Object(S.d)("div", {
                        className: "transition-container",
                        style: Tr(Tr({}, e.defaultStyle), e.transitionStyles[t])
                    }, e.children)
                }))
            };

            function Lr(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }
            var _r = function(e) {
                    b()(n, e);
                    var t = Lr(n);

                    function n() {
                        var e;
                        c()(this, n);
                        for (var r = arguments.length, o = new Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                        return e = t.call.apply(t, [this].concat(o)), w()(f()(e), "onCloseClick", (function() {
                            e.props.dispatch(Object(pt.Sc)(e.props.trackingEvent)), e.props.dispatch(Object(pt.Ic)(!1)), e.props.dispatch(Object(pt.gc)(!1))
                        })), e
                    }
                    return l()(n, [{
                        key: "render",
                        value: function() {
                            return Object(S.d)(O.a.Fragment, null, (!this.props.isChatOnSite || this.props.isChatOnSite && this.props.isMobile) && Object(S.d)("button", {
                                type: "button",
                                className: "material-icons exit-chat mobile-close",
                                onClick: this.onCloseClick,
                                "aria-label": Object(Ge.c)("closeWidget", null, "Close chat widget")
                            }, Object(S.d)(ft.h, null)))
                        }
                    }]), n
                }(O.a.Component),
                Fr = Object(j.b)((function(e) {
                    return {
                        isChatOnSite: Object(vt.b)(e),
                        isMobile: e.isMobile
                    }
                }))(_r),
                zr = n(146),
                Ir = n.n(zr),
                Br = (n(388), n(389), n(101), n(48)),
                Hr = n.n(Br),
                Wr = Object(j.b)((function(e) {
                    return {
                        widgetColor: e.widgetColor
                    }
                }))((function(e) {
                    var t = e.widgetColor;
                    return Object(S.d)("button", {
                        className: "user-data-modal-submit",
                        type: "submit",
                        style: {
                            background: "linear-gradient(99deg, ".concat(t[0], ", ").concat(t[1], ")"),
                            color: t[2] || "#fff",
                            boxShadow: "".concat(Object(lt.v)(t[3], "0.24"), " 0px 8px 32px 0px")
                        }
                    }, Object(S.d)(ot, {
                        value: "offlineSendButton"
                    }))
                })),
                Vr = Object(j.b)((function(e) {
                    return {
                        operators: e.operators
                    }
                }))((function(e) {
                    var t = e.operators.find((function(e) {
                        return e.isOnline
                    })) ? e.operators.filter((function(e) {
                        return e.isOnline
                    })) : e.operators;
                    return Object(S.d)("div", {
                        className: "user-data-modal-operators"
                    }, t.slice(0, 4).map((function(e) {
                        return Object(S.d)(it, {
                            key: e.id,
                            avatarSrc: e.avatarSrc,
                            className: "user-data-modal-operator"
                        })
                    })))
                })),
                Ur = function(e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [],
                        r = 270,
                        o = O.a.useState(!1),
                        a = i()(o, 2),
                        s = a[0],
                        c = a[1],
                        u = Object(St.e)();
                    return O.a.useEffect((function() {
                        function n() {
                            e.current && t.current && (e.current.clientHeight - t.current.clientHeight > r ? c(!0) : c(!1))
                        }
                        return u && u.addEventListener("resize", n),
                            function() {
                                u && u.removeEventListener("resize", n)
                            }
                    }), [t, e, u, n]), O.a.useEffect((function() {
                        if (e.current && t.current) {
                            var n = e.current.clientHeight - t.current.clientHeight > r;
                            c(n)
                        }
                    }), [s, e, t, n]), s
                },
                qr = (n(390), n(105));
            var Gr = {
                    name: "1ll2r3v",
                    styles: "position:relative;z-index:1;margin-bottom:8px;border:1px solid rgba(108, 125, 159, 0.24);border-radius:5px;"
                },
                Yr = {
                    name: "1oo9jfo",
                    styles: "border-color:#f6303a;select{&:not(:focus):invalid{color:#f6303a;}}svg{fill:#f6303a;}"
                },
                Qr = {
                    name: "1fqx5q",
                    styles: "border-color:#007DFC;svg{fill:#647491;}"
                },
                Kr = {
                    name: "zaj675",
                    styles: 'overflow:hidden;display:block;width:100%;padding:9px 40px 10px 12px;border:none;border-radius:0;outline:none;background:transparent;color:#080F1A;font-size:15px;appearance:none;white-space:nowrap;text-overflow:ellipsis;&:not(:focus):invalid{color:#8894ab;}option[value=""][disabled]{display:none;}'
                },
                Zr = {
                    name: "znmab8",
                    styles: "position:absolute;top:0;bottom:0;right:8px;width:24px;height:24px;margin:auto;pointer-events:none;svg{top:auto;left:auto;fill:#647491;}"
                },
                Xr = Object(lt.y)(),
                $r = function(e) {
                    var t = e.onChange,
                        n = e.hasError,
                        r = e.shakeClassName,
                        o = Object(j.d)(vt.c),
                        a = Object(x.useState)(!1),
                        s = i()(a, 2),
                        c = s[0],
                        u = s[1],
                        l = Object(x.useState)(""),
                        d = i()(l, 2),
                        f = d[0],
                        p = d[1];
                    if (!o.length) return null;
                    var b = Object(Ge.c)("routingRules_selector", null, "Select Department...");
                    return Object(S.d)("div", {
                        css: Object(qr.a)([Gr, n && Yr, c && Qr], ""),
                        className: r
                    }, Object(S.d)("select", {
                        css: Kr,
                        value: f,
                        required: !0,
                        form: "novalidatedform",
                        onFocus: function() {
                            u(!0)
                        },
                        onBlur: function() {
                            u(!1)
                        },
                        onChange: function(e) {
                            var n, r = e.target.value,
                                a = null === (n = o.find((function(e) {
                                    return e.position === Number(r)
                                }))) || void 0 === n ? void 0 : n.departmentId;
                            Xr || p(r), t && a && t(a)
                        },
                        title: b
                    }, Object(S.d)("option", {
                        value: "",
                        disabled: !0
                    }, b), o.map((function(e) {
                        var t = e.alias,
                            n = e.position;
                        return Object(S.d)("option", {
                            key: n,
                            value: n
                        }, t)
                    }))), Object(S.d)("div", {
                        css: Zr
                    }, Object(S.d)(ft.c, null)))
                };

            function Jr(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function eo(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? Jr(Object(n), !0).forEach((function(t) {
                        w()(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Jr(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function to(e) {
                var t = e;
                return [yn.b, "signUpNewsletter"].forEach((function(e) {
                    "undefined" !== typeof t[e] && (t[e] = Boolean(t[e]))
                })), "boolean" === typeof t[yn.b] && (t[yn.b] = {
                    value: t[yn.b] ? "subscribed" : "unsubscribed",
                    date: Math.round(Date.now() / 1e3),
                    setBy: "user"
                }), t
            }

            function no(e) {
                var t = {};
                return e.forEach((function(e) {
                    t[e.type] = {
                        isValid: !1,
                        value: t[e.type] ? t[e.type] : ""
                    }
                })), {
                    inputValues: t,
                    fieldsWithErrors: {}
                }
            }

            function ro(e, t) {
                switch (t.type) {
                    case "SET_INPUT":
                        var n = t.fieldType,
                            r = t.isValid,
                            o = t.value;
                        return eo(eo({}, e), {}, {
                            inputValues: eo(eo({}, e.inputValues), {}, w()({}, n, {
                                isValid: r,
                                value: o
                            })),
                            fieldsWithErrors: eo(eo({}, e.fieldsWithErrors), {}, w()({}, n, !1))
                        });
                    case "SHOW_ERROR_ON_INVALID_FIELDS":
                        var a = Object.entries(e.inputValues).filter((function(e) {
                            return !i()(e, 2)[1].isValid
                        })).reduce((function(e, t) {
                            var n = i()(t, 1)[0];
                            return eo(eo({}, e), {}, w()({}, n, !0))
                        }), {});
                        return eo(eo({}, e), {}, {
                            fieldsWithErrors: a
                        });
                    default:
                        throw new Error
                }
            }
            var oo = Object(j.b)((function(e) {
                    return {
                        preChatFields: Object(bt.d)(e.preChat.data, e.visitor),
                        areDepartmentsEnabled: Object(vt.a)(e)
                    }
                }))((function(e) {
                    var t = e.areDepartmentsEnabled ? [].concat(Hr()(e.preChatFields), [{
                            type: yn.a
                        }]) : e.preChatFields,
                        n = O.a.useReducer(ro, t, no),
                        r = i()(n, 2),
                        o = r[0],
                        a = r[1],
                        s = Rt(),
                        c = s.triggerShake,
                        u = s.shakeClassName;

                    function l(e, t, n) {
                        a({
                            type: "SET_INPUT",
                            fieldType: n,
                            value: e,
                            isValid: t
                        })
                    }
                    var d = O.a.useRef();
                    O.a.useEffect((function() {
                        d.current && d.current.focus()
                    }), []);
                    var f = O.a.useRef(),
                        p = Ur(e.parentContainerRef, f, e.preChatFields);

                    function b(t) {
                        return t && t.preventDefault(), Object.values(o.inputValues).every((function(e) {
                            return !0 === e.isValid
                        })) ? (e.dispatch(Object(pt.ac)(function(e) {
                            var t = {};
                            return Object.keys(e).forEach((function(n) {
                                t[n] = e[n].value
                            })), !0 === t.signUpNewsletter && (t.emailConsent = !0), to(t)
                        }(o.inputValues))), !0) : (c(), a({
                            type: "SHOW_ERROR_ON_INVALID_FIELDS"
                        }), !1)
                    }

                    function h(e) {
                        13 === e && b()
                    }
                    var m = function(e, t) {
                            return Object(S.d)(xn, {
                                key: e.type,
                                type: e.type,
                                placeholder: e.placeholder,
                                onInputChange: l,
                                disabled: !1,
                                onKeyDown: h,
                                forceErrorIcon: o.fieldsWithErrors[e.type],
                                shakeClassName: o.fieldsWithErrors[e.type] && u ? u : "",
                                ref: 0 === t ? d : void 0,
                                value: e.value
                            })
                        },
                        g = e.preChatFields.filter((function(e) {
                            return e.type !== yn.b
                        })),
                        v = e.preChatFields.find((function(e) {
                            return e.type === yn.b
                        })),
                        y = o.fieldsWithErrors[yn.a];
                    return Object(S.d)(A.animated.div, {
                        className: "pre-chat",
                        style: e.style
                    }, p && Object(S.d)(Vr, null), Object(S.d)("form", {
                        onSubmit: b,
                        ref: f
                    }, Object(S.d)("div", {
                        className: "user-data-modal-text"
                    }, Object(S.d)(ot, {
                        value: "preformMessage",
                        emojify: !0
                    })), Object(S.d)("div", {
                        className: "user-data-modal-fields"
                    }, g.map(m), e.areDepartmentsEnabled && Object(S.d)($r, {
                        onChange: function(e) {
                            a({
                                type: "SET_INPUT",
                                fieldType: yn.a,
                                value: e,
                                isValid: !0
                            })
                        },
                        shakeClassName: y && u ? u : "",
                        hasError: y
                    }), v && m(v, g.length)), Object(S.d)(Wr, null)))
                })),
                ao = Object(j.b)()((function(e) {
                    var t = O.a.useState(""),
                        n = i()(t, 2),
                        r = n[0],
                        o = n[1],
                        a = O.a.useState(!1),
                        s = i()(a, 2),
                        c = s[0],
                        u = s[1],
                        l = O.a.useState(!1),
                        d = i()(l, 2),
                        f = d[0],
                        p = d[1],
                        b = Rt(),
                        h = b.triggerShake,
                        m = b.shakeClassName,
                        g = O.a.useRef();
                    O.a.useEffect((function() {
                        g.current && g.current.focus()
                    }), []);
                    var v = O.a.useRef(),
                        y = Ur(e.parentContainerRef, v);

                    function w(t) {
                        return t && t.preventDefault(), c ? (e.dispatch(Object(pt.Zb)(r)), !0) : (p(!0), h(), !1)
                    }
                    return Object(S.d)(A.animated.div, {
                        className: "always-online",
                        style: e.style
                    }, y && Object(S.d)(Vr, null), Object(S.d)("form", {
                        onSubmit: w,
                        ref: v
                    }, Object(S.d)("div", {
                        className: "user-data-modal-text"
                    }, Object(S.d)(ot, {
                        value: "alwaysOnlineEngageMessage",
                        emojify: !0
                    })), Object(S.d)("div", {
                        className: "user-data-modal-fields"
                    }, Object(S.d)(vn, {
                        type: "email",
                        placeholder: "preformInput_email",
                        onChange: function(e, t) {
                            o(e), u(t), p(!1)
                        },
                        onKeyDown: function(e) {
                            13 === e && w()
                        },
                        disabled: !1,
                        bindInputRef: g,
                        forceErrorIcon: f,
                        shakeClassName: m
                    })), Object(S.d)(Wr, null)))
                }));

            function io(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }
            var so = Object(j.b)((function(e) {
                    return {
                        showUserDataModal: e.showUserDataModal,
                        widgetColor: e.widgetColor
                    }
                }))((function(e) {
                    var t = O.a.useRef();
                    O.a.useEffect((function() {
                        return function() {
                            Object(St.b)()
                        }
                    }), []);
                    var n = Object(A.useTransition)(e.showUserDataModal, null, {
                            config: A.config.stiff,
                            from: {
                                transform: "translateY(-10px)"
                            },
                            enter: {
                                transform: "translateY(0)"
                            },
                            leave: {
                                transform: "translateY(10px)"
                            }
                        }),
                        r = e.style,
                        o = r.fillerHeight,
                        a = Ir()(r, ["fillerHeight"]),
                        i = O.a.useMemo((function() {
                            return function(e) {
                                for (var t = 1; t < arguments.length; t++) {
                                    var n = null != arguments[t] ? arguments[t] : {};
                                    t % 2 ? io(Object(n), !0).forEach((function(t) {
                                        w()(e, t, n[t])
                                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : io(Object(n)).forEach((function(t) {
                                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                                    }))
                                }
                                return e
                            }({
                                backgroundImage: "linear-gradient(#fff, #fff), linear-gradient(118deg, ".concat(e.widgetColor[0], ", ").concat(e.widgetColor[1], ")")
                            }, a)
                        }), [e.widgetColor, a]);
                    return Object(S.d)(A.animated.div, {
                        className: "user-data-modal",
                        style: i,
                        ref: t,
                        "data-testid": "userDataModal"
                    }, Object(S.d)("button", {
                        className: "user-data-modal-close",
                        onClick: function() {
                            e.dispatch(Object(pt.Sc)(mt.a.closeModalClicked)), e.dispatch(Object(pt.Fc)(!1))
                        },
                        type: "button",
                        "aria-label": Object(Ge.c)("closeUserDataModal", null, "Close modal")
                    }, Object(S.d)(ft.h, null)), n.map((function(e) {
                        var n = e.item,
                            r = e.key,
                            o = e.props;
                        return "prechat" === n ? Object(S.d)(oo, {
                            parentContainerRef: t,
                            key: r,
                            style: o
                        }) : "alwaysOnline" === n ? Object(S.d)(ao, {
                            parentContainerRef: t,
                            key: r,
                            style: o
                        }) : null
                    })), Object(S.d)(A.animated.div, {
                        className: "user-data-modal-filler",
                        style: {
                            height: o
                        }
                    }))
                })),
                co = Object(j.b)((function(e) {
                    return {
                        showUserDataModal: e.showUserDataModal
                    }
                }))((function(e) {
                    return Object(A.useTransition)(!1 !== e.showUserDataModal, null, {
                        config: {
                            tension: 150,
                            friction: 20
                        },
                        from: {
                            opacity: 0,
                            fillerHeight: "93%",
                            moveContent: "translateY(-20px)"
                        },
                        enter: {
                            opacity: 1,
                            fillerHeight: "96%",
                            moveContent: "translateY(0)"
                        },
                        leave: {
                            opacity: 0,
                            fillerHeight: "105%",
                            moveContent: "translateY(20px)"
                        }
                    }).map((function(e) {
                        var t = e.item,
                            n = e.key,
                            r = e.props;
                        return t && Object(S.d)(so, {
                            key: n,
                            style: r
                        })
                    }))
                })),
                uo = {
                    transition: "max-height 200ms"
                },
                lo = Boolean(Object(Ge.c)("welcomeMessage", null, "")),
                fo = Object(lt.m)().name.toLowerCase(),
                po = Object(lt.r)().name.toLowerCase(),
                bo = Object(lt.y)(),
                ho = Ct.e[Ct.f.chatSize1].width,
                mo = function() {
                    var e = Object(j.d)((function(e) {
                            return e.view
                        })),
                        t = Object(j.d)((function(e) {
                            return e.showOptionsDropdown
                        })),
                        n = Object(j.d)((function(e) {
                            return e.isMobile
                        })),
                        r = Object(j.d)((function(e) {
                            return e.messages
                        })),
                        a = Object(j.d)((function(e) {
                            return e.getStartedActive
                        })),
                        s = Object(j.d)((function(e) {
                            return e.hideHeader
                        })),
                        c = Object(j.d)(Dt.l),
                        u = Object(j.d)((function(e) {
                            return e.isDragAndDropActive
                        })),
                        l = Object(j.d)((function(e) {
                            return e.newMessageDisabled
                        })),
                        d = Object(j.d)((function(e) {
                            return e.isProjectOnline
                        })),
                        f = Object(j.d)(Dt.m),
                        p = Object(x.useState)(r.length),
                        b = i()(p, 1)[0],
                        h = Object(x.useState)(c && !n),
                        m = i()(h, 2),
                        g = m[0],
                        v = m[1],
                        y = Object(x.useRef)(0),
                        w = Object(x.useRef)(""),
                        k = Object(x.useRef)(""),
                        M = Object(x.useState)(e),
                        A = i()(M, 2),
                        C = A[0],
                        E = A[1],
                        R = Object(j.c)(),
                        D = Object(x.useRef)(null),
                        N = Object(St.e)(),
                        T = Object(x.useRef)(100),
                        P = Object(x.useRef)(n && "ios" === po),
                        L = Object(x.useRef)({
                            entering: {
                                maxHeight: "".concat(T.current, "px")
                            },
                            entered: {
                                maxHeight: "399px"
                            }
                        }),
                        _ = Object(x.useState)(144),
                        F = i()(_, 2),
                        z = F[0],
                        I = F[1];
                    Object(x.useEffect)((function() {
                        var e = d && !Object(Ge.c)("weAreOnline") || !d && !Object(Ge.c)("alwaysOnlineTopBar");
                        I(e ? 94 : 144)
                    }), [d, I]);
                    var B = Object(x.useCallback)((function() {
                            if (P.current) try {
                                N && N.parent.scrollTo(0, y.current)
                            } catch (e) {
                                Object(ct.a)(e)
                            }
                        }), [N]),
                        H = Object(x.useCallback)((function() {
                            if (n && N) try {
                                N.parent.document.body.style.cssText = w.current, N.parent.document.documentElement.style.cssText = k.current
                            } catch (e) {}
                        }), [n, N]);
                    Object(x.useEffect)((function() {
                        return function() {
                            H(), B()
                        }
                    }), [H, B]), Object(x.useEffect)((function() {
                        P.current && 0 === y.current && N && (y.current = N.parent.scrollY)
                    }), [N]), Object(x.useEffect)((function() {
                        if (e === ht.a.chat && n && N) try {
                            k.current = N.parent.document.documentElement.style.cssText, w.current = N.parent.document.body.style.cssText;
                            var t = "overflow: hidden; height: 100%; width: 100%; visibility: visible; opacity: 1 !important; display: block; left: 0; top:0; right: auto; bottom: auto; margin: 0;";
                            "ios" === po && "chrome" !== fo && (t += "position:fixed;"), N.parent.document.body.style.cssText = t, N.parent.document.documentElement.style.cssText = "overflow: hidden; margin: 0 !important;"
                        } catch (r) {}
                    }), [n, e, N]), Object(x.useEffect)((function() {
                        C === ht.a.welcome && setTimeout((function() {
                            if (D.current && C === ht.a.welcome) {
                                var e = D.current.clientHeight;
                                R(Object(pt.lc)(Ct.f.dynamic, {
                                    width: ho,
                                    height: e + 51
                                })), T.current = e - 110 - z, L.current = {
                                    entering: {
                                        maxHeight: "".concat(T.current, "px")
                                    },
                                    entered: {
                                        maxHeight: "399px"
                                    }
                                }
                            }
                        }), 100)
                    }), [R, z, C]), Object(x.useEffect)((function() {
                        r.length > b && E(ht.a.chat), 0 === r.length && e === ht.a.welcome && E(ht.a.welcome), C === ht.a.welcome && e === ht.a.chat && E(ht.a.chat)
                    }), [r.length, b, C, e]);
                    var W = function() {
                            t && n && "ios" === po && R(Object(pt.qc)(!1))
                        },
                        V = Ue({
                            onDrop: Object(x.useCallback)((function(e) {
                                var t = e[0];
                                R(Object(pt.Oc)(t)), R(Object(pt.ic)(!1))
                            }), [R]),
                            onDragEnter: function() {
                                u || R(Object(pt.ic)(!0))
                            },
                            onDragLeave: function() {
                                R(Object(pt.ic)(!1))
                            },
                            noClick: !0,
                            noKeyboard: !0,
                            disabled: !r.find((function(e) {
                                return "visitor" === e.sender
                            })) || bo || l || f
                        }).getRootProps;
                    return C === ht.a.welcome ? Object(S.d)("div", {
                        className: "start-group ".concat(fo, " no-clip-path ").concat(lo ? "" : "no-start-message"),
                        "data-testid": "welcomeView",
                        onClick: W,
                        ref: D
                    }, Object(S.d)(Mt, null), a ? Object(S.d)(Dr, {
                        onClick: function() {
                            R(Object(pt.Ab)())
                        }
                    }) : Object(S.d)(Jt, null)) : Object(S.d)("div", o()({
                        className: "chat no-clip-path ".concat(fo),
                        onClick: W
                    }, V({
                        onClick: function(e) {
                            return e.stopPropagation()
                        }
                    })), Object(S.d)(O.a.Fragment, null, !g && Object(S.d)(co, null), !(s && n) && Object(S.d)(At, null), s && n && Object(S.d)(Fr, {
                        trackingEvent: mt.a.chatClosed
                    }), g ? Object(S.d)(Pr, { in: !0,
                        timeout: 1,
                        defaultStyle: uo,
                        transitionStyles: L.current,
                        onAnimationEnded: function() {
                            v(!1)
                        }
                    }, Object(S.d)(Rr, null)) : Object(S.d)(Rr, null)), Object(S.d)(Jt, {
                        hasSeparator: !0
                    }))
                },
                go = Object(j.b)((function(e) {
                    return {
                        unreadMessages: e.unreadMessages
                    }
                }))((function(e) {
                    return Object(S.d)(X, {
                        classNames: "ie" === e.browserName ? "fade" : "scale",
                        in: e.unreadMessages > 0
                    }, Object(S.d)("div", {
                        id: "new-message",
                        className: "active"
                    }, e.unreadMessages))
                }));

            function vo(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }
            var yo = {
                    active: "0px 4px 24px",
                    hover: "0px 8px 32px"
                },
                wo = {
                    active: "0px 2px 16px",
                    hover: "0px 2px 12px"
                };

            function xo(e, t) {
                return e ? wo[t] : yo[t]
            }
            var Oo = function(e) {
                b()(n, e);
                var t = vo(n);

                function n() {
                    var e;
                    c()(this, n);
                    for (var r = arguments.length, o = new Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                    return e = t.call.apply(t, [this].concat(o)), w()(f()(e), "state", {
                        elementHovered: !1,
                        buttonShadow: "#020610" === e.props.widgetColor[3] ? "".concat(xo(e.props.isAwesomeIframe, "active"), " ").concat(Object(lt.v)(e.props.widgetColor[3], ".20")) : "".concat(xo(e.props.isAwesomeIframe, "active"), " ").concat(Object(lt.v)(e.props.widgetColor[3], ".50")),
                        isGradientActive: "#020610" !== e.props.widgetColor[3]
                    }), w()(f()(e), "browserName", Object(lt.m)().name.toLowerCase()), w()(f()(e), "wrapperRef", O.a.createRef()), w()(f()(e), "buttonWave", (function() {
                        e.wrapperRef.current && (e.wrapperRef.current.classList.contains("clicked") && e.wrapperRef.current.classList.remove("clicked"), setTimeout((function() {
                            e.wrapperRef.current && e.wrapperRef.current.classList.add("clicked")
                        }), 10))
                    })), w()(f()(e), "onBubbleClick", (function(t) {
                        var n = e.props,
                            r = n.dispatch,
                            o = n.hasMessages,
                            a = n.newMessageDisabled,
                            i = n.view,
                            s = ht.a.chat,
                            c = ht.a.closed,
                            u = ht.a.fly,
                            l = ht.a.welcome;
                        0 === t.nativeEvent.pageX && 0 === t.nativeEvent.pageY || t.currentTarget.blur(), i !== c ? (a ? Object(St.a)() : r(Object(pt.kc)(!0)), (i === u || i === l && o) && r(Object(pt.uc)(s))) : (r(Object(pt.Sc)(mt.a.widgetIconClicked)), r(Object(pt.Pc)()), r(Object(pt.gc)(!0)))
                    })), w()(f()(e), "setHoverShadow", (function() {
                        e.setState({
                            elementHovered: !0
                        })
                    })), w()(f()(e), "setDefaultShadow", (function() {
                        e.setState({
                            elementHovered: !1
                        })
                    })), e
                }
                return l()(n, [{
                    key: "render",
                    value: function() {
                        var e = this.props,
                            t = e.view,
                            n = e.widgetColor,
                            r = e.newMessageDisabled,
                            o = t !== ht.a.closed,
                            a = t === ht.a.closed || t === ht.a.fly,
                            i = n[0],
                            s = n[2] || "#fff",
                            c = r && t === ht.a.chat;
                        return i = c ? "linear-gradient(#c6ccdc,#c6ccdc)" : n[0] === n[1] ? n[0] : "linear-gradient(135deg, ".concat(this.props.widgetColor[0], ", ").concat(this.props.widgetColor[1], ")"), Object(S.d)("div", {
                            id: "button",
                            "data-testid": "widgetButton",
                            className: "".concat(this.props.isSidebarComponent ? "sidebar" : "", " ").concat(o ? "chat-open" : "chat-closed", " mobile-size__").concat(this.props.mobileButtonSize),
                            ref: this.wrapperRef
                        }, this.props.isSidebarComponent && Object(S.d)("div", {
                            className: "sidebar-content",
                            style: {
                                background: this.props.sidebar.color
                            },
                            onClick: this.onBubbleClick
                        }, Object(S.d)("span", null, Object(S.d)(ot, {
                            value: "sidebarLabel"
                        }))), Object(S.d)("div", {
                            className: "buttonWave"
                        }), Object(S.d)("button", {
                            type: "button",
                            id: "button-body",
                            "data-testid": "widgetButtonBody",
                            onClick: this.onBubbleClick,
                            onMouseDown: this.buttonWave,
                            style: {
                                color: c ? i : "#007dfc",
                                background: i,
                                boxShadow: this.state.buttonShadow
                            },
                            onMouseEnter: this.setHoverShadow,
                            onMouseLeave: this.setDefaultShadow,
                            className: "".concat(c ? "disabled" : "", " ").concat(this.browserName),
                            tabIndex: "0",
                            "aria-label": o ? Object(Ge.c)("closeWidget", null, "Close chat widget") : Object(Ge.c)("openWidget", null, "Open chat widget")
                        }, Object(S.d)("i", {
                            className: "material-icons type1 for-closed ".concat(a ? "active" : ""),
                            style: {
                                color: s
                            }
                        }, Object(S.d)(ft.f, null)), Object(S.d)("i", {
                            className: "material-icons type2 for-closed ".concat(a ? "active" : "")
                        }, Object(S.d)(ft.i, null)), Object(S.d)("i", {
                            className: "material-icons type1 for-opened ".concat(a ? "" : "active"),
                            style: {
                                color: s
                            }
                        }, Object(S.d)(ft.x, null)), Object(S.d)("i", {
                            className: "material-icons type2 for-opened ".concat(a ? "" : "active")
                        }, Object(S.d)(ft.x, null))), !this.props.isSidebarComponent && Object(S.d)(O.a.Fragment, null, Object(S.d)(go, {
                            browserName: this.browserName
                        }), Object(S.d)(X, {
                            classNames: "ie" === this.browserName ? "fade" : "scale",
                            in: this.props.isSoundEnabled && this.props.areNotificationSnoozed
                        }, Object(S.d)("div", {
                            id: "dnd-indicator"
                        }, Object(S.d)(ft.s, null)))))
                    }
                }], [{
                    key: "getDerivedStateFromProps",
                    value: function(e, t) {
                        return e.newMessageDisabled && e.view !== ht.a.closed && !t.elementHovered ? {
                            buttonShadow: "".concat(xo(e.isAwesomeIframe, "active"), " ").concat(Object(lt.v)("#020610", ".20"))
                        } : e.newMessageDisabled && e.view !== ht.a.closed && t.elementHovered ? {
                            buttonShadow: "".concat(xo(e.isAwesomeIframe, "hover"), " ").concat(Object(lt.v)("#020610", ".20"))
                        } : t.elementHovered ? t.elementHovered ? {
                            buttonShadow: "".concat(xo(e.isAwesomeIframe, "hover"), " ").concat(Object(lt.v)(e.widgetColor[3], t.isGradientActive ? ".24" : ".20"))
                        } : null : {
                            buttonShadow: "".concat(xo(e.isAwesomeIframe, "active"), " ").concat(Object(lt.v)(e.widgetColor[3], t.isGradientActive ? ".50" : ".20"))
                        }
                    }
                }]), n
            }(O.a.Component);
            Oo.defaultProps = {
                isSidebarComponent: !1
            };
            var jo = Object(j.b)((function(e) {
                    return {
                        view: e.view,
                        widgetColor: Object(lt.d)(e.widgetColor),
                        areNotificationSnoozed: e.notificationSnoozed,
                        newMessageDisabled: e.newMessageDisabled,
                        sidebar: e.sidebarIframeStyles,
                        hasMessages: Boolean(e.messages.length),
                        mobileButtonSize: e.mobileButtonSize,
                        isSoundEnabled: e.isSoundEnabled,
                        isAwesomeIframe: Object(Dt.c)(e)
                    }
                }))(Oo),
                ko = function(e) {
                    var t = Object(j.d)((function(e) {
                            return e.view
                        })),
                        n = Object(x.useState)(t !== ht.a.closed),
                        r = i()(n, 2),
                        o = r[0],
                        a = r[1];
                    return e.children({
                        hasAnimationEnded: o,
                        onAnimationEnded: function() {
                            a((function(e) {
                                return !e
                            }))
                        }
                    })
                };
            ko.propTypes = {
                children: z.a.func.isRequired
            };
            var Mo = ko,
                Ao = Object(j.b)()((function(e) {
                    var t = e.message.type === bt.e.uploadedFile,
                        n = function() {
                            e.dispatch(Object(pt.Sc)(mt.a.flyMessageClicked)), e.dispatch(Object(pt.uc)(ht.a.chat))
                        };
                    return Object(S.d)(ot, {
                        value: ["onlineMessagePlaceholder"]
                    }, (function(r) {
                        var o = r.onlineMessagePlaceholder;
                        return Object(S.d)("button", {
                            type: "button",
                            style: {
                                width: t ? "220px" : "".concat(e.minFlyWidth, "px"),
                                minWidth: t ? "220px" : "".concat(e.minFlyWidth, "px")
                            },
                            id: "new-message-button-fly",
                            className: "fly-new-message-button",
                            onClick: n,
                            "data-testid": "flyNewMessageButton"
                        }, o)
                    }))
                })),
                Co = function(e) {
                    var t = e.showMoreRepliesButton || e.quickReplies.length > e.maxButtons,
                        n = t ? e.quickReplies.slice(0, e.maxButtons - 1) : e.quickReplies;
                    return Object(S.d)("div", {
                        className: "button-wrapper"
                    }, n.map((function(t) {
                        return Object(S.d)(O.a.Fragment, {
                            key: "".concat(t.title).concat(t.payload)
                        }, "url" === t.type && Object(S.d)(ar, {
                            title: t.title,
                            payload: t.payload,
                            url: t.url,
                            onClick: e.onButtonClick
                        }), ("action" === t.type || "bot" === t.type || "text" === t.type) && Object(S.d)(ir, {
                            title: t.title,
                            payload: t.payload,
                            onClick: e.onButtonClick
                        }))
                    })), t && Object(S.d)("button", {
                        type: "button",
                        className: "more-replies",
                        onClick: e.onMoreButtonClick
                    }, Object(S.d)(ft.u, null)))
                };
            Co.defaultProps = {
                showMoreRepliesButton: !1
            };
            var So = Co,
                Eo = Object(j.b)((function(e) {
                    return {
                        isMobile: e.isMobile
                    }
                }))((function(e) {
                    var t, n, r = [];
                    e.message.type === bt.e.cards ? r = (null === (t = e.message.cards) || void 0 === t || null === (n = t[0]) || void 0 === n ? void 0 : n.buttons) || [] : e.message.quickReplies ? r = e.message.quickReplies : e.message.buttons && (r = e.message.buttons);
                    return Object(S.d)(So, {
                        quickReplies: r,
                        onButtonClick: function(t, n) {
                            return e.dispatch(Object(pt.Sc)(mt.a.flyMessageButtonsClicked)), e.dispatch(Object(pt.cc)(n, t)), !0
                        },
                        onMoreButtonClick: function() {
                            e.dispatch(Object(pt.uc)(ht.a.chat))
                        },
                        maxButtons: e.isMobile ? 3 : 4,
                        showMoreRepliesButton: e.message.type === bt.e.cards && e.message.cards.length > 1
                    })
                })),
                Ro = Object(j.b)((function(e) {
                    return {
                        isEmojiPanelVisible: e.isEmojiPanelVisible,
                        widgetColor: e.widgetColor,
                        isMobile: e.isMobile
                    }
                }))((function(e) {
                    return Object(S.d)("div", {
                        className: "input-group"
                    }, e.hasButtons ? Object(S.d)(Eo, {
                        message: e.message
                    }) : Object(S.d)(Ao, {
                        message: e.message,
                        minFlyWidth: e.minFlyWidth
                    }))
                })),
                Do = function(e) {
                    return "image" === e.attachmentType ? Object(S.d)("button", {
                        type: "button",
                        onClick: e.onClick
                    }, Object(S.d)("div", {
                        className: "image-preview",
                        style: {
                            backgroundImage: "url(".concat(e.content, ")")
                        },
                        "data-testid": "imagePreview"
                    })) : Object(S.d)("button", {
                        className: "link",
                        type: "button",
                        onClick: e.onClick,
                        style: {
                            borderBottom: "1px solid #3f88f3",
                            color: "#3f88f3"
                        }
                    }, Object(S.d)(ot, {
                        value: "mediaFile",
                        fallback: "Media file"
                    }))
                };

            function No(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }
            var To = function(e) {
                b()(n, e);
                var t = No(n);

                function n() {
                    var e;
                    c()(this, n);
                    for (var r = arguments.length, o = new Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                    return e = t.call.apply(t, [this].concat(o)), w()(f()(e), "state", {
                        width: 130
                    }), w()(f()(e), "documentRef", Object(St.c)()), e
                }
                return l()(n, [{
                    key: "componentDidMount",
                    value: function() {
                        var e = n.checkWidth(this.props, this.documentRef);
                        e && this.setState({
                            width: e
                        })
                    }
                }, {
                    key: "componentDidUpdate",
                    value: function(e) {
                        if (this.props.lastMessage.content === e.lastMessage.content) return !1;
                        var t = n.checkWidth(this.props, this.documentRef);
                        return t && this.setState({
                            width: t
                        }), !0
                    }
                }, {
                    key: "render",
                    value: function() {
                        return this.props.children(this.state)
                    }
                }]), n
            }(O.a.Component);
            w()(To, "checkWidth", (function(e, t) {
                if (Object(lt.y)()) return 230;
                try {
                    var n = e.messageContentRef,
                        r = ("OffscreenCanvas" in window ? new OffscreenCanvas(500, 100) : t.createElement("canvas")).getContext("2d");
                    r.font = '17px "Mulish", sans-serif';
                    var o = Math.ceil(r.measureText(e.placeholderMessage).width);
                    n.current.style.cssText = "width: auto; align-self: flex-start;";
                    var a = n.current.clientWidth;
                    n.current.style.cssText = "";
                    var i = Object(lt.D)() && window.screen.width < 340,
                        s = Object(lt.D)() && window.screen.width < 410;
                    return i ? 160 : s ? 210 : Math.max(o, a - 15, 130)
                } catch (c) {
                    return 250
                }
            })), To.defaultProps = {
                messageContentRef: null
            };
            var Po = To;

            function Lo(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }
            var _o = O.a.forwardRef((function(e, t) {
                    var n = e.message,
                        r = n.content,
                        o = n.type,
                        a = n.attachmentType;
                    if (o === bt.e.uploadedFile) return Object(S.d)("div", {
                        className: "message-container ".concat(a, "-content"),
                        ref: t
                    }, Object(S.d)(Do, {
                        content: r,
                        onClick: function() {
                            e.dispatch(Object(pt.Sc)(mt.a.flyMessageClicked)), e.dispatch(Object(pt.uc)(ht.a.chat))
                        },
                        attachmentType: a
                    }));
                    var i = null;
                    if (o === bt.e.cards) {
                        var s, c, u = e.message.cards,
                            l = void 0 === u ? [] : u,
                            d = (null === (s = l[0]) || void 0 === s ? void 0 : s.title) || "";
                        i = $e(d);
                        var f = (null === (c = l[0]) || void 0 === c ? void 0 : c.imageUrl) || "";
                        if (f) return Object(S.d)("div", {
                            className: "message-container image-content",
                            ref: t
                        }, Object(S.d)(Do, {
                            content: f,
                            onClick: function() {
                                e.dispatch(Object(pt.uc)(ht.a.chat))
                            },
                            attachmentType: "image"
                        }), Object(S.d)("span", {
                            className: "fly-message--card-title",
                            dangerouslySetInnerHTML: {
                                __html: i
                            }
                        }))
                    } else i = $e(r);
                    return Object(S.d)("div", {
                        className: "message-container",
                        ref: t,
                        dangerouslySetInnerHTML: {
                            __html: i
                        }
                    })
                })),
                Fo = function(e) {
                    b()(n, e);
                    var t = Lo(n);

                    function n() {
                        var e;
                        c()(this, n);
                        for (var r = arguments.length, o = new Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                        return e = t.call.apply(t, [this].concat(o)), w()(f()(e), "browserName", Object(lt.m)().name.toLowerCase()), w()(f()(e), "flyMessageRef", O.a.createRef()), w()(f()(e), "contentRef", O.a.createRef()), w()(f()(e), "windowRef", Object(St.e)()), w()(f()(e), "iframeWidth", null), w()(f()(e), "iframeHeight", null), w()(f()(e), "rafId", null), w()(f()(e), "handleAnimationEnd", (function(t) {
                            "new-message-button-fly" === t.target.getAttribute("id") && e.props.view === ht.a.fly && e.updateIframe()
                        })), w()(f()(e), "hasButtons", (function() {
                            return void 0 !== e.props.message.quickReplies || void 0 !== e.props.message.cards || void 0 !== e.props.message.buttons
                        })), w()(f()(e), "expandIframeToMax", (function() {
                            var t = e.hasButtons() ? 495 : 362;
                            e.props.isMobile && (t = "100%"), e.props.dispatch(Object(pt.lc)("dynamic".concat(t, "_").concat("100%"), {
                                width: t,
                                height: "100%"
                            })), e.iframeWidth = t, e.iframeHeight = "100%"
                        })), w()(f()(e), "updateIframe", (function(t) {
                            return !!e.windowRef && (e.expandIframeToMax(), e.rafId = e.windowRef.requestAnimationFrame((function() {
                                var n = e.flyMessageRef.current,
                                    r = n.clientWidth,
                                    o = n.clientHeight;
                                if (e.props.isMobile) {
                                    if (r += 95, o += 80, e.iframeWidth === r && e.iframeHeight === o) return !1
                                } else if (r += 90, o += 90, e.iframeWidth === r && e.iframeHeight === o) return !1;
                                return t && (t.height && (o = Math.max(o, t.height)), t.width && (r = Math.max(r, t.width))), e.props.dispatch(Object(pt.lc)("dynamic".concat(r, "_").concat(o), {
                                    width: r,
                                    height: o
                                })), e.iframeWidth = r, e.iframeHeight = o, !0
                            })), !0)
                        })), e
                    }
                    return l()(n, [{
                        key: "componentDidMount",
                        value: function() {
                            this.flyMessageRef.current && this.flyMessageRef.current.addEventListener("transitionend", this.handleAnimationEnd), this.updateIframe()
                        }
                    }, {
                        key: "componentDidUpdate",
                        value: function() {
                            return this.props.view !== ht.a.fly ? (this.rafId && (this.windowRef.cancelAnimationFrame(this.rafId), this.rafId = null), !1) : (this.updateIframe(), !0)
                        }
                    }, {
                        key: "componentWillUnmount",
                        value: function() {
                            this.flyMessageRef.current.removeEventListener("transitionend", this.handleAnimationEnd)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this,
                                t = this.hasButtons();
                            return Object(S.d)("div", {
                                ref: this.flyMessageRef,
                                "data-testid": "flyMessage",
                                className: "flyMessage ".concat(t ? "with-buttons" : "", " ").concat(this.browserName)
                            }, Object(S.d)("div", {
                                className: "close-button-wrapper"
                            }, Object(S.d)(Fr, {
                                trackingEvent: mt.a.flyMessageClosed
                            })), Object(S.d)(_o, {
                                ref: this.contentRef,
                                message: this.props.message,
                                dispatch: this.props.dispatch
                            }), Object(S.d)(Po, {
                                messageContentRef: this.contentRef,
                                placeholderMessage: Object(Ge.c)("onlineMessagePlaceholder", null, "New message"),
                                lastMessage: this.props.message
                            }, (function(n) {
                                var r = n.width;
                                return Object(S.d)(Ro, {
                                    message: e.props.message,
                                    hasButtons: t,
                                    minFlyWidth: r
                                })
                            })))
                        }
                    }]), n
                }(O.a.Component),
                zo = Object(j.b)((function(e) {
                    return {
                        isMobile: e.isMobile,
                        view: e.view
                    }
                }))(Fo),
                Io = function(e) {
                    b()(n, e);
                    var t = Lo(n);

                    function n() {
                        var e;
                        c()(this, n);
                        for (var r = arguments.length, o = new Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                        return e = t.call.apply(t, [this].concat(o)), w()(f()(e), "state", {
                            message: e.props.lastMessage
                        }), w()(f()(e), "isPreview", Object(lt.y)()), e
                    }
                    return l()(n, [{
                        key: "render",
                        value: function() {
                            var e = this.isPreview ? this.props.lastMessage : this.state.message;
                            return Object(S.d)(zo, {
                                message: e
                            })
                        }
                    }]), n
                }(O.a.Component),
                Bo = Object(j.b)((function(e) {
                    return {
                        lastMessage: Object(Dt.d)(e)
                    }
                }))(Io),
                Ho = function(e) {
                    var t = e.view !== ht.a.closed;
                    return Object(S.d)(Mo, null, (function(n) {
                        var r = n.hasAnimationEnded,
                            o = n.onAnimationEnded;
                        return Object(S.d)(O.a.Fragment, null, Object(S.d)(X, { in: e.view === ht.a.fly && r,
                            classNames: "moveFromRight",
                            timeout: 300,
                            onExited: e.view === ht.a.closed || e.view === ht.a.fly ? o : void 0
                        }, Object(S.d)(Bo, null)), Object(S.d)(X, { in: t && e.view !== ht.a.fly && r,
                            classNames: "moveFromRight",
                            timeout: 300,
                            onExited: o
                        }, Object(S.d)(mo, null)), Object(S.d)(X, { in: !t && !r,
                            classNames: "".concat(e.sidebarPosition && "left" === e.sidebarPosition ? "bubbleAnimationLeft" : "bubbleAnimation"),
                            timeout: 300,
                            onExited: o
                        }, Object(S.d)(jo, {
                            isSidebarComponent: !0
                        })), Object(S.d)(X, { in: t && r,
                            timeout: 300,
                            classNames: "bubbleAnimation"
                        }, Object(S.d)(jo, null)))
                    }))
                };
            Ho.defaultProps = {
                sidebarPosition: "right"
            };
            var Wo = Object(j.b)((function(e) {
                return {
                    view: e.view,
                    sidebarPosition: e.sidebarIframeStyles.position
                }
            }))(Ho);

            function Vo(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }
            var Uo = function(e) {
                    b()(n, e);
                    var t = Vo(n);

                    function n() {
                        var e;
                        c()(this, n);
                        for (var r = arguments.length, o = new Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                        return e = t.call.apply(t, [this].concat(o)), w()(f()(e), "labelRef", O.a.createRef()), w()(f()(e), "windowRef", null), w()(f()(e), "iframeRef", null), w()(f()(e), "iframeWidth", null), w()(f()(e), "iframeHeight", null), w()(f()(e), "rafId", null), w()(f()(e), "isInPreview", Object(lt.y)()), w()(f()(e), "getIframeWidth", (function() {
                            return e.props.isAwesomeIframe ? 94 : 112
                        })), w()(f()(e), "getIframeHeight", (function() {
                            return e.props.isAwesomeIframe ? 94 : 140
                        })), w()(f()(e), "expandIframeToMax", (function() {
                            var t = e.getIframeHeight();
                            e.props.dispatch(Object(pt.lc)("dynamic".concat(450, "_").concat(t), {
                                width: 450,
                                height: t
                            })), e.iframeWidth = 450, e.iframeHeight = t
                        })), w()(f()(e), "checkWidth", (function() {
                            try {
                                var t = e.labelRef;
                                t.current.style.cssText = "width: auto; align-self: flex-start; white-space: nowrap";
                                var n = t.current.clientWidth;
                                return t.current.style.cssText = "", n + 15
                            } catch (r) {
                                return 250
                            }
                        })), w()(f()(e), "updateIframe", (function() {
                            if (!e.windowRef) return !1;
                            var t = e.getIframeWidth(),
                                n = e.getIframeHeight();
                            return e.isInPreview ? (e.expandIframeToMax(), !0) : (t += e.checkWidth(), e.rafId = e.windowRef.requestAnimationFrame((function() {
                                return (e.iframeWidth !== t || e.iframeHeight !== n) && (e.props.dispatch(Object(pt.lc)("dynamic".concat(t, "_").concat(n), {
                                    width: t,
                                    height: n
                                })), e.iframeWidth = t, !0)
                            })), !0)
                        })), w()(f()(e), "openWidget", (function() {
                            e.props.dispatch(Object(pt.Sc)(mt.a.widgetLabelClicked)), e.props.dispatch(Object(pt.Pc)()), e.props.dispatch(Object(pt.gc)(!0))
                        })), w()(f()(e), "truncateText", (function(e, t) {
                            for (var n = e, r = Hr()(n), o = n.length > t; n.length > t;) r.pop(), n = r.join("");
                            return o ? "".concat(n, "&hellip;") : n
                        })), e
                    }
                    return l()(n, [{
                        key: "componentDidMount",
                        value: function() {
                            this.windowRef = Object(St.e)(), this.iframeRef = Object(St.d)(), this.iframeWidth = this.iframeRef.clientWidth, this.iframeHeight = this.iframeRef.clientHeight, this.updateIframe()
                        }
                    }, {
                        key: "componentDidUpdate",
                        value: function() {
                            return this.props.view !== ht.a.closed ? (this.rafId && (this.windowRef.cancelAnimationFrame(this.rafId), this.rafId = null), !1) : (this.updateIframe(), !0)
                        }
                    }, {
                        key: "componentWillUnmount",
                        value: function() {
                            this.rafId && (this.windowRef.cancelAnimationFrame(this.rafId), this.rafId = null), this.props.view === ht.a.closed && this.props.dispatch(Object(pt.lc)(Ct.f.onlyBubble))
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this;
                            return Object(S.d)(ot, {
                                value: ["chatWithUsLabel"]
                            }, (function(t) {
                                var n = t.chatWithUsLabel;
                                return Object(S.d)("button", {
                                    className: "widgetLabel ".concat(e.props.mobileButtonSize, " ").concat(0 === n.length ? "hidden" : ""),
                                    ref: e.labelRef,
                                    onClick: e.openWidget,
                                    type: "button"
                                }, Object(S.d)("span", {
                                    dangerouslySetInnerHTML: {
                                        __html: $e(e.truncateText(n, 25))
                                    }
                                }))
                            }))
                        }
                    }]), n
                }(O.a.Component),
                qo = Object(j.b)((function(e) {
                    return {
                        view: e.view,
                        mobileButtonSize: e.mobileButtonSize,
                        isAwesomeIframe: Object(Dt.c)(e)
                    }
                }))(Uo),
                Go = Object(j.b)((function(e) {
                    return {
                        view: e.view,
                        widgetLabelEnabled: Object(Dt.i)(e)
                    }
                }))((function(e) {
                    var t = e.view !== ht.a.closed;
                    return Object(S.d)(Mo, null, (function(n) {
                        var r = n.hasAnimationEnded,
                            o = n.onAnimationEnded;
                        return Object(S.d)(O.a.Fragment, null, Object(S.d)(X, { in: e.view === ht.a.fly,
                            classNames: "moveFromRight",
                            onExited: e.view === ht.a.closed ? o : void 0,
                            timeout: 300
                        }, Object(S.d)(Bo, null)), Object(S.d)(X, { in: t && e.view !== ht.a.fly && r,
                            classNames: "moveFromRight",
                            onExited: o,
                            timeout: 400
                        }, Object(S.d)(mo, null)), e.widgetLabelEnabled && Object(S.d)(X, { in: !t && e.view !== ht.a.fly && !r,
                            classNames: "moveFromLeftLabel",
                            timeout: 300
                        }, Object(S.d)(qo, null)), Object(S.d)(X, { in: !t && !r,
                            classNames: "bubbleAnimationReturn",
                            timeout: 300,
                            onExited: o
                        }, Object(S.d)(jo, null)), Object(S.d)(X, { in: t && r,
                            classNames: "bubbleAnimation",
                            timeout: 300,
                            onExited: e.view === ht.a.fly ? o : void 0
                        }, Object(S.d)(jo, null)))
                    }))
                })),
                Yo = function() {},
                Qo = Object(j.b)((function(e) {
                    return {
                        view: e.view,
                        isMobile: e.isMobile,
                        widgetLabelEnabled: Object(Dt.i)(e)
                    }
                }))((function(e) {
                    var t = e.view !== ht.a.closed;
                    return e.isMobile ? Object(S.d)(O.a.Fragment, null, Object(S.d)(X, { in: e.view === ht.a.fly,
                        classNames: "moveFromRight",
                        timeout: 300
                    }, Object(S.d)(Bo, null)), Object(S.d)(X, { in: t && e.view !== ht.a.fly,
                        classNames: "moveFromRight",
                        timeout: 300
                    }, Object(S.d)(mo, null)), Object(S.d)(X, { in: !0,
                        classNames: "bubbleAnimation"
                    }, Object(S.d)(jo, null))) : Object(S.d)(Mo, null, (function(n) {
                        var r = n.hasAnimationEnded,
                            o = n.onAnimationEnded;
                        return Object(S.d)(O.a.Fragment, null, Object(S.d)(X, { in: e.view === ht.a.fly,
                            classNames: "moveFromRight",
                            timeout: 300,
                            onExited: e.view === ht.a.closed ? o : Yo
                        }, Object(S.d)(Bo, null)), Object(S.d)(X, { in: t && e.view !== ht.a.fly,
                            classNames: "moveFromRight",
                            timeout: 300,
                            onExited: o
                        }, Object(S.d)(mo, null)), e.widgetLabelEnabled && Object(S.d)(X, { in: !t && e.view !== ht.a.fly && r,
                            classNames: "moveFromRightLabel",
                            onExited: o,
                            timeout: 300
                        }, Object(S.d)(qo, null)), Object(S.d)(X, { in: !0,
                            classNames: "bubbleAnimation",
                            onEntered: o
                        }, Object(S.d)(jo, null)))
                    }))
                })),
                Ko = Object(j.b)((function(e) {
                    return {
                        view: e.view,
                        isMobile: e.isMobile
                    }
                }))((function(e) {
                    if ("left" === e.widgetPosition && e.isMobile) {
                        var t = e.view !== ht.a.closed;
                        return Object(S.d)(Mo, null, (function(n) {
                            var r = n.hasAnimationEnded,
                                o = n.onAnimationEnded;
                            return Object(S.d)(O.a.Fragment, null, Object(S.d)(X, { in: e.view === ht.a.fly,
                                classNames: "moveFromRight",
                                onExited: e.view === ht.a.closed ? o : void 0,
                                timeout: 300
                            }, Object(S.d)(Bo, null)), Object(S.d)(X, { in: t && e.view !== ht.a.fly && r,
                                classNames: "moveFromRight",
                                onExited: o,
                                timeout: 400
                            }, Object(S.d)(mo, null)), Object(S.d)(X, { in: !t && !r,
                                classNames: "bubbleAnimationReturn",
                                timeout: 300,
                                onExited: o
                            }, Object(S.d)(jo, null)), Object(S.d)(X, { in: t && r,
                                classNames: "bubbleAnimation",
                                timeout: 300,
                                onExited: e.view === ht.a.fly ? o : void 0
                            }, Object(S.d)(jo, null)))
                        }))
                    }
                    return Object(S.d)(O.a.Fragment, null, Object(S.d)(X, { in: e.view === ht.a.fly,
                        classNames: "moveFromRight",
                        timeout: 300
                    }, Object(S.d)(Bo, null)), Object(S.d)(X, { in: e.view !== ht.a.closed && e.view !== ht.a.fly,
                        classNames: "moveFromRight",
                        timeout: 300
                    }, Object(S.d)(mo, null)), Object(S.d)(X, { in: !0,
                        classNames: "bubbleAnimation"
                    }, Object(S.d)(jo, null)))
                })),
                Zo = function() {
                    var e = Object(x.useRef)(""),
                        t = Object(j.d)((function(e) {
                            return e.unreadMessages
                        })),
                        n = Object(j.d)((function(e) {
                            return e.isPageVisible
                        })),
                        r = Object(x.useRef)(null),
                        o = Object(x.useRef)(!1),
                        a = RegExp("\\([0-9]+\\) ".concat(Object(Ge.c)("newMessageTitle", null, "New message"), "$"));
                    return Object(x.useEffect)((function() {
                        try {
                            e.current = window.parent.document.title
                        } catch (t) {
                            o.current = !0
                        }
                    }), []), Object(x.useEffect)((function() {
                        if (o.current) return !1;
                        r.current && (clearInterval(r.current), r.current = null);
                        try {
                            !n && t ? r.current = setInterval((function() {
                                e.current === window.parent.document.title || a.test(window.parent.document.title) || (e.current = window.parent.document.title), window.parent.document.title === e.current ? window.parent.document.title = "(".concat(t, ") ").concat(Object(Ge.c)("newMessageTitle", null, "New message")) : window.parent.document.title = e.current
                            }), 1e3) : a.test(window.parent.document.title) && (window.parent.document.title = e.current)
                        } catch (i) {}
                        return function() {
                            if (o.current) return !1;
                            clearInterval(r.current);
                            try {
                                a.test(window.parent.document.title) && (window.parent.document.title = e.current)
                            } catch (i) {}
                            return !0
                        }
                    }), [n, t, a]), null
                };

            function Xo(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }
            var $o = function(e) {
                    b()(n, e);
                    var t = Xo(n);

                    function n() {
                        var e;
                        c()(this, n);
                        for (var r = arguments.length, o = new Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                        return e = t.call.apply(t, [this].concat(o)), w()(f()(e), "state", {
                            isFontLoaded: !1
                        }), w()(f()(e), "onWindowVisibilityChange", (function() {
                            e.setVisibilityState() && e.props.dispatch(Object(pt.Jc)())
                        })), w()(f()(e), "appAvariant", (function() {
                            return e.props.isChatOnSite ? Object(S.d)(Ko, {
                                widgetPosition: e.props.widgetPosition
                            }) : e.props.isSidebarEnabled ? Object(S.d)(Wo, null) : "left" === e.props.widgetPosition ? Object(S.d)(Go, null) : Object(S.d)(Qo, null)
                        })), e
                    }
                    return l()(n, [{
                        key: "componentDidMount",
                        value: function() {
                            var e = this;
                            try {
                                window.document.addEventListener("visibilitychange", this.onWindowVisibilityChange), this.setVisibilityState()
                            } catch (n) {
                                Object(ct.a)(n)
                            }
                            try {
                                var t = new T.a("Mulish", {
                                    weight: 400,
                                    document: Object(St.c)()
                                });
                                this.state.isFontLoaded || t.load(null, 3e3).catch((function() {})).then((function() {
                                    e.setState({
                                        isFontLoaded: !0
                                    }), window.tidioChatApi.trigger("ready"), window.tidioChatApi.trigger("setStatus", e.props.isProjectOnline ? "online" : "offline")
                                }))
                            } catch (n) {
                                Object(ct.a)(n), this.setState({
                                    isFontLoaded: !0
                                }), window.tidioChatApi.trigger("ready"), window.tidioChatApi.trigger("setStatus", this.props.isProjectOnline ? "online" : "offline")
                            }
                        }
                    }, {
                        key: "componentDidUpdate",
                        value: function(e) {
                            e.widgetPosition !== this.props.widgetPosition && this.props.setWidgetPosition(this.props.widgetPosition)
                        }
                    }, {
                        key: "componentWillUnmount",
                        value: function() {
                            window.document.removeEventListener("visibilitychange", this.onWindowVisibilityChange)
                        }
                    }, {
                        key: "setVisibilityState",
                        value: function() {
                            return "visible" !== document.visibilityState ? (this.props.dispatch(Object(pt.rc)(!1)), !1) : (this.props.dispatch(Object(pt.rc)(!0)), !0)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return this.state.isFontLoaded ? Object(S.d)(O.a.Fragment, null, !this.props.isSoundEnabled && Object(S.d)(Zo, null), this.appAvariant()) : null
                        }
                    }]), n
                }(x.Component),
                Jo = Object(j.b)((function(e) {
                    return {
                        widgetPosition: e.chatIframeStyles.widgetPosition,
                        isSidebarEnabled: e.sidebarIframeStyles,
                        isChatOnSite: Object(vt.b)(e),
                        isProjectOnline: e.isProjectOnline,
                        isSoundEnabled: e.isSoundEnabled
                    }
                }))($o),
                ea = "firefox" === Object(lt.m)().name.toLowerCase() ? {
                    srcDoc: ""
                } : {},
                ta = O.a.lazy((function() {
                    return n.e(1).then(n.bind(null, 402))
                })),
                na = function() {
                    return Object(S.d)(O.a.Fragment, null)
                },
                ra = function() {
                    var e = Object(j.d)((function(e) {
                        return e.popupImageSrc
                    }));
                    return "string" === typeof e && "" !== e ? Object(S.d)(M.a, o()({
                        title: "Tidio Chat - Image Popup",
                        style: {
                            width: "100%",
                            height: "100%",
                            position: "fixed",
                            top: "0",
                            left: "0",
                            zIndex: 2147483003,
                            border: 0
                        },
                        id: "tidio-chat-image-popup"
                    }, ea), Object(S.d)(x.Suspense, {
                        fallback: na
                    }, Object(S.d)(ta, {
                        imageSrc: e
                    }))) : null
                },
                oa = n(391),
                aa = n.n(oa),
                ia = n(195),
                sa = n(337),
                ca = n(196),
                ua = n(3);

            function la(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function da(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? la(Object(n), !0).forEach((function(t) {
                        w()(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : la(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }

            function fa(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = v()(e);
                    if (t) {
                        var o = v()(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return m()(this, n)
                }
            }
            n.d(t, "addImportantToDefaultStyles", (function() {
                return ba
            }));
            var pa = {
                    zIndex: "z-index",
                    transition: "transition",
                    background: "background"
                },
                ba = function(e) {
                    try {
                        e && Object.keys(pa).forEach((function(t) {
                            e.style.setProperty(pa[t], e.style[t], "important")
                        }))
                    } catch (t) {}
                };

            function ha(e, t, n) {
                "mobile" === t ? setTimeout((function() {
                    e.style.setProperty("bottom", n, "important")
                }), 0) : "onlySidebar" === t ? setTimeout((function() {
                    e.style.setProperty("bottom", n, "important"), e.style.setProperty("transform", "translateY(50%)", "important")
                }), 0) : e.style.setProperty("bottom", n)
            }
            var ma = Object(lt.m)().name.toLowerCase(),
                ga = "firefox" === ma ? {
                    srcDoc: ""
                } : {},
                va = Object(lt.A)(),
                ya = function(e) {
                    b()(n, e);
                    var t = fa(n);

                    function n(e) {
                        var r;
                        return c()(this, n), r = t.call(this, e), w()(f()(r), "styleCache", Object(E.a)({
                            key: "tidio",
                            stylisPlugins: Object(Ge.a)() ? [D.a] : [],
                            container: r.props.iframeDocument.head
                        })), w()(f()(r), "state", {
                            isRendered: !1
                        }), w()(f()(r), "setImportantPositioningForMobileAndSidebar", (function() {
                            "mobile" === r.props.iframeView ? setTimeout((function() {
                                r.props.iframeWindow.frameElement && r.props.iframeWindow.frameElement.style.setProperty("bottom", r.getBottomOffset(), "important")
                            }), 0) : "onlySidebar" === r.props.iframeView ? setTimeout((function() {
                                return !!r.props.iframeWindow.frameElement && (r.props.iframeWindow.frameElement.style.setProperty("bottom", "50%", "important"), r.props.iframeWindow.frameElement.style.setProperty("transform", "translateY(50%)", "important"), !0)
                            }), 0) : r.props.iframeWindow.frameElement.style.setProperty("bottom", r.getBottomOffset())
                        })), w()(f()(r), "registerClickForAutoPlayPermissions", (function() {
                            try {
                                var e = function e() {
                                    Object(ia.b)(ma), window.parent.document.removeEventListener("click", e, !0), window.parent.document.removeEventListener("touchend", e, !0), r.props.iframeDocument.removeEventListener("click", e, !0), r.props.iframeDocument.removeEventListener("touchend", e, !0)
                                };
                                (Object(lt.D)() || "Safari" === ma || "Mobile Safari" === ma) && (window.parent.document.addEventListener("click", e, !0), window.parent.document.addEventListener("touchend", e, !0), r.props.iframeDocument.addEventListener("click", e, !0), r.props.iframeDocument.addEventListener("touchend", e, !0))
                            } catch (t) {
                                Object(ct.a)(t)
                            }
                        })), Object(St.g)(r.props.iframeDocument, r.props.iframeWindow), r
                    }
                    return l()(n, [{
                        key: "componentDidMount",
                        value: function() {
                            var e = this;
                            ba(this.props.iframeWindow.frameElement), ha(this.props.iframeWindow.frameElement, this.props.iframeView, this.getBottomOffset()), this.props.isSoundEnabled && this.registerClickForAutoPlayPermissions(), this.setImportantPositioningForMobileAndSidebar(), "firefox" === ma && A.Globals.injectFrame(this.props.iframeWindow.requestAnimationFrame, this.props.iframeWindow.cancelAnimationFrame);
                            try {
                                this.props.iframeDocument.addEventListener("error", (function(t) {
                                    var n;
                                    if (null !== t && void 0 !== t && null !== (n = t.target) && void 0 !== n && n.matches("img.emoji") && t.target.parentNode) {
                                        var r = t.target.closest(".message"),
                                            o = null === r || void 0 === r ? void 0 : r.querySelector(".message-content");
                                        if (t.target.parentNode.replaceChild(e.props.iframeDocument.createTextNode(t.target.alt), t.target), r && o && e.props.iframeWindow) {
                                            e.props.iframeWindow.requestAnimationFrame((function() {
                                                r.style.width = "".concat(o.offsetWidth + 35, "px")
                                            }))
                                        }
                                    }
                                }), !0)
                            } catch (t) {
                                Object(ct.a)(t)
                            }
                            setTimeout((function() {
                                e.setState({
                                    isRendered: !0
                                })
                            }), 0)
                        }
                    }, {
                        key: "componentDidUpdate",
                        value: function(e) {
                            e.iframeView !== this.props.iframeView && (ba(this.props.iframeWindow.frameElement), this.setImportantPositioningForMobileAndSidebar(), ha(this.props.iframeWindow.frameElement, this.props.iframeView, this.getBottomOffset()))
                        }
                    }, {
                        key: "getBottomOffset",
                        value: function() {
                            var e = this.props,
                                t = e.isAwesomeIframe,
                                n = e.iframeMode;
                            return "onlySidebar" === e.iframeView ? "50%" : t && null !== Ct.b && void 0 !== Ct.b && Ct.b[n] && Ct.b[n].bottom || 0
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return Object(S.d)(S.a, {
                                value: this.styleCache
                            }, Object(S.d)(S.b, {
                                styles: Object(S.c)(aa.a.toString(), "")
                            }), Object(S.d)(ca.a, null), this.state.isRendered && Object(S.d)(Jo, {
                                setWidgetPosition: this.props.setWidgetPosition
                            }))
                        }
                    }]), n
                }(O.a.Component),
                wa = Object(sa.a)(ya),
                xa = function(e) {
                    b()(n, e);
                    var t = fa(n);

                    function n() {
                        var e, r;
                        c()(this, n);
                        for (var o = arguments.length, a = new Array(o), s = 0; s < o; s++) a[s] = arguments[s];
                        return r = t.call.apply(t, [this].concat(a)), w()(f()(r), "getIframeSize", (function() {
                            var e = Object(Ct.d)(r.props.iframeView),
                                t = "onlySidebar" === r.props.iframeView ? {
                                    left: "left" === r.props.sidebarPosition ? "0" : void 0,
                                    right: "right" === r.props.sidebarPosition ? "0" : void 0
                                } : {};
                            return da(da({}, e), t)
                        })), w()(f()(r), "state", {
                            style: da(da({
                                display: "block",
                                border: "none",
                                position: !r.props.isChatOnSite || Object(lt.D)() || Object(lt.y)() ? "fixed" : "inherit",
                                top: "auto",
                                bottom: 0,
                                left: "auto",
                                right: "auto"
                            }, r.getIframeSize()), {}, (e = {
                                opacity: 0
                            }, w()(e, r.props.widgetPosition, 0), w()(e, "background", "none transparent"), w()(e, "margin", 0), w()(e, "maxHeight", "100vh"), w()(e, "maxWidth", "100vw"), w()(e, "transform", "translateY(0)"), w()(e, "transition", "none"), w()(e, "visibility", "visible"), w()(e, "zIndex", 999999999), e))
                        }), w()(f()(r), "ref", null), w()(f()(r), "getAwesomeIframeOffset", (function(e, t) {
                            var n, r = 0;
                            return null !== Ct.b && void 0 !== Ct.b && null !== (n = Ct.b[e]) && void 0 !== n && n[t] && (r = Ct.b[e][t]), r
                        })), w()(f()(r), "setIframeStyle", (function(e) {
                            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : function() {};
                            r.setState({
                                style: e
                            }, t)
                        })), w()(f()(r), "getCurrentIframeStyle", (function() {
                            return da({}, r.state.style)
                        })), w()(f()(r), "mergeWithCurrentStyles", (function(e) {
                            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : function() {};
                            r.setIframeStyle(da(da({}, r.getCurrentIframeStyle()), e)), t()
                        })), w()(f()(r), "setWidgetPosition", (function(e, t) {
                            var n = r.getCurrentIframeStyle(),
                                o = r.getIframeMode(),
                                a = 0;
                            r.props.isAwesomeIframe && (a = r.getAwesomeIframeOffset(o, e)), r.setIframeStyle(da(da({}, n), {}, {
                                right: "auto",
                                left: "auto"
                            }, w()({}, e, a)), t)
                        })), w()(f()(r), "getIframeAwesomeStyle", (function() {
                            var e = r.props,
                                t = e.widgetPosition,
                                n = {};
                            if (e.isAwesomeIframe) {
                                var o = r.getIframeMode(),
                                    a = (null === Ct.b || void 0 === Ct.b ? void 0 : Ct.b[o]) || {},
                                    i = a.width,
                                    s = a.height;
                                if (i && (n.width = i), s && (n.height = s), n[t] = r.getAwesomeIframeOffset(o, t), n.borderRadius = Object(lt.D)() ? 0 : Ct.a, va) {
                                    var c = (null === Ct.b || void 0 === Ct.b ? void 0 : Ct.b[o]) || {},
                                        u = c.bottom,
                                        l = c.right;
                                    n.bottom = u, n.right = l
                                }
                            }
                            return n
                        })), w()(f()(r), "onIframeMount", (function() {
                            r.setWidgetPosition(r.props.widgetPosition, r.animateOpacity)
                        })), w()(f()(r), "animateOpacity", (function() {
                            r.mergeWithCurrentStyles({
                                display: "block"
                            }, (function() {
                                setTimeout((function() {
                                    r.mergeWithCurrentStyles({
                                        opacity: 1
                                    })
                                }), 0)
                            }))
                        })), w()(f()(r), "onIframeRef", (function(e) {
                            r.ref = e;
                            var t = r.props,
                                n = t.widgetPosition,
                                o = t.isAwesomeIframe,
                                a = t.dispatch,
                                i = Object(ua.a)("widget_position");
                            try {
                                if (null !== e && void 0 !== e && e.node) {
                                    var s = e.node.getBoundingClientRect(),
                                        c = s.left,
                                        u = s.right,
                                        l = s.bottom,
                                        d = window.parent,
                                        f = d.innerWidth,
                                        p = d.innerHeight,
                                        b = "left" === n ? c : f - u,
                                        h = p - l;
                                    0 === b && 0 === h || i || o || (a(Object(pt.zc)({
                                        initialX: b,
                                        initialY: h
                                    })), Object(ua.g)("widget_position", !0))
                                }
                            } catch (m) {
                                Object(ct.a)("Error onIframeRef", {
                                    message: null === m || void 0 === m ? void 0 : m.message
                                })
                            }
                            o && r.mergeWithCurrentStyles(da({}, Ct.b[r.getIframeMode()]))
                        })), w()(f()(r), "getIframeMode", (function() {
                            var e = r.props,
                                t = e.iframeView,
                                n = e.isWidgetLabelEnabled,
                                o = e.view;
                            if (t.includes(Ct.f.dynamic)) {
                                var a = t.replace(Ct.f.dynamic, "").split("_");
                                return "94" === i()(a, 2)[1] && n && o !== ht.a.fly ? Ct.f.bubbleWithLabel : Ct.f.dynamic
                            }
                            return t === Ct.f.onlyBubble && r.props.isMobile ? Ct.f.onlyBubbleLarge : t
                        })), w()(f()(r), "componentDidUpdate", (function(e) {
                            try {
                                var t, n, o, a, i;
                                if (va && r.props.isAwesomeIframe && e.isAwesomeIframe !== r.props.isAwesomeIframe && null !== (t = r.ref) && void 0 !== t && t.node) null === (n = r.ref.node.contentWindow) || void 0 === n || null === (o = n.document) || void 0 === o || null === (a = o.querySelector("body")) || void 0 === a || null === (i = a.classList) || void 0 === i || i.add("awesome-iframe")
                            } catch (s) {}
                        })), r
                    }
                    return l()(n, [{
                        key: "render",
                        value: function() {
                            var e = this.props.hideWhenOffline && !this.props.isProjectOnline && !this.props.isChatOnSite,
                                t = Object(Ge.a)();
                            if (!this.props.isMounted || e) return null;
                            var n = "".concat(this.props.isMobile ? "mobile" : "", " ").concat(this.props.isChatOnSite ? "chat-on-site" : "", " ").concat(t ? "lang-rtl" : "", " ").concat(Object(lt.y)() ? "chat-in-preview" : "", " ").concat(Object(lt.B)() ? "chat-in-preview--tour" : "", " ").concat(this.props.isAwesomeIframe ? "awesome-iframe" : "", " ").concat("ie" === ma ? "legacy" : ""),
                                r = this.getIframeMode();
                            return Object(S.d)(O.a.Fragment, null, Object(S.d)(M.a, o()({
                                ref: this.onIframeRef,
                                title: "Tidio Chat",
                                head: Object(S.d)(O.a.Fragment, null, Object(S.d)("link", {
                                    href: "https://fonts.googleapis.com/css2?family=Mulish:wght@400;600&display=swap",
                                    rel: "stylesheet"
                                })),
                                style: da(da(da({}, this.state.style), this.getIframeSize()), this.getIframeAwesomeStyle()),
                                initialContent: '\n                  <html lang="en">\n                  <head>\n                  <meta name="viewport" content="width=device-width, user-scalable=no">\n                    </head>\n                  <body '.concat(t ? 'dir="rtl"' : "", ' class="').concat(n.trim(), '">\n                    <div></div>\n                  </body>\n                  '),
                                id: "tidio-chat-iframe",
                                contentDidMount: this.onIframeMount
                            }, ga), Object(S.d)("div", {
                                className: "".concat("left" === this.props.widgetPosition ? "widget-position-left" : "widget-position-right", " ").concat("left" === this.props.sidebarPosition ? "sidebar-position-left" : "sidebar-position-right", " ").concat(r)
                            }, Object(S.d)(wa, {
                                setWidgetPosition: this.setWidgetPosition,
                                iframeView: this.props.iframeView,
                                iframeMode: r,
                                isSoundEnabled: this.props.isSoundEnabled,
                                isAwesomeIframe: this.props.isAwesomeIframe
                            }))), Object(S.d)(ra, null))
                        }
                    }]), n
                }(O.a.Component);
            xa.defaultProps = {
                sidebarPosition: "right"
            };
            t.default = Object(C.hot)(Object(j.b)((function(e) {
                return {
                    isMounted: e.isMounted,
                    iframeView: e.chatIframeStyles.iframeView,
                    isMobile: e.isMobile,
                    widgetPosition: e.chatIframeStyles.widgetPosition,
                    hideWhenOffline: e.hideWhenOffline,
                    isProjectOnline: e.isProjectOnline,
                    isSidebarEnabled: e.sidebarIframeStyles,
                    isAwesomeIframe: Object(Dt.c)(e),
                    sidebarPosition: e.sidebarIframeStyles.position,
                    isChatOnSite: Object(vt.b)(e),
                    isSoundEnabled: e.isSoundEnabled,
                    isWidgetLabelEnabled: Object(Dt.i)(e),
                    view: e.view
                }
            }))(xa))
        }
    }
]);